<?php

/* :script:voixoff.html.twig */
class __TwigTemplate_2c6c468234d92bd992cc02636c2e4616798b877a17ed6adf96af509fda9e8a4e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":script:voixoff.html.twig", 1);
        $this->blocks = array(
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_ariane($context, array $blocks = array())
    {
        // line 5
        echo "
     <div class=\"ariane grey\">
         <div class=\"ib sub-txt-small fine grey\">Projet en cours : </div><div class=\"ib fine lightgrey bord-droit\"> ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "nomProjet", array()), "html", null, true);
        echo "</div>

         <a href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine\">PROJETS</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Paramètres</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <a href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_orientation", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine\">SCRIPT</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Guide</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_voixoff", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Voix-Off</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Ecriture</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <div class=\"ib fine\">STORYBOARD</div>
         <div class=\"ib fine\">></div>
         <div class=\"ib fine petite\">Ecriture</div>

     </div>

 ";
    }

    // line 42
    public function block_left($context, array $blocks = array())
    {
        // line 43
        echo "

<table>

    <td style=\"width:70%; vertical-align: top;\">
        <div class=\"largeur-voixoff\">

            <form>

                <table class=\"title-tab\">
                    <td class=\"padding-ten\"><h3 class=\"script-voixoff hand\">Rédigez le texte de la voix-off</h3></td>
                </table>


                <div class=\"largeur-totale\">
                    <label for=\"voixoffglobal\"></label>
                    <textarea style=\"width: 98%;\" placeholder=\"Rédigez votre voix-off...\" rows=\"30\" class=\"questionnaire\" name=\"voixoff\">";
        // line 59
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "voixoffGlobal", array()), "html", null, true);
        echo "</textarea>
                </div>



                <div class=\"grey\">

                    ";
        // line 66
        $context["timing"] = ($this->getAttribute((isset($context["script"]) ? $context["script"] : null), "count", array()) / 2.5);
        // line 67
        echo "                    ";
        $context["minround"] = ((isset($context["timing"]) ? $context["timing"] : null) / 60);
        // line 68
        echo "                    ";
        $context["min"] = twig_round((isset($context["minround"]) ? $context["minround"] : null), 0, "floor");
        // line 69
        echo "                    ";
        $context["sec"] = ((isset($context["timing"]) ? $context["timing"] : null) % 60);
        // line 70
        echo "
                    <div class=\"ib\">
                        <div class=\"ib sub-txt-big\">";
        // line 72
        if ($this->getAttribute((isset($context["script"]) ? $context["script"] : null), "count", array())) {
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "count", array()), "html", null, true);
        } else {
            echo "0";
        }
        echo "</div>
                        <div class=\"ib sub-txt-small bord-droit\">mots</div>
                    </div>
                    <div class=\"ib\">
                        <div class=\"ib sub-txt-small\">Durée estimée :</div>
                        <div class=\"ib sub-txt-big\">";
        // line 77
        echo twig_escape_filter($this->env, (isset($context["min"]) ? $context["min"] : null), "html", null, true);
        echo "</div>
                        <div class=\"ib sub-txt-small\">min</div>
                        <div class=\"ib sub-txt-big\">";
        // line 79
        echo twig_escape_filter($this->env, (isset($context["sec"]) ? $context["sec"] : null), "html", null, true);
        echo "</div>
                        <div class=\"ib sub-txt-small bord-droit\">sec</div>
                    </div>





                    <div class=\"ib\">
                        <button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\" formmethod=\"post\" formaction=\"";
        // line 88
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_voixoff_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "id", array()))), "html", null, true);
        echo "\">
                            <div class=\"ib\">
                            <table class=\"ib tab-buttons-petit shadow back-voixoff\">
                                <td>
                                    <div class=\"lightgrey fine\">Mettre à jour</div>
                                </td>
                                <td>
                                    <img src=\"";
        // line 95
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/refresh-button.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"19\">
                                </td>
                            </table>
                            </div>
                            <div class=\"ib\">
                            <table class=\"ib tab-buttons-petit shadow back-voixoff\">
                                <td>
                                    <div class=\"lightgrey fine\">Enregistrer</div>
                                </td>
                                <td>
                                    <img src=\"";
        // line 105
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/save-file-option.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"19\">
                                </td>
                            </table>
                    </div>
                        </button>



                    </div>

                </div>




            </form>

        </div>



            <table class=\"largeur-totale voixoff-boxes\">

                <td style=\"width:33%\" class=\"txt-center\">
                    <div class=\"script-voixoff-box1 back-questions\">
                    <a href=\"";
        // line 130
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">
                        <div class=\"ib\">

                            <img src=\"";
        // line 133
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/list.png"), "html", null, true);
        echo "\" alt=\"Script\" height=\"30\">
                        </div>
                        <div>
                            <h3 class=\"ib hand petite\"><- Répondre aux questions</h3>
                        </div>
                        <div class=\"ib txtround2 fine\">
                            <h4 class=\"script-questions\">1</h4>
                        </div>
                   </a>
                    </div>
                </td>
                <td style=\"width:20%\"></td>

                <td style=\"width:33%\" class=\"txt-center\">
                    <div class=\"script-voixoff-box3 back-script\">
                        <a href=\"";
        // line 148
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">

                        <div class=\"ib\">
                            <img src=\"";
        // line 151
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pencil.png"), "html", null, true);
        echo "\" alt=\"Retour\" height=\"30\">
                        </div>
                        <div>
                            <h3 class=\"ib hand petite\">Ecrire le script -></h3>
                        </div>
                            <div class=\"ib txtround2 fine\">
                                <h4 class=\"script\">3</h4>
                            </div>
                    </a>
                    </div>
                </td>

            </table>


        </div>




    </td>
    <td style=\"vertical-align: top; padding-right: 3%; padding-top: 1.5%;\">


        <div class=\"largeur-voixoff-right back-voixoff padding-ten\">
            <a href=\"";
        // line 176
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">

            <h3 class=\"ib bord-droit lightgrey\">Vos réponses :</h3>
            </a>
            ";
        // line 180
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["reponses"]) ? $context["reponses"] : null));
        foreach ($context['_seq'] as $context["key"] => $context["reponse"]) {
            // line 181
            echo "                <div class=\"id sub-txt-small grey\">
                      ";
            // line 182
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["reponse"], "question", array()), "question", array()), "html", null, true);
            echo "
                </div>

                <div class=\"id sub-txt-small lightgrey\">
                    ";
            // line 186
            if ($this->getAttribute($context["reponse"], "reponse", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "reponse", array()), "html", null, true);
                echo "
                    ";
            } else {
                // line 187
                echo " Vous n'avez pas répondu
                    ";
            }
            // line 189
            echo "                </div>

            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['reponse'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 192
        echo "        </div>

    </td>

</table>
";
    }

    public function getTemplateName()
    {
        return ":script:voixoff.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  314 => 192,  306 => 189,  302 => 187,  296 => 186,  289 => 182,  286 => 181,  282 => 180,  275 => 176,  247 => 151,  241 => 148,  223 => 133,  217 => 130,  189 => 105,  176 => 95,  166 => 88,  154 => 79,  149 => 77,  137 => 72,  133 => 70,  130 => 69,  127 => 68,  124 => 67,  122 => 66,  112 => 59,  94 => 43,  91 => 42,  76 => 29,  69 => 25,  62 => 21,  55 => 17,  48 => 13,  41 => 9,  36 => 7,  32 => 5,  29 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", ":script:voixoff.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/script/voixoff.html.twig");
    }
}
