<?php

/* :script:show.html.twig */
class __TwigTemplate_7a4938fe88cc042c8f3e5a9a4f5c463107415a4e288f6a4485b957d12ec5f2c5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":script:show.html.twig", 1);
        $this->blocks = array(
            'contentlarge' => array($this, 'block_contentlarge'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_contentlarge($context, array $blocks = array())
    {
        // line 4
        echo "






    <div style=\"width: 100%; text-align: center\">

    <a href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_print", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "id", array()))), "html", null, true);
        echo "\" target=_blank>
    <img class=\"imgflat\" src=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/printer.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"70\"><h4 style=\"color: #ed7425\">Imprimer</h4></a>

    </div>
    <br>
    <div style=\"width: 100%; text-align: center\">

    <a href=\"#\">
    <img class=\"imgflat\" src=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/hand-shake.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"70\"><h4 style=\"color: #273b7a\">Faire appel à un expert</h4></a>

    </div>
    <br>
    <div style=\"width: 100%; text-align: center\">

    <a href=\"#\">
    <img class=\"imgflat\" src=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/trophy.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"70\"><h4 style=\"color: #c92f00\">Valider le script</h4></a>

    </div>


";
    }

    public function getTemplateName()
    {
        return ":script:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  66 => 28,  56 => 21,  46 => 14,  42 => 13,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", ":script:show.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/script/show.html.twig");
    }
}
