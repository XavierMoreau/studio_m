<?php

/* :scriptecriture:edit.html.twig */
class __TwigTemplate_5782f3170abb5addec95af0d192378a15fa8f616cdfc3bbc42a8ea2825368d37 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":scriptecriture:edit.html.twig", 1);
        $this->blocks = array(
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_ariane($context, array $blocks = array())
    {
        // line 5
        echo "
     <div class=\"ariane grey\">
         <div class=\"ib sub-txt-small fine grey\">Projet en cours : </div><div class=\"ib fine lightgrey bord-droit\"> ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "nomProjet", array()), "html", null, true);
        echo "</div>

         <a href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine\">PROJETS</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Paramètres</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <a href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_orientation", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine\">SCRIPT</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Guide</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_voixoff", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Voix-Off</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Ecriture</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <div class=\"ib fine\">STORYBOARD</div>
         <div class=\"ib fine\">></div>
         <div class=\"ib fine petite\">Ecriture</div>

     </div>

 ";
    }

    // line 42
    public function block_left($context, array $blocks = array())
    {
        // line 43
        echo "


    ";
        // line 46
        $context["mintotal"] = 0;
        // line 47
        echo "    ";
        $context["sectotal"] = 0;
        // line 48
        echo "


<table>

    <td style=\"width:65%; vertical-align: top; background-color: #e4e8e9;\">

        <div class=\"padding-ten\">

    <div class=\"largeur-totale script-footer\">
        <a target=\"_blank\" class=\"ib icontop\" href=\"";
        // line 58
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_print", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "id", array()))), "html", null, true);
        echo "\">
            <img src=\"";
        // line 59
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/print.png"), "html", null, true);
        echo "\" alt=\"Imprimer\" height=\"25\">

        </a>
        <a class=\"ib icontop\" href=\"";
        // line 62
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_valid", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "id", array()))), "html", null, true);
        echo "\">
            <img src=\"";
        // line 63
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/envelope.png"), "html", null, true);
        echo "\" alt=\"Mail\" height=\"25\">

        </a>
    </div>



    ";
        // line 71
        echo "    <form>


            ";
        // line 74
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["ecritures"]) ? $context["ecritures"] : null));
        foreach ($context['_seq'] as $context["key"] => $context["ecriture"]) {
            // line 75
            echo "
                ";
            // line 77
            echo "
                <div style=\"background-color: white\";>
                <table class=\"title-tab\">
                    <td class=\"padding-ten script\"><h3>Ligne de script n° ";
            // line 80
            echo twig_escape_filter($this->env, ($context["key"] + 1), "html", null, true);
            echo "</h3></td>
                </table>

        ";
            // line 84
            echo "
            ";
            // line 86
            echo "            <input type=\"hidden\" name=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\" value=\"idecriture";
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\">

                <div class=\"largeur-totale\">
                    <div class=\"largeur-half-form-script ib txt-center\">
                        <div class=\"largeur-totale title-txt-petit script\">Voix-off</div>
                        <div class=\"largeur-totale padding-ten\" >
                            <label for=\"voixoff";
            // line 92
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\"></label>
                            <textarea class=\"txtarea-form-script\" placeholder=\"Saisissez la voixoff ici...\" rows=\"10\" name=\"vo";
            // line 93
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\" >";
            if ($this->getAttribute($context["ecriture"], "voixoff", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "voixoff", array()), "html", null, true);
            }
            echo "</textarea>
                        </div>
                    </div>
                    <div class=\"largeur-half-form-script ib txt-center\">
                        <div class=\"largeur-totale title-txt-petit script\">Description</div>
                        <div class=\"largeur-totale padding-ten\" >
                            <label for=\"description";
            // line 99
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\"></label>
                            <textarea class=\"txtarea-form-script\" placeholder=\"Saisissez la description ici...\" rows=\"10\" name=\"desc";
            // line 100
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\" >";
            if ($this->getAttribute($context["ecriture"], "description", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "description", array()), "html", null, true);
            }
            echo "</textarea>
                        </div>
                    </div>

                </div>

                <div class=\"sub-form-script\">
                    ";
            // line 107
            $context["timing"] = ($this->getAttribute($context["ecriture"], "count", array()) / 2.5);
            // line 108
            echo "                    ";
            $context["minround"] = ((isset($context["timing"]) ? $context["timing"] : null) / 60);
            // line 109
            echo "                    ";
            $context["min"] = twig_round((isset($context["minround"]) ? $context["minround"] : null), 0, "floor");
            // line 110
            echo "                    ";
            $context["sec"] = ((isset($context["timing"]) ? $context["timing"] : null) % 60);
            // line 111
            echo "                    <div class=\"ib\">
                        <div class=\"ib padding-ten sub-txt-big\">";
            // line 112
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "count", array()), "html", null, true);
            echo "</div>
                        <div class=\"ib sub-txt-small bord-droit\">mots</div>
                    </div>
                    <div class=\"ib\">
                        <div class=\"ib sub-txt-small\">Durée estimée :</div>
                        <div class=\"ib sub-txt-big\">";
            // line 117
            echo twig_escape_filter($this->env, (isset($context["min"]) ? $context["min"] : null), "html", null, true);
            echo "</div>
                        <div class=\"ib sub-txt-small\">min</div>
                        <div class=\"ib sub-txt-big\">";
            // line 119
            echo twig_escape_filter($this->env, (isset($context["sec"]) ? $context["sec"] : null), "html", null, true);
            echo "</div>
                        <div class=\"ib sub-txt-small bord-droit\">sec</div>
                    </div>
                        <div class=\"ib\">
                        <div class=\"ib sub-txt-small\">Forcer la durée :</div>
                            <input style=\"display: inline-block; width: 50px; padding-right: 5px;\" placeholder=\"00\" type=\"number\" min=\"0\" max=\"59\" step=\"1\" class=\"form-control\" name=\"min";
            // line 124
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\" value=\"";
            if ($this->getAttribute($context["ecriture"], "tempsForceMin", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "tempsForceMin", array()), "html", null, true);
            }
            echo "\">
                        <div class=\"ib sub-txt-small\"> min</div>
                            <input style=\"display: inline-block; width: 50px; padding-right: 5px;\" placeholder=\"00\" type=\"number\" min=\"0\" max=\"59\" step=\"1\" class=\"form-control\" name=\"sec";
            // line 126
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\" value=\"";
            if ($this->getAttribute($context["ecriture"], "tempsForceSec", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "tempsForceSec", array()), "html", null, true);
            }
            echo "\">
                        <div class=\"ib sub-txt-small bord-droit\"> sec</div>
                    </div>

                    ";
            // line 130
            if (($this->getAttribute($context["ecriture"], "tempsForceMin", array()) || $this->getAttribute($context["ecriture"], "tempsForceSec", array()))) {
                // line 131
                echo "                        ";
                $context["mintotal"] = ((isset($context["mintotal"]) ? $context["mintotal"] : null) + $this->getAttribute($context["ecriture"], "tempsForceMin", array()));
                // line 132
                echo "                        ";
                $context["sectotal"] = ((isset($context["sectotal"]) ? $context["sectotal"] : null) + $this->getAttribute($context["ecriture"], "tempsForceSec", array()));
                // line 133
                echo "                        ";
                if (((isset($context["sectotal"]) ? $context["sectotal"] : null) > 59)) {
                    // line 134
                    echo "                            ";
                    $context["mintotal"] = ((isset($context["mintotal"]) ? $context["mintotal"] : null) + 1);
                    // line 135
                    echo "                            ";
                    $context["sectotal"] = ((isset($context["sectotal"]) ? $context["sectotal"] : null) - 60);
                    // line 136
                    echo "                        ";
                }
                // line 137
                echo "                    ";
            } else {
                // line 138
                echo "                        ";
                $context["mintotal"] = ((isset($context["mintotal"]) ? $context["mintotal"] : null) + (isset($context["min"]) ? $context["min"] : null));
                // line 139
                echo "                        ";
                $context["sectotal"] = ((isset($context["sectotal"]) ? $context["sectotal"] : null) + (isset($context["sec"]) ? $context["sec"] : null));
                // line 140
                echo "                        ";
                if (((isset($context["sectotal"]) ? $context["sectotal"] : null) > 59)) {
                    // line 141
                    echo "                            ";
                    $context["mintotal"] = ((isset($context["mintotal"]) ? $context["mintotal"] : null) + 1);
                    // line 142
                    echo "                            ";
                    $context["sectotal"] = ((isset($context["sectotal"]) ? $context["sectotal"] : null) - 60);
                    // line 143
                    echo "                        ";
                }
                // line 144
                echo "                    ";
            }
            // line 145
            echo "

                    <div class=\"ib\">
                        <div class=\"ib sub-txt-small\">Durée depuis le début :</div>
                        <div class=\"ib sub-txt-big\">";
            // line 149
            echo twig_escape_filter($this->env, (isset($context["mintotal"]) ? $context["mintotal"] : null), "html", null, true);
            echo "</div>
                        <div class=\"ib sub-txt-small\">min</div>
                        <div class=\"ib sub-txt-big\">";
            // line 151
            echo twig_escape_filter($this->env, (isset($context["sectotal"]) ? $context["sectotal"] : null), "html", null, true);
            echo "</div>
                        <div class=\"ib sub-txt-small bord-droit\">sec</div>
                    </div>

                    <div class=\"ib\">
                        <button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\" formmethod=\"post\" formaction=\"";
            // line 156
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "id", array()))), "html", null, true);
            echo "\">
                            <table class=\"ib tab-buttons-petit shadow back-script\">
                                <td>
                                    <div class=\"lightgrey\">Mettre à jour</div>
                                </td>
                                <td>
                                    <img src=\"";
            // line 162
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/refresh-button.png"), "html", null, true);
            echo "\" alt=\"Enregistrer\" height=\"19\">
                                </td>
                            </table>
                        </button>

                        <a href=\"";
            // line 167
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_delete", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "id", array()), "scriptEcriture" => $this->getAttribute($context["ecriture"], "id", array()))), "html", null, true);
            echo "\">


                                    <div class=\"script ib\" style=\"font-size: 0.8em\">Supprimer</div>

                                    <img src=\"";
            // line 172
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/delete.png"), "html", null, true);
            echo "\" alt=\"Enregistrer\" height=\"13\">


                        </a>
                    </div>
                </div>

            <div class=\"title-tab\"></div>



</div>
                <br>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['ecriture'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 186
        echo "
        <div class=\"largeur-totale txt-center ib\">

            <div class=\"ib\">
                <button class=\"btn-iconflat\" type=\"submit\" formmethod=\"post\" formaction=\"";
        // line 190
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_new", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "id", array()))), "html", null, true);
        echo "\" value=\"Enregistrer\">
                    <img class=\"imgflat\" src=\"";
        // line 191
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/add-plus-button.png"), "html", null, true);
        echo "\" alt=\"Ajouter une ligne de script\" height=\"14\">
                    <h2 class=\"ib script\">Ajouter une ligne de script</h2>
                    <img class=\"imgflat\" src=\"";
        // line 193
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pen-plume.png"), "html", null, true);
        echo "\" alt=\"Ajouter une ligne de script\" height=\"35\">
                </button>
            </div>

        </div>



    </form>
        <br>




<div class=\"largeur-totale script-footer\">
    <a target=\"_blank\" class=\"ib icontop\" href=\"";
        // line 208
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_print", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "id", array()))), "html", null, true);
        echo "\">
                <img src=\"";
        // line 209
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/print.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"30\">

    </a>
    <a class=\"ib icontop\" href=\"";
        // line 212
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_valid", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "id", array()))), "html", null, true);
        echo "\">
        <img src=\"";
        // line 213
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/envelope.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"30\">

    </a>
</div>
        </div>


    </td>
<td style=\"vertical-align: top; padding-right: 3%\">


<div class=\"largeur-totale padding-ten\">

    <h3 class=\"ib bord-droit script\">Vos réponses :</h3>
    ";
        // line 227
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["reponses"]) ? $context["reponses"] : null));
        foreach ($context['_seq'] as $context["key"] => $context["reponse"]) {
            // line 228
            echo "


        <div class=\"id sub-txt-small grey\">
            ";
            // line 232
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["reponse"], "question", array()), "question", array()), "html", null, true);
            echo "
        </div>



        <div class=\"id sub-txt-small script\">
            ";
            // line 238
            echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "reponse", array()), "html", null, true);
            echo "
        </div>

        <br>

        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['reponse'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 244
        echo "
    <div class=\"title-tab\"></div>



    <h3 class=\"ib bord-droit script\">Votre voix-off :</h3>


    ";
        // line 252
        $context["timing"] = ($this->getAttribute((isset($context["script"]) ? $context["script"] : null), "count", array()) / 2.5);
        // line 253
        echo "    ";
        $context["minround"] = ((isset($context["timing"]) ? $context["timing"] : null) / 60);
        // line 254
        echo "    ";
        $context["minvo"] = twig_round((isset($context["minround"]) ? $context["minround"] : null), 0, "floor");
        // line 255
        echo "    ";
        $context["secvo"] = ((isset($context["timing"]) ? $context["timing"] : null) % 60);
        // line 256
        echo "
    <div class=\"ib sub-txt-big grey\">";
        // line 257
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "count", array()), "html", null, true);
        echo "</div>
    <div class=\"ib sub-txt-small grey bord-droit\">mots</div>

    <div class=\"ib sub-txt-big grey\">";
        // line 260
        echo twig_escape_filter($this->env, (isset($context["minvo"]) ? $context["minvo"] : null), "html", null, true);
        echo "</div>
    <div class=\"ib sub-txt-small grey\">min</div>
    <div class=\"ib sub-txt-big grey\">";
        // line 262
        echo twig_escape_filter($this->env, (isset($context["secvo"]) ? $context["secvo"] : null), "html", null, true);
        echo "</div>
    <div class=\"ib sub-txt-small grey\">sec</div>


    ";
        // line 266
        $context["text"] = twig_split_filter($this->env, $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "voixoffGlobal", array()), "
");
        // line 267
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["text"]) ? $context["text"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["paragraph"]) {
            // line 268
            echo "    <p class=\"sub-txt-small script\">";
            echo twig_escape_filter($this->env, $context["paragraph"], "html", null, true);
            echo "</p>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['paragraph'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 270
        echo "
</div>
</td>

</table>

";
    }

    public function getTemplateName()
    {
        return ":scriptecriture:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  530 => 270,  521 => 268,  516 => 267,  513 => 266,  506 => 262,  501 => 260,  495 => 257,  492 => 256,  489 => 255,  486 => 254,  483 => 253,  481 => 252,  471 => 244,  459 => 238,  450 => 232,  444 => 228,  440 => 227,  423 => 213,  419 => 212,  413 => 209,  409 => 208,  391 => 193,  386 => 191,  382 => 190,  376 => 186,  356 => 172,  348 => 167,  340 => 162,  331 => 156,  323 => 151,  318 => 149,  312 => 145,  309 => 144,  306 => 143,  303 => 142,  300 => 141,  297 => 140,  294 => 139,  291 => 138,  288 => 137,  285 => 136,  282 => 135,  279 => 134,  276 => 133,  273 => 132,  270 => 131,  268 => 130,  257 => 126,  248 => 124,  240 => 119,  235 => 117,  227 => 112,  224 => 111,  221 => 110,  218 => 109,  215 => 108,  213 => 107,  199 => 100,  195 => 99,  182 => 93,  178 => 92,  166 => 86,  163 => 84,  157 => 80,  152 => 77,  149 => 75,  145 => 74,  140 => 71,  130 => 63,  126 => 62,  120 => 59,  116 => 58,  104 => 48,  101 => 47,  99 => 46,  94 => 43,  91 => 42,  76 => 29,  69 => 25,  62 => 21,  55 => 17,  48 => 13,  41 => 9,  36 => 7,  32 => 5,  29 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", ":scriptecriture:edit.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/scriptecriture/edit.html.twig");
    }
}
