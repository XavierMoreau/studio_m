<?php

/* :projet:edit.html.twig */
class __TwigTemplate_b40382e44dd0e0990bb6c5bec64df6a57aa1a2aedf7d0490b03494b0251a16e8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":projet:edit.html.twig", 1);
        $this->blocks = array(
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
            'right' => array($this, 'block_right'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_ariane($context, array $blocks = array())
    {
        // line 4
        echo "


";
    }

    // line 9
    public function block_left($context, array $blocks = array())
    {
        // line 10
        echo "<div class=\"ib leftprojet\">

<div class=\"leftprojet-top\">

        <div class=\"txt-center\">
            <div class=\"ib imground\">
                <img src=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/idea.png"), "html", null, true);
        echo "\" alt=\"Nouveau Projet\">
            </div>
            <div>
                <h3 class=\"ib hand\">Modifiez votre projet</h3>
            </div>

        </div>

</div>
    <div class=\"leftprojet-photo\">
        <img src=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pic5.jpg"), "html", null, true);
        echo "\" alt=\"Nouveau Projet\">
    </div>
    <div class=\"leftprojet-bottom\">
        <div class=\"fine petite\"> Créez votre projet, renseignez les types de supports, les types diffusions, les types d'utilisations.
                Vous pouvez aussi indiquer pour quand votre projet est prévu ainsi que sa surée dans le temps.
                Toutes ces données nous permettront de calculer les droits et le montant approximatif de votre projet.



            </div>
        </div>



</div>

";
    }

    // line 44
    public function block_right($context, array $blocks = array())
    {
        // line 45
        echo "
   <div class=\"ib rightprojet-new-edit\">



    ";
        // line 50
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : null), 'form_start');
        echo "
        ";
        // line 51
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : null), 'widget');
        echo "

<button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\">
    <table class=\"tab-buttons shadow back-projet\">
        <td>
            <div class=\"lightgrey\">Enregistrer</div>
        </td>
        <td>
         <img src=\"";
        // line 59
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/save-file-option.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"19\">
        </td>
    </table>
</button>






    ";
        // line 69
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : null), 'form_end');
        echo "



</div>



";
    }

    public function getTemplateName()
    {
        return ":projet:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  123 => 69,  110 => 59,  99 => 51,  95 => 50,  88 => 45,  85 => 44,  64 => 26,  51 => 16,  43 => 10,  40 => 9,  33 => 4,  30 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", ":projet:edit.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/projet/edit.html.twig");
    }
}
