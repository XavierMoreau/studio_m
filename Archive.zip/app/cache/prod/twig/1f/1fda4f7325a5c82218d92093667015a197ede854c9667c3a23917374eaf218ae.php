<?php

/* :projet:edit.html.twig */
class __TwigTemplate_b40382e44dd0e0990bb6c5bec64df6a57aa1a2aedf7d0490b03494b0251a16e8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":projet:edit.html.twig", 1);
        $this->blocks = array(
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
            'right' => array($this, 'block_right'),
            'aside' => array($this, 'block_aside'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_ariane($context, array $blocks = array())
    {
        // line 4
        echo "
    <div class=\"ariane grey\">
        <div class=\"ib fine\">PROJETS</div>
        <div class=\"ib fine petite\">Paramètres</div>
        <div class=\"ib padding-ten fine\">></div>
        <div class=\"ib fine\">SCRIPT</div>
        <div class=\"ib fine petite\">Guide</div>
        <div class=\"ib fine petite\">Voix-Off</div>
        <div class=\"ib fine petite\">Ecriture</div>
        <div class=\"ib padding-ten fine\">></div>
        <div class=\"ib fine\">STORYBOARD</div>
        <div class=\"ib fine petite\">Ecriture</div>

    </div>

";
    }

    // line 21
    public function block_left($context, array $blocks = array())
    {
        // line 22
        echo "
    <div class=\"ib largeur-un-quart  leftprojet-new-edit\">



        <div class=\"txt-center\">
            <div class=\"ib imground\">
                <img src=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/light-bulb.png"), "html", null, true);
        echo "\" alt=\"Nouveau Projet\">
            </div>


        </div>





    </div>

";
    }

    // line 43
    public function block_right($context, array $blocks = array())
    {
        // line 44
        echo "
   <div class=\"ib largeur-trois-quarts rightprojet-new-edit\">

    <table class=\"title-tab\">
        <td class=\"padding-ten projet hand\"><h3>Modifiez votre projet</h3></td>
    </table>

    ";
        // line 51
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : null), 'form_start');
        echo "
        ";
        // line 52
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : null), 'widget');
        echo "

<button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\">
    <table class=\"tab-buttons shadow back-projet\">
        <td>
            <div class=\"lightgrey\">Enregistrer</div>
        </td>
        <td>
         <img src=\"";
        // line 60
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/save-file-option.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"19\">
        </td>
    </table>
</button>






    ";
        // line 70
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : null), 'form_end');
        echo "







";
    }

    // line 81
    public function block_aside($context, array $blocks = array())
    {
        // line 82
        echo "


    <div class=\"largeur-totale txt-center\">
        <img class=\"imgflat\" src=\"";
        // line 86
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/file.png"), "html", null, true);
        echo "\" alt=\"Script\" height=\"50\"><h4 style=\"color: #ff5419\">Projet</h4>
    </div>




    <div class=\"largeur-totale left-menu actuel\">
        <a href=\"";
        // line 93
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "id", array()))), "html", null, true);
        echo "\">
            <img class=\"imgflat\" src=\"";
        // line 94
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/parameters.png"), "html", null, true);
        echo "\" alt=\"Voix-off\" height=\"30\">
            <div class=\"ib title-txt-petit projet\">Paramètres</div>
        </a>
    </div>

    <div class=\"largeur-totale txt-center padding-ten\">

        <div class=\"title-tab\">
        </div>
    </div>




    <div class=\"largeur-totale txt-center\">
        <img class=\"imgflat\" src=\"";
        // line 109
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pen.png"), "html", null, true);
        echo "\" alt=\"Script\" height=\"50\"><h4 style=\"color: #34495e\">Script</h4>
    </div>

    <div class=\"largeur-totale left-menu\">
        <a href=\"";
        // line 113
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "id", array()))), "html", null, true);
        echo "\">
            <img class=\"imgflat\" src=\"";
        // line 114
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/guide.png"), "html", null, true);
        echo "\" alt=\"Questionnaire\" height=\"30\">
            <div class=\"ib title-txt-petit script\">Questionnaire</div>
        </a>
    </div>

    <div class=\"largeur-totale left-menu\">
        <a href=\"";
        // line 120
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_voixoff", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "id", array()))), "html", null, true);
        echo "\">
            <img class=\"imgflat\" src=\"";
        // line 121
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/voixoff1.png"), "html", null, true);
        echo "\" alt=\"Voix-off\" height=\"30\">
            <div class=\"ib title-txt-petit script\">Voix-off</div>
        </a>
    </div>

    <div class=\"largeur-totale left-menu\">
        <a href=\"";
        // line 127
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "id", array()))), "html", null, true);
        echo "\">
            <img class=\"imgflat\" src=\"";
        // line 128
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pen-plume.png"), "html", null, true);
        echo "\" alt=\"Script\" height=\"30\">
            <div class=\"ib title-txt-petit script\">Script</div>
        </a>
    </div>





    <div class=\"largeur-totale txt-center padding-ten\">

        <br>
        <div class=\"title-tab\">
        </div>
    </div>

";
    }

    public function getTemplateName()
    {
        return ":projet:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  213 => 128,  209 => 127,  200 => 121,  196 => 120,  187 => 114,  183 => 113,  176 => 109,  158 => 94,  154 => 93,  144 => 86,  138 => 82,  135 => 81,  122 => 70,  109 => 60,  98 => 52,  94 => 51,  85 => 44,  82 => 43,  65 => 29,  56 => 22,  53 => 21,  34 => 4,  31 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", ":projet:edit.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/projet/edit.html.twig");
    }
}
