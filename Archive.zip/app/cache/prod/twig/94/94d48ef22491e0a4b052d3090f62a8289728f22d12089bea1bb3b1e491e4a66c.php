<?php

/* layout.html.twig */
class __TwigTemplate_f2fbd3e1d528f5e032f9436cccc8ba243cbc6330314617a70d30c4bd47f12755 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
            'right' => array($this, 'block_right'),
            'connection' => array($this, 'block_connection'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"fr\">
<head>
    <meta charset=\"UTF-8\">
    <title>
        Bump";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        // line 7
        echo "    </title>
    <link href=\"https://fonts.googleapis.com/css?family=News+Cycle\" rel=\"stylesheet\">
    <link href=\"https://fonts.googleapis.com/css?family=Gloria+Hallelujah|Yanone+Kaffeesatz:200\" rel=\"stylesheet\">
    <link rel=\"stylesheet\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/appli/css/main.css"), "html", null, true);
        echo "\" type=\"text/css\" media=\"all\" />
    ";
        // line 12
        echo "    <link rel=\"icon\" type=\"image/png\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/favicon.png"), "html", null, true);
        echo "\">
</head>
<body>


";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "session", array()), "flashBag", array()), "all", array()));
        foreach ($context['_seq'] as $context["type"] => $context["messages"]) {
            // line 18
            echo "    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["messages"]);
            foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                // line 19
                echo "        <div class=\"";
                echo twig_escape_filter($this->env, $context["type"], "html", null, true);
                echo "\">
            ";
                // line 20
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($context["message"], array(), "FOSUserBundle"), "html", null, true);
                echo "
        </div>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['type'], $context['messages'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "

";
        // line 26
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_USER")) {
            // line 27
            echo "    <header class=\"log\">


            <div class=\"menuleft\">
                <div class=\"headerlogo\">
                   <img src=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/bumplogo-white.png"), "html", null, true);
            echo "\" alt=\"Logo Bump\"></a>
                </div>
                <div class=\"ib sub-txt-small fine grey\">Bonjour</div><div class=\"ib fine lightgrey bord-droit\"> <a href=\"";
            // line 34
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_profile_show");
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "prenom", array()), "html", null, true);
            echo "</a> ! </div>
                ";
            // line 35
            if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_ADMIN")) {
                // line 36
                echo "                    <div class=\"ib fine bord-droit\"><a href=\"";
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_index");
                echo "\">Administration</a></div>
                ";
            }
            // line 38
            echo "                <div class=\" ib fine petite\"><a class=\"deconnexion\" href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_logout");
            echo "\">Déconnexion</a></div>



            </div>



            ";
            // line 46
            $this->displayBlock('ariane', $context, $blocks);
            // line 50
            echo "







    </header>

<main>


        ";
            // line 63
            $this->displayBlock('left', $context, $blocks);
            // line 65
            echo "


        ";
            // line 68
            $this->displayBlock('right', $context, $blocks);
            // line 70
            echo "




</main>



";
        } else {
            // line 80
            echo "    <header>
        <div class=\"headerlogo\">
            <img src=\"";
            // line 82
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/bumplogo.png"), "html", null, true);
            echo "\" alt=\"Logo Bump\">
        </div>
    </header>


    <main class=\"nolog\">
        ";
            // line 88
            $this->displayBlock('connection', $context, $blocks);
            // line 90
            echo "    </main>
";
        }
        // line 92
        echo "<footer>Copyright © 2017 Diaphonics <span>●</span> Studio Bump <span>●</span> Contact <span>●</span> Mentions Légales
</footer>

</body>



</html>
";
    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
    }

    // line 46
    public function block_ariane($context, array $blocks = array())
    {
        // line 47
        echo "

            ";
    }

    // line 63
    public function block_left($context, array $blocks = array())
    {
        // line 64
        echo "        ";
    }

    // line 68
    public function block_right($context, array $blocks = array())
    {
        // line 69
        echo "        ";
    }

    // line 88
    public function block_connection($context, array $blocks = array())
    {
        // line 89
        echo "        ";
    }

    public function getTemplateName()
    {
        return "layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  222 => 89,  219 => 88,  215 => 69,  212 => 68,  208 => 64,  205 => 63,  199 => 47,  196 => 46,  191 => 6,  179 => 92,  175 => 90,  173 => 88,  164 => 82,  160 => 80,  148 => 70,  146 => 68,  141 => 65,  139 => 63,  124 => 50,  122 => 46,  110 => 38,  104 => 36,  102 => 35,  96 => 34,  91 => 32,  84 => 27,  82 => 26,  78 => 24,  65 => 20,  60 => 19,  55 => 18,  51 => 17,  42 => 12,  38 => 10,  33 => 7,  31 => 6,  24 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "layout.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/layout.html.twig");
    }
}
