<?php

/* layout.html.twig */
class __TwigTemplate_f2fbd3e1d528f5e032f9436cccc8ba243cbc6330314617a70d30c4bd47f12755 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
            'right' => array($this, 'block_right'),
            'connection' => array($this, 'block_connection'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"fr\">
<head>
    <meta charset=\"UTF-8\">
    <title>
        Bump";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        // line 7
        echo "    </title>
    <link href=\"https://fonts.googleapis.com/css?family=News+Cycle\" rel=\"stylesheet\">
    <link href=\"https://fonts.googleapis.com/css?family=Gloria+Hallelujah|Yanone+Kaffeesatz:200\" rel=\"stylesheet\">
    <link rel=\"stylesheet\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/appli/css/main.css"), "html", null, true);
        echo "\" type=\"text/css\" media=\"all\" />
    ";
        // line 12
        echo "    <link rel=\"icon\" type=\"image/png\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/favicon.png"), "html", null, true);
        echo "\">
</head>
<body>


";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "session", array()), "flashBag", array()), "all", array()));
        foreach ($context['_seq'] as $context["type"] => $context["messages"]) {
            // line 18
            echo "    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["messages"]);
            foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                // line 19
                echo "        <div class=\"";
                echo twig_escape_filter($this->env, $context["type"], "html", null, true);
                echo "\">
            ";
                // line 20
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($context["message"], array(), "FOSUserBundle"), "html", null, true);
                echo "
        </div>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['type'], $context['messages'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "

";
        // line 26
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_USER")) {
            // line 27
            echo "    <header class=\"log\">
            <div class=\"menuleft\">
                <div class=\"headerlogo\">
                   <img src=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/bumplogo-white.png"), "html", null, true);
            echo "\" alt=\"Logo Bump\"></a>
                </div>
                <div class=\"ib sub-txt-small fine grey\">Bonjour</div><div class=\"ib fine lightgrey bord-droit\"> <a href=\"";
            // line 32
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_profile_show");
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "prenom", array()), "html", null, true);
            echo "</a> ! </div>
                ";
            // line 33
            if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_ADMIN")) {
                // line 34
                echo "                    <div class=\"ib fine bord-droit\"><a href=\"";
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_index");
                echo "\">Administration</a></div>
                ";
            }
            // line 36
            echo "                <div class=\" ib fine petite\"><a class=\"deconnexion\" href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_logout");
            echo "\">Déconnexion</a></div>



            </div>



            ";
            // line 44
            $this->displayBlock('ariane', $context, $blocks);
            // line 48
            echo "







    </header>

<main>


        ";
            // line 61
            $this->displayBlock('left', $context, $blocks);
            // line 63
            echo "


        ";
            // line 66
            $this->displayBlock('right', $context, $blocks);
            // line 68
            echo "




</main>



";
        } else {
            // line 78
            echo "    <header>
        <div class=\"headerlogo-nolog\">
            <img src=\"";
            // line 80
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/bumplogo-rouge.png"), "html", null, true);
            echo "\" alt=\"Logo Bump\">
        </div>
    </header>


    <main class=\"nolog\">
        ";
            // line 86
            $this->displayBlock('connection', $context, $blocks);
            // line 88
            echo "    </main>
";
        }
        // line 90
        echo "<footer>Copyright © 2017 Diaphonics <span>●</span> Studio Bump <span>●</span> Contact <span>●</span> Mentions Légales
</footer>

</body>



</html>
";
    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
    }

    // line 44
    public function block_ariane($context, array $blocks = array())
    {
        // line 45
        echo "

            ";
    }

    // line 61
    public function block_left($context, array $blocks = array())
    {
        // line 62
        echo "        ";
    }

    // line 66
    public function block_right($context, array $blocks = array())
    {
        // line 67
        echo "        ";
    }

    // line 86
    public function block_connection($context, array $blocks = array())
    {
        // line 87
        echo "        ";
    }

    public function getTemplateName()
    {
        return "layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  220 => 87,  217 => 86,  213 => 67,  210 => 66,  206 => 62,  203 => 61,  197 => 45,  194 => 44,  189 => 6,  177 => 90,  173 => 88,  171 => 86,  162 => 80,  158 => 78,  146 => 68,  144 => 66,  139 => 63,  137 => 61,  122 => 48,  120 => 44,  108 => 36,  102 => 34,  100 => 33,  94 => 32,  89 => 30,  84 => 27,  82 => 26,  78 => 24,  65 => 20,  60 => 19,  55 => 18,  51 => 17,  42 => 12,  38 => 10,  33 => 7,  31 => 6,  24 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "layout.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/layout.html.twig");
    }
}
