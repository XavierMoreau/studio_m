<?php

/* :scriptecriture:new.html.twig */
class __TwigTemplate_a2611b347c49aee7bf99dbe940f8dd6ca0c0e0eacc456a6869981ed622209099 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":scriptecriture:new.html.twig", 1);
        $this->blocks = array(
            'contentlarge' => array($this, 'block_contentlarge'),
            'aside' => array($this, 'block_aside'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_contentlarge($context, array $blocks = array())
    {
        // line 4
        echo "
";
        // line 8
        echo "
    ";
        // line 10
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["reponses"]) ? $context["reponses"] : null));
        foreach ($context['_seq'] as $context["key"] => $context["reponse"]) {
            // line 11
            echo "
    ";
            // line 13
            echo "    <form  method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "id", array()), "ecriture" => $this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "id", array()))), "html", null, true);
            echo "\">

        ";
            // line 16
            echo "        <input type=\"hidden\" name=\"0\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "id", array()), "html", null, true);
            echo "\">

<div style=\"width: 100%; border: solid 3px #34495e; border-radius: 10px\">


    <table style=\"width: 100%; background-color: #34495e;  font-weight: bold; text-align: center; color: white\">
    <td>Ligne de script n° ";
            // line 22
            echo twig_escape_filter($this->env, ($context["key"] + 1), "html", null, true);
            echo "</td>
    </table>
    <table class=\"table table-striped\">

        <thead class=\"tabhead scriptcolor\">
            <th>A la question :</th>
            <th>Vous avez répondu :</th>
            <th></th>
            <th></th>
        </thead>
        <tbody class=\"tabcells scriptcolor\">
            <td>";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["reponse"], "question", array()), "question", array()), "html", null, true);
            echo "</td>
            <td>";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "reponse", array()), "html", null, true);
            echo "</td>
            <td width=\"80\"><a href=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()))), "html", null, true);
            echo "\"><img class=\"imgflat\" src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/back.png"), "html", null, true);
            echo "\" alt=\"Retour\" height=\"40\"></a></td>
            <td width=\"100\"><a href=\"";
            // line 36
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()))), "html", null, true);
            echo "\"><h5 style=\"color: #d97077\">Retour aux questions</h5></a></td>
        </tbody>
    </table>
    <table class=\"table table-striped\">
        <thead>
            <th style=\"color: palevioletred; font-size: 20px\">Saisissez la voix-off ici : <img src=\"";
            // line 41
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/arrowpink.png"), "html", null, true);
            echo "\" width=\"60\"></th>
            <th style=\"color: #5BDB7F; font-size: 20px; text-align: right\"><img src=\"";
            // line 42
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/arrowgreen.png"), "html", null, true);
            echo "\" width=\"60\">Saisissez la description ici :</th>
            <th style=\"color: #4c8ab0; font-size: 20px; text-align: right\" colspan=\"2\">Et la durée ici : <img src=\"";
            // line 43
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/arrowblue.png"), "html", null, true);
            echo "\" width=\"40\"></th>
        </thead>

        <tbody>
        <tr>
            ";
            // line 49
            echo "            <td rowspan=\"2\"><label for=\"voixoff";
            echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "id", array()), "html", null, true);
            echo "\"></label>
                <textarea  rows=\"8\" class=\"form-control\" name=\"1\" >";
            // line 50
            if ($this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "voixoff", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "voixoff", array()), "html", null, true);
            }
            echo "</textarea></td>
            <td rowspan=\"2\"><label for=\"description";
            // line 51
            echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "id", array()), "html", null, true);
            echo "\"></label>
                <textarea  rows=\"8\" class=\"form-control\" name=\"2\" >";
            // line 52
            if ($this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "description", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "description", array()), "html", null, true);
            }
            echo "</textarea></td>
            <td width=\"100\"><label for=\"timeMin";
            // line 53
            echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "id", array()), "html", null, true);
            echo "\">Min : </label><br>
                <input type=\"number\" min=\"0\" max=\"59\" step=\"1\" class=\"form-control\" name=\"3\" value=\"";
            // line 54
            if ($this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "tempsForceMin", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "tempsForceMin", array()), "html", null, true);
            }
            echo "\"></td>
            <td width=\"100\"><label for=\"timeSec";
            // line 55
            echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "id", array()), "html", null, true);
            echo "\">Sec :</label><br>
                <input type=\"number\" min=\"0\" max=\"59\" step=\"1\" class=\"form-control\" name=\"4\" value=\"";
            // line 56
            if ($this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "tempsForceSec", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "tempsForceSec", array()), "html", null, true);
            }
            echo "\"></td>


        <tr>
             <td colspan=\"2\" style=\"text-align: center\">
                 <button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\">
                     <img class=\"imgflat\" src=\"";
            // line 62
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/save.png"), "html", null, true);
            echo "\" alt=\"Enregistrer\" height=\"40\"><h4 style=\"color: #ff8e31\">Enregistrer</h4></button>
             </td>

        </tr>

        </tbody>


    </table>


        </div>
        </form>



        <br>
        <br>

        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['reponse'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 82
        echo "<hr>


    <table style=\"width: 100%;\">
        <td style=\"width: 49%; text-align: center;\">

                <a href=\"";
        // line 88
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()))), "html", null, true);
        echo "\">
                    <img class=\"imgflat\" src=\"";
        // line 89
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/back.png"), "html", null, true);
        echo "\" alt=\"Retour\" height=\"70\"><h4 style=\"color: #d97077\">Retour</h4></a>


        </td>
        <td style=\"width: 49%; text-align: center;\">
            ";
        // line 95
        echo "
            ";
        // line 97
        echo "            ";
        $context["valid"] = 1;
        // line 98
        echo "
            ";
        // line 100
        echo "            ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["reponses"]) ? $context["reponses"] : null));
        foreach ($context['_seq'] as $context["key"] => $context["reponse"]) {
            // line 101
            echo "                ";
            if (((isset($context["valid"]) ? $context["valid"] : null) == 0)) {
                // line 102
                echo "                    ";
                $context["valid"] = 0;
                // line 103
                echo "                ";
            } else {
                // line 104
                echo "                    ";
                if (($this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "voixoff", array()) && $this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "description", array()))) {
                    // line 105
                    echo "                        ";
                    $context["valid"] = 1;
                    // line 106
                    echo "                    ";
                } else {
                    // line 107
                    echo "                        ";
                    $context["valid"] = 0;
                    // line 108
                    echo "                    ";
                }
                // line 109
                echo "                ";
            }
            // line 110
            echo "            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['reponse'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 111
        echo "
            ";
        // line 113
        echo "            ";
        if (((isset($context["valid"]) ? $context["valid"] : null) == 0)) {
            // line 114
            echo "
               <div style=\"position: relative;\">
                <img style=\"opacity: 0.5\" class=\"imgflat\" src=\"";
            // line 116
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pen.png"), "html", null, true);
            echo "\" alt=\"Enregistrer\" height=\"70\"><h4 style=\"color: #34495e;opacity: 0.5;\">Continuer</h4>
               <h4 style=\"position: absolute;top : 30px; width: 100%; color: #34495e\">Remplissez tous les champs</h4>
               </div>
                ";
            // line 120
            echo "            ";
        } else {
            // line 121
            echo "
                <a href=\"";
            // line 122
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_valid", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "id", array()))), "html", null, true);
            echo "\">
                    <img class=\"imgflat\" src=\"";
            // line 123
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pen.png"), "html", null, true);
            echo "\" alt=\"Enregistrer\" height=\"70\"><h4 style=\"color: #34495e\">Continuer</h4></a>

            ";
        }
        // line 126
        echo "        </td>

    </table>




";
    }

    // line 138
    public function block_aside($context, array $blocks = array())
    {
        // line 139
        echo "




    ";
        // line 144
        $context["min"] = 0;
        // line 145
        echo "    ";
        $context["sec"] = 0;
        // line 146
        echo "
    ";
        // line 148
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["reponses"]) ? $context["reponses"] : null));
        foreach ($context['_seq'] as $context["key"] => $context["reponse"]) {
            // line 149
            echo "
        ";
            // line 150
            $context["sec"] = ((isset($context["sec"]) ? $context["sec"] : null) + $this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "tempsForceSec", array()));
            // line 151
            echo "        ";
            if (((isset($context["sec"]) ? $context["sec"] : null) > 59)) {
                // line 152
                echo "            ";
                $context["min"] = ((isset($context["min"]) ? $context["min"] : null) + 1);
                // line 153
                echo "            ";
                $context["sec"] = 0;
                // line 154
                echo "        ";
            }
            // line 155
            echo "        ";
            $context["min"] = ((isset($context["min"]) ? $context["min"] : null) + $this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "tempsForceMin", array()));
            // line 156
            echo "
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['reponse'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 158
        echo "

    <div style=\"width: 100%; margin-left: 15px; text-align: center\">


        <div style=\"width: 100%; text-align: center\">
            <img class=\"imgflat\" src=\"";
        // line 164
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pen.png"), "html", null, true);
        echo "\" alt=\"Script\" height=\"100\"><h3 style=\"color: #34495e\">Script</h3>
        </div>
<br>
<br>
<br>

        <table style=\"width: 85%; background-color: #d3d3d3\">
            <thead>
            <tr>
                <th style=\"width: 20%;\"></th>
                <th style=\"text-align: center\" colspan=\"4\">Durée totale :</th>
                <th style=\"width: 20%;\"></th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td></td>
                <td><h1>";
        // line 181
        echo twig_escape_filter($this->env, (isset($context["min"]) ? $context["min"] : null), "html", null, true);
        echo "</h1></td>
                <td><h5> min</h5></td>
                <td><h1>";
        // line 183
        echo twig_escape_filter($this->env, (isset($context["sec"]) ? $context["sec"] : null), "html", null, true);
        echo "</h1></td>
                <td><h5> sec</h5></td>
                <td></td>
            </tr>
            </tbody>
        </table>
        
    </div>


";
    }

    public function getTemplateName()
    {
        return ":scriptecriture:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  379 => 183,  374 => 181,  354 => 164,  346 => 158,  339 => 156,  336 => 155,  333 => 154,  330 => 153,  327 => 152,  324 => 151,  322 => 150,  319 => 149,  314 => 148,  311 => 146,  308 => 145,  306 => 144,  299 => 139,  296 => 138,  285 => 126,  279 => 123,  275 => 122,  272 => 121,  269 => 120,  263 => 116,  259 => 114,  256 => 113,  253 => 111,  247 => 110,  244 => 109,  241 => 108,  238 => 107,  235 => 106,  232 => 105,  229 => 104,  226 => 103,  223 => 102,  220 => 101,  215 => 100,  212 => 98,  209 => 97,  206 => 95,  198 => 89,  194 => 88,  186 => 82,  160 => 62,  149 => 56,  145 => 55,  139 => 54,  135 => 53,  129 => 52,  125 => 51,  119 => 50,  114 => 49,  106 => 43,  102 => 42,  98 => 41,  90 => 36,  84 => 35,  80 => 34,  76 => 33,  62 => 22,  52 => 16,  46 => 13,  43 => 11,  38 => 10,  35 => 8,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", ":scriptecriture:new.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/scriptecriture/new.html.twig");
    }
}
