<?php

/* :script:edit.html.twig */
class __TwigTemplate_490337adcda8d6c802751c001878d3a4fb47c8f31d2aa7c8aa50af3dfff1b36b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":script:edit.html.twig", 1);
        $this->blocks = array(
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
            'right' => array($this, 'block_right'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_ariane($context, array $blocks = array())
    {
        // line 5
        echo "
     <div class=\"ariane grey\">
         <div class=\"ib sub-txt-small fine grey\">Projet en cours : </div><div class=\"ib fine lightgrey bord-droit\"> ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "nomProjet", array()), "html", null, true);
        echo "</div>

         <a href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine\">PROJETS</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Paramètres</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <a href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_orientation", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine\">SCRIPT</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Guide</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_voixoff", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Voix-Off</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Ecriture</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <div class=\"ib fine\">STORYBOARD</div>
         <div class=\"ib fine\">></div>
         <div class=\"ib fine petite\">Ecriture</div>

     </div>

 ";
    }

    // line 41
    public function block_left($context, array $blocks = array())
    {
        // line 42
        echo "

<div class=\"ib largeur-trois-quarts\">


<table class=\"title-tab\">
        <td class=\"padding-ten script-questions\"><h3>Afin d'écrire votre script, répondez aux questions suivantes</h3></td>
    </table>




    <form>


        ";
        // line 57
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["reponses"]) ? $context["reponses"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["reponse"]) {
            // line 58
            echo "
        <div class=\"padding-ten\">
            <div class=\"largeur-totale title-txt-petit script-questions\">";
            // line 60
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["reponse"], "question", array()), "question", array()), "html", null, true);
            echo "</div>

                <label for=\"";
            // line 62
            echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "id", array()), "html", null, true);
            echo "\"></label><br>
                <textarea placeholder=\"Entrez votre réponse...\" rows=\"6\" class=\"questionnaire\" name=\"";
            // line 63
            echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "reponse", array()), "html", null, true);
            echo "</textarea>


            </div>


        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['reponse'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 70
        echo "

        <div class=\"largeur-totale txt-center ib\">
            <button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\" formmethod=\"post\" formaction=\"";
        // line 73
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_reponses_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">
                <table class=\"tab-buttons shadow back-questions\">
                    <td>
                        <div class=\"lightgrey\">Enregistrer</div>
                    </td>
                    <td>
                        <img src=\"";
        // line 79
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/save-file-option.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"19\">
                    </td>
                </table>
            </button>
        </div>


    </form>

</div>

";
    }

    // line 94
    public function block_right($context, array $blocks = array())
    {
        // line 95
        echo "

    <div class=\"ib largeur-un-quart txt-center\">
        ";
        // line 99
        echo "


            ";
        // line 103
        echo "
        ";
        // line 105
        echo "            ";
        // line 106
        echo "        ";
        // line 107
        echo "
    ";
        // line 109
        echo "


    <a href=\"";
        // line 112
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_voixoff", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">

        <div class=\"ib script-questionnaire-voixoff-box shadow\">
            <div class=\"ib\">
                <img src=\"";
        // line 116
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/microphone.png"), "html", null, true);
        echo "\" alt=\"Script\" height=\"30\">
            </div>
            <div>
                <h3 class=\"ib hand petite\">Ecrire la voix-off -></h3>
            </div>
            <div class=\"ib txtround2 fine\">
                <h4 class=\"script-voixoff\">2</h4>
            </div>
        </div>
    </a>


</div>
";
    }

    public function getTemplateName()
    {
        return ":script:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  209 => 116,  202 => 112,  197 => 109,  194 => 107,  192 => 106,  190 => 105,  187 => 103,  182 => 99,  177 => 95,  174 => 94,  158 => 79,  149 => 73,  144 => 70,  129 => 63,  125 => 62,  120 => 60,  116 => 58,  112 => 57,  95 => 42,  92 => 41,  77 => 29,  70 => 25,  63 => 21,  56 => 17,  49 => 13,  42 => 9,  37 => 7,  33 => 5,  30 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", ":script:edit.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/script/edit.html.twig");
    }
}
