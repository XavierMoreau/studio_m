<?php

/* :conseiltype:index.html.twig */
class __TwigTemplate_8482fcbe2547598f41062103d89712472e151f24830ecf826c1721456fad64c3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":conseiltype:index.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <h1>Types de conseil</h1>

    <table class=\"table table-striped\">
        <thead>
            <tr>
                <th>Types proposés :</th>
                <th><a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("experttype_index");
        echo "\">Métiers : </a></th>
                <th></th>
            </tr>
        </thead>
        <tbody>

        ";
        // line 16
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["conseilTypes"]) ? $context["conseilTypes"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["conseilType"]) {
            // line 17
            echo "
              <tr>

                <td>";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["conseilType"], "type", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["conseilType"], "expertType", array()), "type", array()), "html", null, true);
            echo "</td>
                <td><a class=\"btn-modifier\" href=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("conseiltype_edit", array("id" => $this->getAttribute($context["conseilType"], "id", array()))), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-edit\" aria-hidden=\"true\"></span></a></td>
                <td><a class=\"btn-delete\" href=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("conseiltype_delete", array("id" => $this->getAttribute($context["conseilType"], "id", array()))), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-trash\" aria-hidden=\"true\"></span></a></td>


            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['conseilType'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 28
        echo "        </tbody>
    </table>

    <a class=\"btn btn-primary\" href=\"";
        // line 31
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("conseiltype_new");
        echo "\">Nouveau</a>

    <a class=\"btn btn-default\" href=\"";
        // line 33
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_index");
        echo "\">Retour</a>




";
    }

    public function getTemplateName()
    {
        return ":conseiltype:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 33,  85 => 31,  80 => 28,  69 => 23,  65 => 22,  61 => 21,  57 => 20,  52 => 17,  48 => 16,  39 => 10,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", ":conseiltype:index.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/conseiltype/index.html.twig");
    }
}
