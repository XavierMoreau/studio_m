<?php

/* FOSUserBundle:Profile:show_content.html.twig */
class __TwigTemplate_b2822d08093030aceb14b1c009f8daa1795668cefcae3ef62e5b69f2b36313fa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "
<div>
    <dl class=\"dl-horizontal\">
        <dt>Nom d'utilisateur</dt>
        <dd>";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : null), "username", array()), "html", null, true);
        echo "</dd>
    </dl>


    <dl class=\"dl-horizontal\">
        <dt>Nom</dt>
        <dd>";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : null), "nom", array()), "html", null, true);
        echo "</dd>
        <dt>Prénom</dt>
        <dd>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : null), "prenom", array()), "html", null, true);
        echo "</dd>
        <dt>Société</dt>
        <dd>";
        // line 16
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : null), "societe", array()), "html", null, true);
        echo "</dd>
        <dt>Poste</dt>
        <dd>";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : null), "poste", array()), "html", null, true);
        echo "</dd>
        <dt>Téléphone</dt>
        <dd>";
        // line 20
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : null), "telephone", array()), "html", null, true);
        echo "</dd>
        <dt>E-mail</dt>
        <dd>";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : null), "email", array()), "html", null, true);
        echo "</dd>
    </dl>


    <dl class=\"dl-horizontal\">
        <dt>Expert métier</dt>
        <dd>";
        // line 28
        if (($this->getAttribute((isset($context["user"]) ? $context["user"] : null), "userExpert", array()) == 1)) {
            echo " Oui ";
        } else {
            echo " Non ";
        }
        echo "</dd>
        <dt>Comédien audio</dt>
        <dd>";
        // line 30
        if (($this->getAttribute((isset($context["user"]) ? $context["user"] : null), "userVoix", array()) == 1)) {
            echo " Oui ";
        } else {
            echo " Non ";
        }
        echo "</dd>
        <dt>Dessinateur</dt>
        <dd>";
        // line 32
        if (($this->getAttribute((isset($context["user"]) ? $context["user"] : null), "userContributeur", array()) == 1)) {
            echo " Oui ";
        } else {
            echo " Non ";
        }
        echo "</dd>
    </dl>

    <dl class=\"dl-horizontal\">
        <dt>Membre depuis le</dt>
        <dd>";
        // line 37
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : null), "dateCreation", array()), "d-m-Y"), "html", null, true);
        echo "</dd>
    </dl>
</div>

<div style=\"text-align: right; width : 210px\">
    <a class=\"btn btn-default\" href=\"";
        // line 42
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_profile_edit");
        echo "\">Modifier</a>
</div>
";
    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:show_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  106 => 42,  98 => 37,  86 => 32,  77 => 30,  68 => 28,  59 => 22,  54 => 20,  49 => 18,  44 => 16,  39 => 14,  34 => 12,  25 => 6,  19 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "FOSUserBundle:Profile:show_content.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/src/UserBundle/Resources/views/Profile/show_content.html.twig");
    }
}
