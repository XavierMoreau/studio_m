<?php

/* :script:orientation.html.twig */
class __TwigTemplate_fc3ab49930ad1fb104d87961693f8c1320a752d135585bd278d5179b28ba85d0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":script:orientation.html.twig", 1);
        $this->blocks = array(
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_ariane($context, array $blocks = array())
    {
        // line 4
        echo "
     <div class=\"ib ariane grey\">
         <div>
            <div class=\"ib sub-txt-small fine grey\">Projet en cours : </div>
             <div class=\"ib fine lightgrey\"> ";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "nomProjet", array()), "html", null, true);
        echo "</div>
         </div>
         <div class=\"ib\">
             <a href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine\">PROJETS</div>
            </a>
             <div class=\"ib fine\">></div>
             <a href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : null), "id", array()))), "html", null, true);
        echo "\">
                 <div class=\"ib fine petite\">Paramètres</div>
             </a>
         </div>
             <div class=\"ib\">
             <div class=\"ib chevron fine\">></div>
             <a href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_orientation", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">
                 <div class=\"ib fine\">SCRIPT</div>
             </a>
             <div class=\"ib fine\">></div>
             <a href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">
                 <div class=\"ib fine petite\">Guide</div>
             </a>
             <div class=\"ib fine\">></div>
             <a href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_voixoff", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">
                 <div class=\"ib fine petite\">Voix-Off</div>
             </a>
             <div class=\"ib fine\">></div>
             <a href=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">
                 <div class=\"ib fine petite\">Ecriture</div>
             </a>
         </div>
         <div class=\"ib\">
             <div class=\"ib chevron fine\">></div>
             <div class=\"ib fine\">STORYBOARD</div>
             <div class=\"ib fine\">></div>
             <div class=\"ib fine petite\">Ecriture</div>
         </div>
     </div>


 ";
    }

    // line 50
    public function block_left($context, array $blocks = array())
    {
        // line 51
        echo "

<div class=\"largeur-totale txt-center\">




    <table class=\"title-tab\">
        <td class=\"padding-ten hand lightgrey\"><h3>Pour écrire votre script, vous souhaitez :</h3></td>
    </table>

    <table class=\"script-orientation-box\">
    <tr>
            <td class=\"largeur-tiers back-questions\">

                <a href=\"";
        // line 66
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">

                <div class=\"ib txtround1 fine\">
                    <h4 class=\"script-questions\">1</h4>
                </div>

                <div>
                    <h3 class=\"ib hand\">Répondre aux questions</h3>
                </div>
                <div class=\"ib imground\">

                    <img src=\"";
        // line 77
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/list.png"), "html", null, true);
        echo "\" alt=\"Script\">
                </div>
                </a>
        <div class=\"img-orientation\">
            <img src=\"";
        // line 81
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pic6.jpg"), "html", null, true);
        echo "\" alt=\"Retour\">
        </div>
            </td>
            <td class=\"largeur-tiers back-voixoff\">

                <a href=\"";
        // line 86
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_voixoff", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">

                <div class=\"ib txtround2 fine\">
                    <h4 class=\"script-voixoff\">2</h4>
                </div>

                <div>
                    <h3 class=\"ib hand\">Ecrire la voix-off</h3>
                </div>
                <div class=\"ib imground\">
                    <img src=\"";
        // line 96
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/microphone.png"), "html", null, true);
        echo "\" alt=\"Script\" >
                </div>
                </a>
        <div class=\"img-orientation\">
            <img src=\"";
        // line 100
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pic9.jpg"), "html", null, true);
        echo "\" alt=\"Retour\">
        </div>

        </td>

            <td class=\"largeur-tiers back-script\">

                <a href=\"";
        // line 107
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : null), "script", array()), "id", array()))), "html", null, true);
        echo "\">

                <div class=\"ib txtround3 fine\">
                    <h4 class=\"script\">3</h4>
                </div>
                <div>
                    <h3 class=\"ib hand\">Ecrire le script</h3>
                </div>
                <div class=\"ib imground\">
                    <img src=\"";
        // line 116
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pencil.png"), "html", null, true);
        echo "\" alt=\"Retour\">
                </div>
                </a>
                <div class=\"img-orientation\">
                    <img src=\"";
        // line 120
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pic4.jpg"), "html", null, true);
        echo "\" alt=\"Retour\">
                </div>

            </td>
        </tr>


        <tr>

            <td class=\"largeur-tiers orientation-text back-questions fine petite\"> Vous ne maitisez pas l'écriture de script ? Répondez à ces quelques questions qui vous guideront pour la rédaction du script correspondant à votre projet.
            </td>

            <td class=\"largeur-tiers orientation-text back-voixoff fine petite\"> Ecrivez votre voix-off d'un seul bloc et contrôlez la durée estimée en fonction du nombre de mots.
            </td>

            <td class=\"largeur-tiers orientation-text back-script fine petite\"> Ecrivez votre script et votre voix-off en parallèle. Maitrisez le durées des séquences à votre guise.
            </td>
        </tr>


    </table>



</div>





";
    }

    public function getTemplateName()
    {
        return ":script:orientation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  197 => 120,  190 => 116,  178 => 107,  168 => 100,  161 => 96,  148 => 86,  140 => 81,  133 => 77,  119 => 66,  102 => 51,  99 => 50,  81 => 33,  74 => 29,  67 => 25,  60 => 21,  51 => 15,  44 => 11,  38 => 8,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", ":script:orientation.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/script/orientation.html.twig");
    }
}
