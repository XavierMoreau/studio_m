<?php

/* AppliBundle:admin:admin.html.twig */
class __TwigTemplate_26cd9ffd5bedab821b973d15379db2c0f041be6c191bfc30b3f088c44baf806c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "AppliBundle:admin:admin.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 6
    public function block_content($context, array $blocks = array())
    {
        // line 7
        echo "
<div style=\"text-align: center\">

    <table width=\"498\" style=\"text-align: center\">
        <tr>
            <td width=\"498\" style=\"text-align: center\" colspan=\"2\"><h2>Administration</h2></td>

        </tr>
        <tr>
            <td height=\"40\"></td>
            <td></td>
        </tr>
        <tr>
            <td width=\"150\"><a class=\"btn btn-primary\" href=\"";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("users_index");
        echo "\">Utilisateurs</a></td>
            <td width=\"150\"><a class=\"btn btn-danger\" style=\"width: 100px\" href=\"";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projets_index");
        echo "\">Projets</a></td>
        </tr>


    </table>
    <br>
    <hr>
    <br>

    <table width=\"498\" style=\"text-align: center\">
        <thead>
        <th colspan=\"3\" style=\"text-align: center\">
            <b>Questionnaire de création de projet</b>
        </th>
        </thead>
        <tbody>
        <tr>
            <td height=\"10\"></td>
        </tr>
        <tr>
            <td width=\"100\"><a class=\"btn btn-success\" href=\"";
        // line 41
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("utilisation_index");
        echo "\">Utilisations</a></td>
            <td width=\"100\"><a class=\"btn btn-info\" href=\"";
        // line 42
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("support_index");
        echo "\">Supports</a></td>
            <td width=\"100\"><a class=\"btn btn-warning\" href=\"";
        // line 43
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("diffusion_index");
        echo "\">Diffusions</a></td>
        </tr>
        </tbody>
    </table>

    <br>
    <hr>
    <br>

    <table width=\"498\" style=\"text-align: center\">
        <thead>
        <th colspan=\"3\" style=\"text-align: center\">
            <b>Questionnaire de création de script</b>
        </th>
        </thead>
        <tbody>
        <tr>
            <td height=\"10\"></td>
        </tr>
        <tr>
            <td width=\"300\"><a class=\"btn btn-success\" href=\"";
        // line 63
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptquestion_index");
        echo "\">Questions</a></td>
        </tr>
        </tbody>
    </table>

    <br>
    <hr>
    <br>

    <table width=\"498\" style=\"text-align: center\">
        <thead>
        <th colspan=\"3\" style=\"text-align: center\">
            <b>Expertises et conseils</b>
        </th>
        </thead>
        <tbody>
        <tr>
            <td height=\"10\"></td>
        </tr>
        <tr>
            <td width=\"300\"><a class=\"btn btn-success\" href=\"";
        // line 83
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("experttype_index");
        echo "\">Métiers</a></td>
            <td width=\"300\"><a class=\"btn btn-success\" href=\"";
        // line 84
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("conseiltype_index");
        echo "\">Conseils</a></td>
        </tr>
        </tbody>
    </table>


</div>





";
    }

    public function getTemplateName()
    {
        return "AppliBundle:admin:admin.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  131 => 84,  127 => 83,  104 => 63,  81 => 43,  77 => 42,  73 => 41,  50 => 21,  46 => 20,  31 => 7,  28 => 6,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "AppliBundle:admin:admin.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/src/AppliBundle/Resources/views/admin/admin.html.twig");
    }
}
