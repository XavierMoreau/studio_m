<?php

/* :projet:new.html.twig */
class __TwigTemplate_afe098f3800dc1e727aadb3d3ea9f99ac04a8e4d161ec83af6c6f1d835d36e15 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":projet:new.html.twig", 1);
        $this->blocks = array(
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
            'right' => array($this, 'block_right'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_ariane($context, array $blocks = array())
    {
        // line 4
        echo "


";
    }

    // line 9
    public function block_left($context, array $blocks = array())
    {
        // line 10
        echo "
    <div class=\"ib leftprojet\">

        <div class=\"leftprojet-top\">

                <div class=\"txt-center\">
                    <div class=\"ib imground\">
                        <img src=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/idea.png"), "html", null, true);
        echo "\" alt=\"Nouveau Projet\">
                    </div>
                    <div>
                        <h3 class=\"ib hand\">Votre nouveau projet</h3>
                    </div>

                </div>

        </div>
        <div class=\"leftprojet-photo\">
            <img src=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pic5.jpg"), "html", null, true);
        echo "\" alt=\"Nouveau Projet\">
        </div>
        <div class=\"leftprojet-bottom\">
            <div class=\"fine petite\"> Créez votre projet, renseignez les types de supports, les types diffusions, les types d'utilisations.
                Vous pouvez aussi indiquer pour quand votre projet est prévu ainsi que sa surée dans le temps.
                Toutes ces données nous permettront de calculer les droits et le montant approximatif de votre projet.



            </div>
        </div>



    </div>

";
    }

    // line 45
    public function block_right($context, array $blocks = array())
    {
        // line 46
        echo "<div class=\"ib rightprojet-new-edit\">





    ";
        // line 52
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_start');
        echo "
        ";
        // line 53
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : null), 'widget');
        echo "

    <button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\">
        <table class=\"tab-buttons shadow back-projet\">
            <td>
                <div class=\"lightgrey\">Enregistrer</div>
            </td>
            <td>
                <img src=\"";
        // line 61
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/save-file-option.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"19\">
            </td>
        </table>
    </button>



    ";
        // line 68
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_end');
        echo "

</div>

";
    }

    public function getTemplateName()
    {
        return ":projet:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  122 => 68,  112 => 61,  101 => 53,  97 => 52,  89 => 46,  86 => 45,  65 => 27,  52 => 17,  43 => 10,  40 => 9,  33 => 4,  30 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", ":projet:new.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/projet/new.html.twig");
    }
}
