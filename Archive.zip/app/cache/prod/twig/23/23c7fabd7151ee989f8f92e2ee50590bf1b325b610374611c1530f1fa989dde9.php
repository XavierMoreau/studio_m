<?php

/* :projet:new.html.twig */
class __TwigTemplate_afe098f3800dc1e727aadb3d3ea9f99ac04a8e4d161ec83af6c6f1d835d36e15 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":projet:new.html.twig", 1);
        $this->blocks = array(
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
            'right' => array($this, 'block_right'),
            'aside' => array($this, 'block_aside'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_ariane($context, array $blocks = array())
    {
        // line 4
        echo "
    <div class=\"ariane grey\">
        <div class=\"ib fine\">PROJETS</div>
        <div class=\"ib fine petite\">Paramètres</div>
        <div class=\"ib padding-ten fine\">></div>
        <div class=\"ib fine\">SCRIPT</div>
        <div class=\"ib fine petite\">Guide</div>
        <div class=\"ib fine petite\">Voix-Off</div>
        <div class=\"ib fine petite\">Ecriture</div>
        <div class=\"ib padding-ten fine\">></div>
        <div class=\"ib fine\">STORYBOARD</div>
        <div class=\"ib fine petite\">Ecriture</div>

    </div>

";
    }

    // line 21
    public function block_left($context, array $blocks = array())
    {
        // line 22
        echo "
    <div class=\"ib largeur-un-quart  leftprojet-new-edit\">



            <div class=\"txt-center\">
                <div class=\"ib imground\">
                    <img src=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/light-bulb.png"), "html", null, true);
        echo "\" alt=\"Nouveau Projet\">
                </div>


            </div>





    </div>

";
    }

    // line 43
    public function block_right($context, array $blocks = array())
    {
        // line 44
        echo "<div class=\"ib largeur-trois-quarts rightprojet-new-edit\">

    <table class=\"title-tab\">
        <td class=\"padding-ten projet hand\"><h3>Nouveau projet</h3></td>
    </table>



    ";
        // line 52
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_start');
        echo "
        ";
        // line 53
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : null), 'widget');
        echo "

    <button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\">
        <table class=\"tab-buttons shadow back-projet\">
            <td>
                <div class=\"lightgrey\">Enregistrer</div>
            </td>
            <td>
                <img src=\"";
        // line 61
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/save-file-option.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"19\">
            </td>
        </table>
    </button>



    ";
        // line 68
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_end');
        echo "



";
    }

    // line 77
    public function block_aside($context, array $blocks = array())
    {
        // line 78
        echo "
    <div class=\"largeur-totale txt-center\">
        <img class=\"imgflat\" src=\"";
        // line 80
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/file.png"), "html", null, true);
        echo "\" alt=\"Script\" height=\"50\"><h4 style=\"color: #ff5419\">Projet</h4>
    </div>




    <div class=\"largeur-totale left-menu actuel\">

            <img class=\"imgflat\" src=\"";
        // line 88
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/parameters.png"), "html", null, true);
        echo "\" alt=\"Voix-off\" height=\"30\">
            <div class=\"ib title-txt-petit projet\">Paramètres</div>
        </a>
    </div>

    <div class=\"largeur-totale txt-center padding-ten\">

        <div class=\"title-tab\">
        </div>
    </div>




<div>
";
    }

    public function getTemplateName()
    {
        return ":projet:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  147 => 88,  136 => 80,  132 => 78,  129 => 77,  120 => 68,  110 => 61,  99 => 53,  95 => 52,  85 => 44,  82 => 43,  65 => 29,  56 => 22,  53 => 21,  34 => 4,  31 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", ":projet:new.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/projet/new.html.twig");
    }
}
