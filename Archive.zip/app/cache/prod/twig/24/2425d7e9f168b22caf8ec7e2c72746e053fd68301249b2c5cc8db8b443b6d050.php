<?php

/* AppliBundle:Default:index.html.twig */
class __TwigTemplate_8fa470596bcc3a37d1d27dcb10b1a40b83055fc14f2ced7bb73d90f44b285271 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "AppliBundle:Default:index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'contentlarge' => array($this, 'block_contentlarge'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
    }

    // line 9
    public function block_contentlarge($context, array $blocks = array())
    {
        // line 10
        echo "    ";
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_USER")) {
            // line 11
            echo "



    <table style=\"text-align: center; width: 100%\">
        <tr>
            <td width=\"167\"><a href=\"";
            // line 17
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_new", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()))), "html", null, true);
            echo "\"><img class=\"imgflat\" src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/file.png"), "html", null, true);
            echo "\" alt=\"Nouveau projets\" height=\"150\"><h3 style=\"color: #ff5419\">Nouveau Projet</h3></a></td>
            <td width=\"167\"><a href=\"";
            // line 18
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_profile_show");
            echo "\"><img class=\"imgflat\" src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/astronaut.png"), "html", null, true);
            echo "\" alt=\"Projets\" height=\"150\"><h3 style=\"color: #386895\">Profil</h3></a></td>

        </tr>
        <tr>
            <td width=\"167\"><a href=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "user", array()), "id", array()))), "html", null, true);
            echo "\"><img class=\"imgflat\" src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/projection.png"), "html", null, true);
            echo "\" alt=\"Projets\" height=\"150\"><h3 style=\"color: #4AB8A1\">Projets</h3></a></td>

                  <td width=\"167\"><a href=\"";
            // line 24
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_logout");
            echo "\"><img class=\"imgflat\" src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/logout.png"), "html", null, true);
            echo "\" alt=\"Projets\" height=\"150\"><h3 style=\"color: #FABC3D\">Déconnection</h3></a></td>
        </tr>

    </table>
";
        }
        // line 29
        echo "



";
    }

    public function getTemplateName()
    {
        return "AppliBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 29,  70 => 24,  63 => 22,  54 => 18,  48 => 17,  40 => 11,  37 => 10,  34 => 9,  29 => 7,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "AppliBundle:Default:index.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/src/AppliBundle/Resources/views/Default/index.html.twig");
    }
}
