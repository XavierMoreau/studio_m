<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appDevDebugProjectContainerUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if (rtrim($pathinfo, '/') === '/_profiler') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_profiler_home');
                    }

                    return array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                }

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ($pathinfo === '/_profiler/search') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ($pathinfo === '/_profiler/search_bar') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_purge
                if ($pathinfo === '/_profiler/purge') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:purgeAction',  '_route' => '_profiler_purge',);
                }

                // _profiler_info
                if (0 === strpos($pathinfo, '/_profiler/info') && preg_match('#^/_profiler/info/(?P<about>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_info')), array (  '_controller' => 'web_profiler.controller.profiler:infoAction',));
                }

                // _profiler_phpinfo
                if ($pathinfo === '/_profiler/phpinfo') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        if (0 === strpos($pathinfo, '/admin')) {
            // admin_index
            if ($pathinfo === '/admin') {
                return array (  '_controller' => 'AppliBundle\\Controller\\AdminController::adminAction',  '_route' => 'admin_index',);
            }

            // users_index
            if ($pathinfo === '/admin/users') {
                return array (  '_controller' => 'AppliBundle\\Controller\\AdminController::listeAction',  '_route' => 'users_index',);
            }

            // projets_index
            if ($pathinfo === '/admin/projets') {
                return array (  '_controller' => 'AppliBundle\\Controller\\AdminController::projetsAction',  '_route' => 'projets_index',);
            }

        }

        // index
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'index');
            }

            return array (  '_controller' => 'AppliBundle\\Controller\\DefaultController::indexAction',  '_route' => 'index',);
        }

        // unauthorized
        if ($pathinfo === '/unauth') {
            return array (  '_controller' => 'AppliBundle\\Controller\\DefaultController::unauthAction',  '_route' => 'unauthorized',);
        }

        // expert_control
        if ($pathinfo === '/expert') {
            return array (  '_controller' => 'AppliBundle\\Controller\\DefaultController::expertAction',  '_route' => 'expert_control',);
        }

        // contributeur_control
        if ($pathinfo === '/contributeur') {
            return array (  '_controller' => 'AppliBundle\\Controller\\DefaultController::contributeurAction',  '_route' => 'contributeur_control',);
        }

        if (0 === strpos($pathinfo, '/projet')) {
            // projet_index
            if (preg_match('#^/projet/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_projet_index;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'projet_index')), array (  '_controller' => 'AppliBundle\\Controller\\ProjetController::indexAction',));
            }
            not_projet_index:

            // projet_new
            if (preg_match('#^/projet/(?P<id>[^/]++)/new$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                    goto not_projet_new;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'projet_new')), array (  '_controller' => 'AppliBundle\\Controller\\ProjetController::newAction',));
            }
            not_projet_new:

            // projet_edit
            if (0 === strpos($pathinfo, '/projet/edit/user') && preg_match('#^/projet/edit/user\\=(?P<id>[^/]++)/projet\\=(?P<projet>[^/]++)/script\\=(?P<script>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                    goto not_projet_edit;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'projet_edit')), array (  '_controller' => 'AppliBundle\\Controller\\ProjetController::editAction',));
            }
            not_projet_edit:

            // projet_delete
            if (0 === strpos($pathinfo, '/projet/delete') && preg_match('#^/projet/delete/(?P<id>[^/]++)/(?P<projet>[^/]++)/(?P<script>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('DELETE', 'GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('DELETE', 'GET', 'HEAD'));
                    goto not_projet_delete;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'projet_delete')), array (  '_controller' => 'AppliBundle\\Controller\\ProjetController::deleteAction',));
            }
            not_projet_delete:

        }

        if (0 === strpos($pathinfo, '/script')) {
            // script_orientation
            if (0 === strpos($pathinfo, '/script/orientation/user') && preg_match('#^/script/orientation/user\\=(?P<id>[^/]++)/projet\\=(?P<projet>[^/]++)/script\\=(?P<script>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                    goto not_script_orientation;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'script_orientation')), array (  '_controller' => 'AppliBundle\\Controller\\ScriptController::orientationAction',));
            }
            not_script_orientation:

            if (0 === strpos($pathinfo, '/script/voixoff')) {
                // script_voixoff
                if (0 === strpos($pathinfo, '/script/voixoff/user') && preg_match('#^/script/voixoff/user\\=(?P<id>[^/]++)/projet\\=(?P<projet>[^/]++)/script\\=(?P<script>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_script_voixoff;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'script_voixoff')), array (  '_controller' => 'AppliBundle\\Controller\\ScriptController::voixoffAction',));
                }
                not_script_voixoff:

                // script_voixoff_edit
                if (0 === strpos($pathinfo, '/script/voixoffedit/user') && preg_match('#^/script/voixoffedit/user\\=(?P<id>[^/]++)/projet\\=(?P<projet>[^/]++)/script\\=(?P<script>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_script_voixoff_edit;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'script_voixoff_edit')), array (  '_controller' => 'AppliBundle\\Controller\\ScriptController::voixoffEditAction',));
                }
                not_script_voixoff_edit:

            }

            // script_questions
            if (0 === strpos($pathinfo, '/script/questions/user') && preg_match('#^/script/questions/user\\=(?P<id>[^/]++)/projet\\=(?P<projet>[^/]++)/script\\=(?P<script>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                    goto not_script_questions;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'script_questions')), array (  '_controller' => 'AppliBundle\\Controller\\ScriptController::questionsAction',));
            }
            not_script_questions:

            // script_reponses_edit
            if (0 === strpos($pathinfo, '/script/reponsesedit/user') && preg_match('#^/script/reponsesedit/user\\=(?P<id>[^/]++)/projet\\=(?P<projet>[^/]++)/script\\=(?P<script>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                    goto not_script_reponses_edit;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'script_reponses_edit')), array (  '_controller' => 'AppliBundle\\Controller\\ScriptController::reponsesEditAction',));
            }
            not_script_reponses_edit:

            // script_valid
            if (0 === strpos($pathinfo, '/script/valid/user') && preg_match('#^/script/valid/user\\=(?P<id>[^/]++)/projet\\=(?P<projet>[^/]++)/script\\=(?P<script>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_script_valid;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'script_valid')), array (  '_controller' => 'AppliBundle\\Controller\\ScriptController::validAction',));
            }
            not_script_valid:

            // script_print
            if (0 === strpos($pathinfo, '/script/print/user') && preg_match('#^/script/print/user\\=(?P<id>[^/]++)/projet\\=(?P<projet>[^/]++)/script\\=(?P<script>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                    goto not_script_print;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'script_print')), array (  '_controller' => 'AppliBundle\\Controller\\ScriptController::printAction',));
            }
            not_script_print:

            if (0 === strpos($pathinfo, '/scriptecriture')) {
                // scriptecriture_index
                if (0 === strpos($pathinfo, '/scriptecriture/user') && preg_match('#^/scriptecriture/user\\=(?P<id>[^/]++)/projet\\=(?P<projet>[^/]++)/script\\=(?P<script>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_scriptecriture_index;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'scriptecriture_index')), array (  '_controller' => 'AppliBundle\\Controller\\ScriptEcritureController::indexAction',));
                }
                not_scriptecriture_index:

                // scriptecriture_new
                if (0 === strpos($pathinfo, '/scriptecriture/new/user') && preg_match('#^/scriptecriture/new/user\\=(?P<id>[^/]++)/projet\\=(?P<projet>[^/]++)/script\\=(?P<script>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_scriptecriture_new;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'scriptecriture_new')), array (  '_controller' => 'AppliBundle\\Controller\\ScriptEcritureController::newAction',));
                }
                not_scriptecriture_new:

                if (0 === strpos($pathinfo, '/scriptecriture/edit/user')) {
                    // scriptecriture_edit
                    if (preg_match('#^/scriptecriture/edit/user\\=(?P<id>[^/]++)/projet\\=(?P<projet>[^/]++)/script\\=(?P<script>[^/]++)$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                            goto not_scriptecriture_edit;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'scriptecriture_edit')), array (  '_controller' => 'AppliBundle\\Controller\\ScriptEcritureController::editAction',));
                    }
                    not_scriptecriture_edit:

                    // scriptecriture_save
                    if (preg_match('#^/scriptecriture/edit/user\\=(?P<id>[^/]++)/projet\\=(?P<projet>[^/]++)/script\\=(?P<script>[^/]++)$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                            goto not_scriptecriture_save;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'scriptecriture_save')), array (  '_controller' => 'AppliBundle\\Controller\\ScriptEcritureController::saveAction',));
                    }
                    not_scriptecriture_save:

                }

                // scriptecriture_delete
                if (0 === strpos($pathinfo, '/scriptecriture/delete/user') && preg_match('#^/scriptecriture/delete/user\\=(?P<id>[^/]++)/projet\\=(?P<projet>[^/]++)/script\\=(?P<script>[^/]++)/scritpEcriture\\=(?P<scriptEcriture>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('DELETE', 'GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('DELETE', 'GET', 'HEAD'));
                        goto not_scriptecriture_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'scriptecriture_delete')), array (  '_controller' => 'AppliBundle\\Controller\\ScriptEcritureController::deleteAction',));
                }
                not_scriptecriture_delete:

            }

            if (0 === strpos($pathinfo, '/scriptreponse')) {
                // scriptreponse_index
                if (rtrim($pathinfo, '/') === '/scriptreponse') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_scriptreponse_index;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'scriptreponse_index');
                    }

                    return array (  '_controller' => 'AppliBundle\\Controller\\ScriptReponseController::indexAction',  '_route' => 'scriptreponse_index',);
                }
                not_scriptreponse_index:

                // scriptreponse_new
                if (0 === strpos($pathinfo, '/scriptreponse/user') && preg_match('#^/scriptreponse/user\\=(?P<id>[^/]++)/projet\\=(?P<projet>[^/]++)/script\\=(?P<script>[^/]++)/new$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_scriptreponse_new;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'scriptreponse_new')), array (  '_controller' => 'AppliBundle\\Controller\\ScriptReponseController::newAction',));
                }
                not_scriptreponse_new:

                // scriptreponse_show
                if (preg_match('#^/scriptreponse/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_scriptreponse_show;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'scriptreponse_show')), array (  '_controller' => 'AppliBundle\\Controller\\ScriptReponseController::showAction',));
                }
                not_scriptreponse_show:

                // scriptreponse_edit
                if (preg_match('#^/scriptreponse/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_scriptreponse_edit;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'scriptreponse_edit')), array (  '_controller' => 'AppliBundle\\Controller\\ScriptReponseController::editAction',));
                }
                not_scriptreponse_edit:

                // scriptreponse_delete
                if (preg_match('#^/scriptreponse/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'DELETE') {
                        $allow[] = 'DELETE';
                        goto not_scriptreponse_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'scriptreponse_delete')), array (  '_controller' => 'AppliBundle\\Controller\\ScriptReponseController::deleteAction',));
                }
                not_scriptreponse_delete:

            }

        }

        if (0 === strpos($pathinfo, '/conseil')) {
            // conseil_index
            if (rtrim($pathinfo, '/') === '/conseil') {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_conseil_index;
                }

                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'conseil_index');
                }

                return array (  '_controller' => 'AppliBundle\\Controller\\conseilController::indexAction',  '_route' => 'conseil_index',);
            }
            not_conseil_index:

            // conseil_new
            if ($pathinfo === '/conseil/new') {
                if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                    goto not_conseil_new;
                }

                return array (  '_controller' => 'AppliBundle\\Controller\\conseilController::newAction',  '_route' => 'conseil_new',);
            }
            not_conseil_new:

            // conseil_show
            if (preg_match('#^/conseil/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_conseil_show;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'conseil_show')), array (  '_controller' => 'AppliBundle\\Controller\\conseilController::showAction',));
            }
            not_conseil_show:

            // conseil_edit
            if (preg_match('#^/conseil/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                    goto not_conseil_edit;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'conseil_edit')), array (  '_controller' => 'AppliBundle\\Controller\\conseilController::editAction',));
            }
            not_conseil_edit:

            // conseil_delete
            if (preg_match('#^/conseil/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                if ($this->context->getMethod() != 'DELETE') {
                    $allow[] = 'DELETE';
                    goto not_conseil_delete;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'conseil_delete')), array (  '_controller' => 'AppliBundle\\Controller\\conseilController::deleteAction',));
            }
            not_conseil_delete:

        }

        // user_default_index
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'user_default_index');
            }

            return array (  '_controller' => 'UserBundle\\Controller\\DefaultController::indexAction',  '_route' => 'user_default_index',);
        }

        if (0 === strpos($pathinfo, '/log')) {
            if (0 === strpos($pathinfo, '/login')) {
                // fos_user_security_login
                if ($pathinfo === '/login') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_fos_user_security_login;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::loginAction',  '_route' => 'fos_user_security_login',);
                }
                not_fos_user_security_login:

                // fos_user_security_check
                if ($pathinfo === '/login_check') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_fos_user_security_check;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::checkAction',  '_route' => 'fos_user_security_check',);
                }
                not_fos_user_security_check:

            }

            // fos_user_security_logout
            if ($pathinfo === '/logout') {
                if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                    goto not_fos_user_security_logout;
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::logoutAction',  '_route' => 'fos_user_security_logout',);
            }
            not_fos_user_security_logout:

        }

        if (0 === strpos($pathinfo, '/profile')) {
            // fos_user_profile_show
            if (rtrim($pathinfo, '/') === '/profile') {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_fos_user_profile_show;
                }

                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'fos_user_profile_show');
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ProfileController::showAction',  '_route' => 'fos_user_profile_show',);
            }
            not_fos_user_profile_show:

            // fos_user_profile_edit
            if ($pathinfo === '/profile/edit') {
                if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                    goto not_fos_user_profile_edit;
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ProfileController::editAction',  '_route' => 'fos_user_profile_edit',);
            }
            not_fos_user_profile_edit:

        }

        if (0 === strpos($pathinfo, '/re')) {
            if (0 === strpos($pathinfo, '/register')) {
                // fos_user_registration_register
                if (rtrim($pathinfo, '/') === '/register') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_fos_user_registration_register;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'fos_user_registration_register');
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::registerAction',  '_route' => 'fos_user_registration_register',);
                }
                not_fos_user_registration_register:

                if (0 === strpos($pathinfo, '/register/c')) {
                    // fos_user_registration_check_email
                    if ($pathinfo === '/register/check-email') {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_fos_user_registration_check_email;
                        }

                        return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::checkEmailAction',  '_route' => 'fos_user_registration_check_email',);
                    }
                    not_fos_user_registration_check_email:

                    if (0 === strpos($pathinfo, '/register/confirm')) {
                        // fos_user_registration_confirm
                        if (preg_match('#^/register/confirm/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                                $allow = array_merge($allow, array('GET', 'HEAD'));
                                goto not_fos_user_registration_confirm;
                            }

                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'fos_user_registration_confirm')), array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::confirmAction',));
                        }
                        not_fos_user_registration_confirm:

                        // fos_user_registration_confirmed
                        if ($pathinfo === '/register/confirmed') {
                            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                                $allow = array_merge($allow, array('GET', 'HEAD'));
                                goto not_fos_user_registration_confirmed;
                            }

                            return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::confirmedAction',  '_route' => 'fos_user_registration_confirmed',);
                        }
                        not_fos_user_registration_confirmed:

                    }

                }

            }

            if (0 === strpos($pathinfo, '/resetting')) {
                // fos_user_resetting_request
                if ($pathinfo === '/resetting/request') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_fos_user_resetting_request;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::requestAction',  '_route' => 'fos_user_resetting_request',);
                }
                not_fos_user_resetting_request:

                // fos_user_resetting_send_email
                if ($pathinfo === '/resetting/send-email') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_fos_user_resetting_send_email;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::sendEmailAction',  '_route' => 'fos_user_resetting_send_email',);
                }
                not_fos_user_resetting_send_email:

                // fos_user_resetting_check_email
                if ($pathinfo === '/resetting/check-email') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_fos_user_resetting_check_email;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::checkEmailAction',  '_route' => 'fos_user_resetting_check_email',);
                }
                not_fos_user_resetting_check_email:

                // fos_user_resetting_reset
                if (0 === strpos($pathinfo, '/resetting/reset') && preg_match('#^/resetting/reset/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_fos_user_resetting_reset;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'fos_user_resetting_reset')), array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::resetAction',));
                }
                not_fos_user_resetting_reset:

            }

        }

        // fos_user_change_password
        if ($pathinfo === '/change-password/change-password') {
            if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                goto not_fos_user_change_password;
            }

            return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ChangePasswordController::changePasswordAction',  '_route' => 'fos_user_change_password',);
        }
        not_fos_user_change_password:

        if (0 === strpos($pathinfo, '/admin')) {
            if (0 === strpos($pathinfo, '/admin/utilisation')) {
                // utilisation_index
                if (rtrim($pathinfo, '/') === '/admin/utilisation') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_utilisation_index;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'utilisation_index');
                    }

                    return array (  '_controller' => 'AppliBundle\\Controller\\UtilisationController::indexAction',  '_route' => 'utilisation_index',);
                }
                not_utilisation_index:

                // utilisation_new
                if ($pathinfo === '/admin/utilisation/new') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_utilisation_new;
                    }

                    return array (  '_controller' => 'AppliBundle\\Controller\\UtilisationController::newAction',  '_route' => 'utilisation_new',);
                }
                not_utilisation_new:

                // utilisation_show
                if (preg_match('#^/admin/utilisation/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_utilisation_show;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'utilisation_show')), array (  '_controller' => 'AppliBundle\\Controller\\UtilisationController::showAction',));
                }
                not_utilisation_show:

                // utilisation_edit
                if (preg_match('#^/admin/utilisation/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_utilisation_edit;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'utilisation_edit')), array (  '_controller' => 'AppliBundle\\Controller\\UtilisationController::editAction',));
                }
                not_utilisation_edit:

                // utilisation_delete
                if (0 === strpos($pathinfo, '/admin/utilisation/delete') && preg_match('#^/admin/utilisation/delete/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('DELETE', 'GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('DELETE', 'GET', 'HEAD'));
                        goto not_utilisation_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'utilisation_delete')), array (  '_controller' => 'AppliBundle\\Controller\\UtilisationController::deleteAction',));
                }
                not_utilisation_delete:

            }

            if (0 === strpos($pathinfo, '/admin/support')) {
                // support_index
                if (rtrim($pathinfo, '/') === '/admin/support') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_support_index;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'support_index');
                    }

                    return array (  '_controller' => 'AppliBundle\\Controller\\SupportController::indexAction',  '_route' => 'support_index',);
                }
                not_support_index:

                // support_new
                if ($pathinfo === '/admin/support/new') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_support_new;
                    }

                    return array (  '_controller' => 'AppliBundle\\Controller\\SupportController::newAction',  '_route' => 'support_new',);
                }
                not_support_new:

                // support_show
                if (preg_match('#^/admin/support/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_support_show;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'support_show')), array (  '_controller' => 'AppliBundle\\Controller\\SupportController::showAction',));
                }
                not_support_show:

                // support_edit
                if (preg_match('#^/admin/support/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_support_edit;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'support_edit')), array (  '_controller' => 'AppliBundle\\Controller\\SupportController::editAction',));
                }
                not_support_edit:

                // support_delete
                if (0 === strpos($pathinfo, '/admin/support/delete') && preg_match('#^/admin/support/delete/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('DELETE', 'GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('DELETE', 'GET', 'HEAD'));
                        goto not_support_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'support_delete')), array (  '_controller' => 'AppliBundle\\Controller\\SupportController::deleteAction',));
                }
                not_support_delete:

            }

            if (0 === strpos($pathinfo, '/admin/diffusion')) {
                // diffusion_index
                if (rtrim($pathinfo, '/') === '/admin/diffusion') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_diffusion_index;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'diffusion_index');
                    }

                    return array (  '_controller' => 'AppliBundle\\Controller\\DiffusionController::indexAction',  '_route' => 'diffusion_index',);
                }
                not_diffusion_index:

                // diffusion_new
                if ($pathinfo === '/admin/diffusion/new') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_diffusion_new;
                    }

                    return array (  '_controller' => 'AppliBundle\\Controller\\DiffusionController::newAction',  '_route' => 'diffusion_new',);
                }
                not_diffusion_new:

                // diffusion_show
                if (preg_match('#^/admin/diffusion/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_diffusion_show;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'diffusion_show')), array (  '_controller' => 'AppliBundle\\Controller\\DiffusionController::showAction',));
                }
                not_diffusion_show:

                // diffusion_edit
                if (preg_match('#^/admin/diffusion/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_diffusion_edit;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'diffusion_edit')), array (  '_controller' => 'AppliBundle\\Controller\\DiffusionController::editAction',));
                }
                not_diffusion_edit:

                // diffusion_delete
                if (0 === strpos($pathinfo, '/admin/diffusion/delete') && preg_match('#^/admin/diffusion/delete/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('DELETE', 'GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('DELETE', 'GET', 'HEAD'));
                        goto not_diffusion_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'diffusion_delete')), array (  '_controller' => 'AppliBundle\\Controller\\DiffusionController::deleteAction',));
                }
                not_diffusion_delete:

            }

            if (0 === strpos($pathinfo, '/admin/scriptquestion')) {
                // scriptquestion_index
                if (rtrim($pathinfo, '/') === '/admin/scriptquestion') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_scriptquestion_index;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'scriptquestion_index');
                    }

                    return array (  '_controller' => 'AppliBundle\\Controller\\ScriptQuestionController::indexAction',  '_route' => 'scriptquestion_index',);
                }
                not_scriptquestion_index:

                // scriptquestion_new
                if (rtrim($pathinfo, '/') === '/admin/scriptquestion') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_scriptquestion_new;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'scriptquestion_new');
                    }

                    return array (  '_controller' => 'AppliBundle\\Controller\\ScriptQuestionController::newAction',  '_route' => 'scriptquestion_new',);
                }
                not_scriptquestion_new:

                // scriptquestion_show
                if (preg_match('#^/admin/scriptquestion/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_scriptquestion_show;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'scriptquestion_show')), array (  '_controller' => 'AppliBundle\\Controller\\ScriptQuestionController::showAction',));
                }
                not_scriptquestion_show:

                // scriptquestion_edit
                if (preg_match('#^/admin/scriptquestion/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_scriptquestion_edit;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'scriptquestion_edit')), array (  '_controller' => 'AppliBundle\\Controller\\ScriptQuestionController::editAction',));
                }
                not_scriptquestion_edit:

                // scriptquestion_delete
                if (0 === strpos($pathinfo, '/admin/scriptquestion/delete') && preg_match('#^/admin/scriptquestion/delete/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('DELETE', 'GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('DELETE', 'GET', 'HEAD'));
                        goto not_scriptquestion_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'scriptquestion_delete')), array (  '_controller' => 'AppliBundle\\Controller\\ScriptQuestionController::deleteAction',));
                }
                not_scriptquestion_delete:

            }

            if (0 === strpos($pathinfo, '/admin/experttype')) {
                // experttype_index
                if (rtrim($pathinfo, '/') === '/admin/experttype') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_experttype_index;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'experttype_index');
                    }

                    return array (  '_controller' => 'AppliBundle\\Controller\\expertTypeController::indexAction',  '_route' => 'experttype_index',);
                }
                not_experttype_index:

                // experttype_new
                if ($pathinfo === '/admin/experttype/new') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_experttype_new;
                    }

                    return array (  '_controller' => 'AppliBundle\\Controller\\expertTypeController::newAction',  '_route' => 'experttype_new',);
                }
                not_experttype_new:

                // experttype_show
                if (preg_match('#^/admin/experttype/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_experttype_show;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'experttype_show')), array (  '_controller' => 'AppliBundle\\Controller\\expertTypeController::showAction',));
                }
                not_experttype_show:

                // experttype_edit
                if (preg_match('#^/admin/experttype/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_experttype_edit;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'experttype_edit')), array (  '_controller' => 'AppliBundle\\Controller\\expertTypeController::editAction',));
                }
                not_experttype_edit:

                // experttype_delete
                if (0 === strpos($pathinfo, '/admin/experttype/delete') && preg_match('#^/admin/experttype/delete/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('DELETE', 'GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('DELETE', 'GET', 'HEAD'));
                        goto not_experttype_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'experttype_delete')), array (  '_controller' => 'AppliBundle\\Controller\\expertTypeController::deleteAction',));
                }
                not_experttype_delete:

            }

            if (0 === strpos($pathinfo, '/admin/conseiltype')) {
                // conseiltype_index
                if (rtrim($pathinfo, '/') === '/admin/conseiltype') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_conseiltype_index;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'conseiltype_index');
                    }

                    return array (  '_controller' => 'AppliBundle\\Controller\\conseilTypeController::indexAction',  '_route' => 'conseiltype_index',);
                }
                not_conseiltype_index:

                // conseiltype_new
                if ($pathinfo === '/admin/conseiltype/new') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_conseiltype_new;
                    }

                    return array (  '_controller' => 'AppliBundle\\Controller\\conseilTypeController::newAction',  '_route' => 'conseiltype_new',);
                }
                not_conseiltype_new:

                // conseiltype_show
                if (preg_match('#^/admin/conseiltype/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_conseiltype_show;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'conseiltype_show')), array (  '_controller' => 'AppliBundle\\Controller\\conseilTypeController::showAction',));
                }
                not_conseiltype_show:

                // conseiltype_edit
                if (preg_match('#^/admin/conseiltype/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_conseiltype_edit;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'conseiltype_edit')), array (  '_controller' => 'AppliBundle\\Controller\\conseilTypeController::editAction',));
                }
                not_conseiltype_edit:

                // conseiltype_delete
                if (0 === strpos($pathinfo, '/admin/conseiltype/delete') && preg_match('#^/admin/conseiltype/delete/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('DELETE', 'GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('DELETE', 'GET', 'HEAD'));
                        goto not_conseiltype_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'conseiltype_delete')), array (  '_controller' => 'AppliBundle\\Controller\\conseilTypeController::deleteAction',));
                }
                not_conseiltype_delete:

            }

        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
