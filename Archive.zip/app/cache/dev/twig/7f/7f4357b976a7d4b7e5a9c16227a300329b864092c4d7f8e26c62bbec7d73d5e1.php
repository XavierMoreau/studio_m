<?php

/* AppliBundle:admin:userslist.html.twig */
class __TwigTemplate_ea703e563ec2f9e987b78929ae4d86fc95aa7214d172d5b5114d1d7879797f6c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "AppliBundle:admin:userslist.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f4c96e892d20240d87f0e7cbf5a59d267ee737400032c43c1c926910cc806b6b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f4c96e892d20240d87f0e7cbf5a59d267ee737400032c43c1c926910cc806b6b->enter($__internal_f4c96e892d20240d87f0e7cbf5a59d267ee737400032c43c1c926910cc806b6b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppliBundle:admin:userslist.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f4c96e892d20240d87f0e7cbf5a59d267ee737400032c43c1c926910cc806b6b->leave($__internal_f4c96e892d20240d87f0e7cbf5a59d267ee737400032c43c1c926910cc806b6b_prof);

    }

    // line 4
    public function block_content($context, array $blocks = array())
    {
        $__internal_a37a568346f1a2b9d4fd30a45caa0dd81b75c3169d833b74b9fb33ca32a4bef6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a37a568346f1a2b9d4fd30a45caa0dd81b75c3169d833b74b9fb33ca32a4bef6->enter($__internal_a37a568346f1a2b9d4fd30a45caa0dd81b75c3169d833b74b9fb33ca32a4bef6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 5
        echo "
    ";
        // line 7
        echo "

";
        
        $__internal_a37a568346f1a2b9d4fd30a45caa0dd81b75c3169d833b74b9fb33ca32a4bef6->leave($__internal_a37a568346f1a2b9d4fd30a45caa0dd81b75c3169d833b74b9fb33ca32a4bef6_prof);

    }

    // line 12
    public function block_body($context, array $blocks = array())
    {
        $__internal_7f083e310db6a06ddeac9f1d13ff2705b24f9d987f3d59a62d55e7b842ff4ad8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7f083e310db6a06ddeac9f1d13ff2705b24f9d987f3d59a62d55e7b842ff4ad8->enter($__internal_7f083e310db6a06ddeac9f1d13ff2705b24f9d987f3d59a62d55e7b842ff4ad8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 13
        echo "

    <h1>Utilisateurs</h1>

    <table class=\"table table-striped\">
        <thead>
        <tr>
            <th>N°</th>
            <th>Nom d'utilisateur</th>
            <th>Civilité</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Societé</th>
            <th>Poste</th>
            <th>Téléphone</th>
            <th>E-mail</th>
            <th>Inscrit depuis le</th>
            <th>Dernière connexion</th>
            <th>Expert métier</th>
            <th>Comédien Audio</th>
            <th>Dessinateur</th>

        </tr>
        </thead>
        <tbody>
        ";
        // line 38
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["users"]) ? $context["users"] : $this->getContext($context, "users")));
        foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
            // line 39
            echo "            <tr>
                <td>";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "id", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "username", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "civilite", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "nom", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "prenom", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 45
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "societe", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 46
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "poste", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 47
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "telephone", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute($context["user"], "email", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 49
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["user"], "dateCreation", array()), "d/m/Y"), "html", null, true);
            echo "</td>
                <td>";
            // line 50
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["user"], "lastLogin", array()), "d/m/Y \\à\\ H:i"), "html", null, true);
            echo "</td>
                <td>";
            // line 51
            if (($this->getAttribute($context["user"], "userExpert", array()) == true)) {
                echo "Oui";
            } else {
                echo "Non";
            }
            echo "</td>
                <td>";
            // line 52
            if (($this->getAttribute($context["user"], "userVoix", array()) == true)) {
                echo "Oui";
            } else {
                echo "Non";
            }
            echo "</td>
                <td>";
            // line 53
            if (($this->getAttribute($context["user"], "userContributeur", array()) == true)) {
                echo "Oui";
            } else {
                echo "Non";
            }
            echo "</td>



            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 59
        echo "        </tbody>
    </table>
";
        
        $__internal_7f083e310db6a06ddeac9f1d13ff2705b24f9d987f3d59a62d55e7b842ff4ad8->leave($__internal_7f083e310db6a06ddeac9f1d13ff2705b24f9d987f3d59a62d55e7b842ff4ad8_prof);

    }

    public function getTemplateName()
    {
        return "AppliBundle:admin:userslist.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  169 => 59,  153 => 53,  145 => 52,  137 => 51,  133 => 50,  129 => 49,  125 => 48,  121 => 47,  117 => 46,  113 => 45,  109 => 44,  105 => 43,  101 => 42,  97 => 41,  93 => 40,  90 => 39,  86 => 38,  59 => 13,  53 => 12,  44 => 7,  41 => 5,  35 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block content %}

    {#<a class=\"btn btn-default\" href=\"{{ path('admin_index') }}\">Administration</a>#}


{% endblock %}


{% block body %}


    <h1>Utilisateurs</h1>

    <table class=\"table table-striped\">
        <thead>
        <tr>
            <th>N°</th>
            <th>Nom d'utilisateur</th>
            <th>Civilité</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Societé</th>
            <th>Poste</th>
            <th>Téléphone</th>
            <th>E-mail</th>
            <th>Inscrit depuis le</th>
            <th>Dernière connexion</th>
            <th>Expert métier</th>
            <th>Comédien Audio</th>
            <th>Dessinateur</th>

        </tr>
        </thead>
        <tbody>
        {% for user in users %}
            <tr>
                <td>{{ user.id }}</td>
                <td>{{ user.username }}</td>
                <td>{{ user.civilite }}</td>
                <td>{{ user.nom }}</td>
                <td>{{ user.prenom }}</td>
                <td>{{ user.societe }}</td>
                <td>{{ user.poste }}</td>
                <td>{{ user.telephone }}</td>
                <td>{{ user.email }}</td>
                <td>{{ user.dateCreation | date('d/m/Y') }}</td>
                <td>{{ user.lastLogin | date('d/m/Y \\\\à\\\\ H:i') }}</td>
                <td>{% if user.userExpert == true %}Oui{% else %}Non{% endif %}</td>
                <td>{% if user.userVoix == true %}Oui{% else %}Non{% endif %}</td>
                <td>{% if user.userContributeur == true %}Oui{% else %}Non{% endif %}</td>



            </tr>
        {% endfor %}
        </tbody>
    </table>
{% endblock %}
", "AppliBundle:admin:userslist.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/src/AppliBundle/Resources/views/admin/userslist.html.twig");
    }
}
