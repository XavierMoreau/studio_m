<?php

/* @FOSUser/Security/login_content.html.twig */
class __TwigTemplate_89b675f1f3edc5004e84e39250404990e50e02b2e5d308c744d038c3600fa946 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_24fe45866b4badd7bcaad9b6c830997551fd74e7f44eafcaf07485f419c9dc40 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_24fe45866b4badd7bcaad9b6c830997551fd74e7f44eafcaf07485f419c9dc40->enter($__internal_24fe45866b4badd7bcaad9b6c830997551fd74e7f44eafcaf07485f419c9dc40_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Security/login_content.html.twig"));

        // line 2
        echo "
";
        // line 3
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 4
            echo "    <div>";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageData", array()), "security"), "html", null, true);
            echo "</div>
";
        }
        // line 6
        echo "
<div class=\"login_form\">
    <form action=\"";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_check");
        echo "\" method=\"post\">
        ";
        // line 9
        if ((isset($context["csrf_token"]) ? $context["csrf_token"] : $this->getContext($context, "csrf_token"))) {
            // line 10
            echo "            <input type=\"hidden\" name=\"_csrf_token\" value=\"";
            echo twig_escape_filter($this->env, (isset($context["csrf_token"]) ? $context["csrf_token"] : $this->getContext($context, "csrf_token")), "html", null, true);
            echo "\" />
        ";
        }
        // line 12
        echo "
        <div>
            ";
        // line 15
        echo "                ";
        // line 16
        echo "            ";
        // line 17
        echo "            <input placeholder=\"Nom d'utilisateur\" class=\"login_input\" type=\"text\" id=\"username\" name=\"_username\" value=\"";
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\" required=\"required\" />
        </div>

        <div>
            ";
        // line 22
        echo "                ";
        // line 23
        echo "            ";
        // line 24
        echo "            <input placeholder=\"Mot de passe\" class=\"login_input\" type=\"password\" id=\"password\" name=\"_password\" required=\"required\" />
        </div>

        <div class=\"login_remember\">
            <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\" />
            <label for=\"remember_me\">";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.remember_me", array(), "FOSUserBundle"), "html", null, true);
        echo "</label>
        </div>

        <div class=\"login_submit\">
            <button id=\"login_submit\" type=\"submit\" name=\"_submit\" value=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.submit", array(), "FOSUserBundle"), "html", null, true);
        echo "\">Connexion</button>
            ";
        // line 35
        echo "        </div>
    </form>
</div>
";
        
        $__internal_24fe45866b4badd7bcaad9b6c830997551fd74e7f44eafcaf07485f419c9dc40->leave($__internal_24fe45866b4badd7bcaad9b6c830997551fd74e7f44eafcaf07485f419c9dc40_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Security/login_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  87 => 35,  83 => 33,  76 => 29,  69 => 24,  67 => 23,  65 => 22,  57 => 17,  55 => 16,  53 => 15,  49 => 12,  43 => 10,  41 => 9,  37 => 8,  33 => 6,  27 => 4,  25 => 3,  22 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}

{% if error %}
    <div>{{ error.messageKey|trans(error.messageData, 'security') }}</div>
{% endif %}

<div class=\"login_form\">
    <form action=\"{{ path(\"fos_user_security_check\") }}\" method=\"post\">
        {% if csrf_token %}
            <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token }}\" />
        {% endif %}

        <div>
            {#<div class=\"login_label\">#}
                {#<label for=\"username\">{{ 'security.login.username'|trans }}</label>#}
            {#</div>#}
            <input placeholder=\"Nom d'utilisateur\" class=\"login_input\" type=\"text\" id=\"username\" name=\"_username\" value=\"{{ last_username }}\" required=\"required\" />
        </div>

        <div>
            {#<div class=\"login_label\">#}
                {#<label for=\"password\">{{ 'security.login.password'|trans }}</label>#}
            {#</div>#}
            <input placeholder=\"Mot de passe\" class=\"login_input\" type=\"password\" id=\"password\" name=\"_password\" required=\"required\" />
        </div>

        <div class=\"login_remember\">
            <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\" />
            <label for=\"remember_me\">{{ 'security.login.remember_me'|trans }}</label>
        </div>

        <div class=\"login_submit\">
            <button id=\"login_submit\" type=\"submit\" name=\"_submit\" value=\"{{ 'security.login.submit'|trans }}\">Connexion</button>
            {#<a href=\"{{ path('fos_user_registration_register') }}\">S'inscrire</a>#}
        </div>
    </form>
</div>
", "@FOSUser/Security/login_content.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/friendsofsymfony/user-bundle/Resources/views/Security/login_content.html.twig");
    }
}
