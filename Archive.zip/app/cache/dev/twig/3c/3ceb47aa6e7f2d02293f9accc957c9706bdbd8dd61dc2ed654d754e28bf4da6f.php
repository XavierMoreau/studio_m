<?php

/* :conseil:show.html.twig */
class __TwigTemplate_13e5d4c49396e9b823c8cffeca39af0ef7631621464a9d858e9f4bdb0ddc0892 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":conseil:show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_58cff1628fbb2d6ab8efe960005482309ce0699e6b1f488473b6f295d881fe9b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_58cff1628fbb2d6ab8efe960005482309ce0699e6b1f488473b6f295d881fe9b->enter($__internal_58cff1628fbb2d6ab8efe960005482309ce0699e6b1f488473b6f295d881fe9b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":conseil:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_58cff1628fbb2d6ab8efe960005482309ce0699e6b1f488473b6f295d881fe9b->leave($__internal_58cff1628fbb2d6ab8efe960005482309ce0699e6b1f488473b6f295d881fe9b_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_0885fe34df8e5540c984ab11346ebbf5620e4efa65e62542627b433a480ffc2a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0885fe34df8e5540c984ab11346ebbf5620e4efa65e62542627b433a480ffc2a->enter($__internal_0885fe34df8e5540c984ab11346ebbf5620e4efa65e62542627b433a480ffc2a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Conseil</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["conseil"]) ? $context["conseil"] : $this->getContext($context, "conseil")), "id", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Temps</th>
                <td>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["conseil"]) ? $context["conseil"] : $this->getContext($context, "conseil")), "temps", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Daterequise</th>
                <td>";
        // line 18
        if ($this->getAttribute((isset($context["conseil"]) ? $context["conseil"] : $this->getContext($context, "conseil")), "dateRequise", array())) {
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["conseil"]) ? $context["conseil"] : $this->getContext($context, "conseil")), "dateRequise", array()), "Y-m-d"), "html", null, true);
        }
        echo "</td>
            </tr>
            <tr>
                <th>Datedemande</th>
                <td>";
        // line 22
        if ($this->getAttribute((isset($context["conseil"]) ? $context["conseil"] : $this->getContext($context, "conseil")), "dateDemande", array())) {
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["conseil"]) ? $context["conseil"] : $this->getContext($context, "conseil")), "dateDemande", array()), "Y-m-d H:i:s"), "html", null, true);
        }
        echo "</td>
            </tr>
            <tr>
                <th>Quantite</th>
                <td>";
        // line 26
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["conseil"]) ? $context["conseil"] : $this->getContext($context, "conseil")), "quantite", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Storyboard</th>
                <td>";
        // line 30
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["conseil"]) ? $context["conseil"] : $this->getContext($context, "conseil")), "storyboard", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Commande</th>
                <td>";
        // line 34
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["conseil"]) ? $context["conseil"] : $this->getContext($context, "conseil")), "commande", array()), "html", null, true);
        echo "</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 41
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("conseil_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            <a href=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("conseil_edit", array("id" => $this->getAttribute((isset($context["conseil"]) ? $context["conseil"] : $this->getContext($context, "conseil")), "id", array()))), "html", null, true);
        echo "\">Edit</a>
        </li>
        <li>
            ";
        // line 47
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 49
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_0885fe34df8e5540c984ab11346ebbf5620e4efa65e62542627b433a480ffc2a->leave($__internal_0885fe34df8e5540c984ab11346ebbf5620e4efa65e62542627b433a480ffc2a_prof);

    }

    public function getTemplateName()
    {
        return ":conseil:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  121 => 49,  116 => 47,  110 => 44,  104 => 41,  94 => 34,  87 => 30,  80 => 26,  71 => 22,  62 => 18,  55 => 14,  48 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Conseil</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>{{ conseil.id }}</td>
            </tr>
            <tr>
                <th>Temps</th>
                <td>{{ conseil.temps }}</td>
            </tr>
            <tr>
                <th>Daterequise</th>
                <td>{% if conseil.dateRequise %}{{ conseil.dateRequise|date('Y-m-d') }}{% endif %}</td>
            </tr>
            <tr>
                <th>Datedemande</th>
                <td>{% if conseil.dateDemande %}{{ conseil.dateDemande|date('Y-m-d H:i:s') }}{% endif %}</td>
            </tr>
            <tr>
                <th>Quantite</th>
                <td>{{ conseil.quantite }}</td>
            </tr>
            <tr>
                <th>Storyboard</th>
                <td>{{ conseil.storyboard }}</td>
            </tr>
            <tr>
                <th>Commande</th>
                <td>{{ conseil.commande }}</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"{{ path('conseil_index') }}\">Back to the list</a>
        </li>
        <li>
            <a href=\"{{ path('conseil_edit', { 'id': conseil.id }) }}\">Edit</a>
        </li>
        <li>
            {{ form_start(delete_form) }}
                <input type=\"submit\" value=\"Delete\">
            {{ form_end(delete_form) }}
        </li>
    </ul>
{% endblock %}
", ":conseil:show.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/conseil/show.html.twig");
    }
}
