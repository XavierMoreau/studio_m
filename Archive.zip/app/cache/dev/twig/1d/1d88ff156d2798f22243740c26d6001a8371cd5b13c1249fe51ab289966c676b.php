<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_5dcf714ea8b35c876d32d9715e081a7b08b77552bc86f6668d26f6a9be88e1d4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_96a89258143eff14c2fceaeaa6d4325efe21f4a00a2885565e405e2cd193979c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_96a89258143eff14c2fceaeaa6d4325efe21f4a00a2885565e405e2cd193979c->enter($__internal_96a89258143eff14c2fceaeaa6d4325efe21f4a00a2885565e405e2cd193979c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_96a89258143eff14c2fceaeaa6d4325efe21f4a00a2885565e405e2cd193979c->leave($__internal_96a89258143eff14c2fceaeaa6d4325efe21f4a00a2885565e405e2cd193979c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_rows') ?>
", "@Framework/Form/repeated_row.html.php", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/repeated_row.html.php");
    }
}
