<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_7d40c52537446ca44364f7ddff48bc22290e8755ff88af1e5aca10cdc47af604 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ff04d9ef65b7f7f4809d1d1d64703f555a16edbabed94e5aae475343e3b32586 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ff04d9ef65b7f7f4809d1d1d64703f555a16edbabed94e5aae475343e3b32586->enter($__internal_ff04d9ef65b7f7f4809d1d1d64703f555a16edbabed94e5aae475343e3b32586_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_ff04d9ef65b7f7f4809d1d1d64703f555a16edbabed94e5aae475343e3b32586->leave($__internal_ff04d9ef65b7f7f4809d1d1d64703f555a16edbabed94e5aae475343e3b32586_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_options.html.php");
    }
}
