<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_7d40c52537446ca44364f7ddff48bc22290e8755ff88af1e5aca10cdc47af604 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dd41bbc6038a0a56754c1cf72da2d171f3c0f02d5b2ec58bc6d89def787896f0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dd41bbc6038a0a56754c1cf72da2d171f3c0f02d5b2ec58bc6d89def787896f0->enter($__internal_dd41bbc6038a0a56754c1cf72da2d171f3c0f02d5b2ec58bc6d89def787896f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_dd41bbc6038a0a56754c1cf72da2d171f3c0f02d5b2ec58bc6d89def787896f0->leave($__internal_dd41bbc6038a0a56754c1cf72da2d171f3c0f02d5b2ec58bc6d89def787896f0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_options.html.php");
    }
}
