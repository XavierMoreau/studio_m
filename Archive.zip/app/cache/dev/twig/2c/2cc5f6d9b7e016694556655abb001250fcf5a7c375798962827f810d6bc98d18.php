<?php

/* ::base.html.twig */
class __TwigTemplate_290154c8306ef6b7c4e990ef8eb5f26865bd7244ff52291f167c373df2e98aab extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a18b3ad9cd614a45cf516f608e7b981f0fca8b9d9a2638d9fea2962a3b6a3382 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a18b3ad9cd614a45cf516f608e7b981f0fca8b9d9a2638d9fea2962a3b6a3382->enter($__internal_a18b3ad9cd614a45cf516f608e7b981f0fca8b9d9a2638d9fea2962a3b6a3382_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_a18b3ad9cd614a45cf516f608e7b981f0fca8b9d9a2638d9fea2962a3b6a3382->leave($__internal_a18b3ad9cd614a45cf516f608e7b981f0fca8b9d9a2638d9fea2962a3b6a3382_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_abb9a76cf291f50e8e6c66258d5aac584c314e3e41f053f607f6bd16496a8ce5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_abb9a76cf291f50e8e6c66258d5aac584c314e3e41f053f607f6bd16496a8ce5->enter($__internal_abb9a76cf291f50e8e6c66258d5aac584c314e3e41f053f607f6bd16496a8ce5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_abb9a76cf291f50e8e6c66258d5aac584c314e3e41f053f607f6bd16496a8ce5->leave($__internal_abb9a76cf291f50e8e6c66258d5aac584c314e3e41f053f607f6bd16496a8ce5_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_e7aa35413b72d29647f75fa6d5e78ebee1e8bc8bd193ecedf5db5b10c274378b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e7aa35413b72d29647f75fa6d5e78ebee1e8bc8bd193ecedf5db5b10c274378b->enter($__internal_e7aa35413b72d29647f75fa6d5e78ebee1e8bc8bd193ecedf5db5b10c274378b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_e7aa35413b72d29647f75fa6d5e78ebee1e8bc8bd193ecedf5db5b10c274378b->leave($__internal_e7aa35413b72d29647f75fa6d5e78ebee1e8bc8bd193ecedf5db5b10c274378b_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_a54aa5e3ebb37e949f0ed3ea4d8172866f000e4448215845d843ff88c5308225 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a54aa5e3ebb37e949f0ed3ea4d8172866f000e4448215845d843ff88c5308225->enter($__internal_a54aa5e3ebb37e949f0ed3ea4d8172866f000e4448215845d843ff88c5308225_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_a54aa5e3ebb37e949f0ed3ea4d8172866f000e4448215845d843ff88c5308225->leave($__internal_a54aa5e3ebb37e949f0ed3ea4d8172866f000e4448215845d843ff88c5308225_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_c0caa434fae5ca06d2d90163e3e8d93fc810fe1484caf33d7db5a0baae164b90 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c0caa434fae5ca06d2d90163e3e8d93fc810fe1484caf33d7db5a0baae164b90->enter($__internal_c0caa434fae5ca06d2d90163e3e8d93fc810fe1484caf33d7db5a0baae164b90_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_c0caa434fae5ca06d2d90163e3e8d93fc810fe1484caf33d7db5a0baae164b90->leave($__internal_c0caa434fae5ca06d2d90163e3e8d93fc810fe1484caf33d7db5a0baae164b90_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "::base.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/base.html.twig");
    }
}
