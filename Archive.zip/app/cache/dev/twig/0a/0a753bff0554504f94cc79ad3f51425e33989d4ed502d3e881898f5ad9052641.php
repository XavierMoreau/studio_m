<?php

/* :experttype:edit.html.twig */
class __TwigTemplate_b8b734077bcfda1cc4a3eed081da5751f0675b17febd97884202057fc9af3cf5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("layout.html.twig", ":experttype:edit.html.twig", 2);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b5947d1a0878f44d4a232f2f8aa2f1c4b370ee2978b9b02f59d3a412ee384cbb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b5947d1a0878f44d4a232f2f8aa2f1c4b370ee2978b9b02f59d3a412ee384cbb->enter($__internal_b5947d1a0878f44d4a232f2f8aa2f1c4b370ee2978b9b02f59d3a412ee384cbb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":experttype:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b5947d1a0878f44d4a232f2f8aa2f1c4b370ee2978b9b02f59d3a412ee384cbb->leave($__internal_b5947d1a0878f44d4a232f2f8aa2f1c4b370ee2978b9b02f59d3a412ee384cbb_prof);

    }

    // line 4
    public function block_content($context, array $blocks = array())
    {
        $__internal_d3c7ad9e07e9df41425a2b15c7fde2252a4ec51d9b5c5e07580bc3fa5efe5739 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d3c7ad9e07e9df41425a2b15c7fde2252a4ec51d9b5c5e07580bc3fa5efe5739->enter($__internal_d3c7ad9e07e9df41425a2b15c7fde2252a4ec51d9b5c5e07580bc3fa5efe5739_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 5
        echo "    <h1>Type de métier</h1>

    ";
        // line 7
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
    ";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "
    <input class=\"btn btn-primary\" type=\"submit\" value=\"Enregistrer\" />
    <a class=\"btn btn-default\" href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("experttype_index");
        echo "\">Retour</a>
    ";
        // line 11
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "


";
        
        $__internal_d3c7ad9e07e9df41425a2b15c7fde2252a4ec51d9b5c5e07580bc3fa5efe5739->leave($__internal_d3c7ad9e07e9df41425a2b15c7fde2252a4ec51d9b5c5e07580bc3fa5efe5739_prof);

    }

    public function getTemplateName()
    {
        return ":experttype:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 11,  53 => 10,  48 => 8,  44 => 7,  40 => 5,  34 => 4,  11 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
{% extends 'layout.html.twig' %}

{% block content %}
    <h1>Type de métier</h1>

    {{ form_start(edit_form) }}
    {{ form_widget(edit_form) }}
    <input class=\"btn btn-primary\" type=\"submit\" value=\"Enregistrer\" />
    <a class=\"btn btn-default\" href=\"{{ path('experttype_index') }}\">Retour</a>
    {{ form_end(edit_form) }}


{% endblock %}
", ":experttype:edit.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/experttype/edit.html.twig");
    }
}
