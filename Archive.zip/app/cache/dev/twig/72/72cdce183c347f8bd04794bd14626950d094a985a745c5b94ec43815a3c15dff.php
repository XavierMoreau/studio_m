<?php

/* :utilisation:index.html.twig */
class __TwigTemplate_323ce0c4894e1191a8547f0dee5e77c281069f97ddc99194359003db0dd53e69 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":utilisation:index.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_be1601eb2720e1e1985b13e58f30cc4dbc6aa3caabcbb9e3a402bf2e8d3ced28 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_be1601eb2720e1e1985b13e58f30cc4dbc6aa3caabcbb9e3a402bf2e8d3ced28->enter($__internal_be1601eb2720e1e1985b13e58f30cc4dbc6aa3caabcbb9e3a402bf2e8d3ced28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":utilisation:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_be1601eb2720e1e1985b13e58f30cc4dbc6aa3caabcbb9e3a402bf2e8d3ced28->leave($__internal_be1601eb2720e1e1985b13e58f30cc4dbc6aa3caabcbb9e3a402bf2e8d3ced28_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_cecc2a451d9ab54e289e17623e438559d1fe64fbeaee66aa490f470f4bccd3d1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cecc2a451d9ab54e289e17623e438559d1fe64fbeaee66aa490f470f4bccd3d1->enter($__internal_cecc2a451d9ab54e289e17623e438559d1fe64fbeaee66aa490f470f4bccd3d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <h1>Types d'utilisation</h1>

    <table class=\"table table-striped\">
        <thead>
            <tr>
                <th> Types proposés :</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["utilisations"]) ? $context["utilisations"] : $this->getContext($context, "utilisations")));
        foreach ($context['_seq'] as $context["_key"] => $context["utilisation"]) {
            // line 15
            echo "            <tr>
                <td>";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute($context["utilisation"], "utilisationType", array()), "html", null, true);
            echo "</td>
                <td><a class=\"btn-modifier\" href=\"";
            // line 17
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("utilisation_edit", array("id" => $this->getAttribute($context["utilisation"], "id", array()))), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-edit\" aria-hidden=\"true\"></span></a></td>
                <td><a class=\"btn-delete\" href=\"";
            // line 18
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("utilisation_delete", array("id" => $this->getAttribute($context["utilisation"], "id", array()))), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-trash\" aria-hidden=\"true\"></span></a></td>

            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['utilisation'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 22
        echo "        </tbody>
    </table>


            <a class=\"btn btn-primary\" href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("utilisation_new");
        echo "\">Nouveau</a>

            <a class=\"btn btn-default\" href=\"";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_index");
        echo "\">Retour</a>

";
        
        $__internal_cecc2a451d9ab54e289e17623e438559d1fe64fbeaee66aa490f470f4bccd3d1->leave($__internal_cecc2a451d9ab54e289e17623e438559d1fe64fbeaee66aa490f470f4bccd3d1_prof);

    }

    public function getTemplateName()
    {
        return ":utilisation:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 28,  83 => 26,  77 => 22,  67 => 18,  63 => 17,  59 => 16,  56 => 15,  52 => 14,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block content %}
    <h1>Types d'utilisation</h1>

    <table class=\"table table-striped\">
        <thead>
            <tr>
                <th> Types proposés :</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        {% for utilisation in utilisations %}
            <tr>
                <td>{{ utilisation.utilisationType }}</td>
                <td><a class=\"btn-modifier\" href=\"{{ path('utilisation_edit', { 'id': utilisation.id }) }}\"><span class=\"glyphicon glyphicon-edit\" aria-hidden=\"true\"></span></a></td>
                <td><a class=\"btn-delete\" href=\"{{ path('utilisation_delete', { 'id': utilisation.id }) }}\"><span class=\"glyphicon glyphicon-trash\" aria-hidden=\"true\"></span></a></td>

            </tr>
        {% endfor %}
        </tbody>
    </table>


            <a class=\"btn btn-primary\" href=\"{{ path('utilisation_new') }}\">Nouveau</a>

            <a class=\"btn btn-default\" href=\"{{ path('admin_index') }}\">Retour</a>

{% endblock %}
", ":utilisation:index.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/utilisation/index.html.twig");
    }
}
