<?php

/* :support:show.html.twig */
class __TwigTemplate_970b229f43ef1206ffd4ea625bf6766191b66453a4a0d4bc91cb550c79d85e4a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":support:show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6473eb875feb1ef8af746cfaae4a1ae6c25bff3fa4e5fe309b0b843cca92170f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6473eb875feb1ef8af746cfaae4a1ae6c25bff3fa4e5fe309b0b843cca92170f->enter($__internal_6473eb875feb1ef8af746cfaae4a1ae6c25bff3fa4e5fe309b0b843cca92170f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":support:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6473eb875feb1ef8af746cfaae4a1ae6c25bff3fa4e5fe309b0b843cca92170f->leave($__internal_6473eb875feb1ef8af746cfaae4a1ae6c25bff3fa4e5fe309b0b843cca92170f_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_37612433659b1304b9f607aab9195213b34c73961024a5579bec421a07c99aba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_37612433659b1304b9f607aab9195213b34c73961024a5579bec421a07c99aba->enter($__internal_37612433659b1304b9f607aab9195213b34c73961024a5579bec421a07c99aba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Support</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["support"]) ? $context["support"] : $this->getContext($context, "support")), "id", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Supporttype</th>
                <td>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["support"]) ? $context["support"] : $this->getContext($context, "support")), "supportType", array()), "html", null, true);
        echo "</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("support_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            <a href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("support_edit", array("id" => $this->getAttribute((isset($context["support"]) ? $context["support"] : $this->getContext($context, "support")), "id", array()))), "html", null, true);
        echo "\">Edit</a>
        </li>
        <li>
            ";
        // line 27
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 29
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_37612433659b1304b9f607aab9195213b34c73961024a5579bec421a07c99aba->leave($__internal_37612433659b1304b9f607aab9195213b34c73961024a5579bec421a07c99aba_prof);

    }

    public function getTemplateName()
    {
        return ":support:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 29,  77 => 27,  71 => 24,  65 => 21,  55 => 14,  48 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block body %}
    <h1>Support</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>{{ support.id }}</td>
            </tr>
            <tr>
                <th>Supporttype</th>
                <td>{{ support.supportType }}</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"{{ path('support_index') }}\">Back to the list</a>
        </li>
        <li>
            <a href=\"{{ path('support_edit', { 'id': support.id }) }}\">Edit</a>
        </li>
        <li>
            {{ form_start(delete_form) }}
                <input type=\"submit\" value=\"Delete\">
            {{ form_end(delete_form) }}
        </li>
    </ul>
{% endblock %}
", ":support:show.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/support/show.html.twig");
    }
}
