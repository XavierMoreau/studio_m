<?php

/* :support:edit.html.twig */
class __TwigTemplate_aa39fcb5a09f77dd80527f3f07f1cc9d46d3542c001758b37de5bbc2d1259079 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":support:edit.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_50e8890ddf3199b6c86617052153b5224acc337dca2dd4d9330a8923e638bd34 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_50e8890ddf3199b6c86617052153b5224acc337dca2dd4d9330a8923e638bd34->enter($__internal_50e8890ddf3199b6c86617052153b5224acc337dca2dd4d9330a8923e638bd34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":support:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_50e8890ddf3199b6c86617052153b5224acc337dca2dd4d9330a8923e638bd34->leave($__internal_50e8890ddf3199b6c86617052153b5224acc337dca2dd4d9330a8923e638bd34_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_b16be12dd82ae95c815a2a147db3b341c6321d1b1da90cc9f97ac4dd8102fbf7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b16be12dd82ae95c815a2a147db3b341c6321d1b1da90cc9f97ac4dd8102fbf7->enter($__internal_b16be12dd82ae95c815a2a147db3b341c6321d1b1da90cc9f97ac4dd8102fbf7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <h1>Type de support</h1>

    ";
        // line 6
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "
        <input class=\"btn btn-primary\" type=\"submit\" value=\"Enregistrer\" />
    <a class=\"btn btn-default\" href=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("support_index");
        echo "\">Retour</a>
    ";
        // line 10
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "


";
        
        $__internal_b16be12dd82ae95c815a2a147db3b341c6321d1b1da90cc9f97ac4dd8102fbf7->leave($__internal_b16be12dd82ae95c815a2a147db3b341c6321d1b1da90cc9f97ac4dd8102fbf7_prof);

    }

    public function getTemplateName()
    {
        return ":support:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 10,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block content %}
    <h1>Type de support</h1>

    {{ form_start(edit_form) }}
        {{ form_widget(edit_form) }}
        <input class=\"btn btn-primary\" type=\"submit\" value=\"Enregistrer\" />
    <a class=\"btn btn-default\" href=\"{{ path('support_index') }}\">Retour</a>
    {{ form_end(edit_form) }}


{% endblock %}
", ":support:edit.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/support/edit.html.twig");
    }
}
