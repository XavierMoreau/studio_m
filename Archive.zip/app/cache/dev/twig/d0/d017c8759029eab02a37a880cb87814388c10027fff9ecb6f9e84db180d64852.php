<?php

/* AppliBundle:Default:contributeur.html.twig */
class __TwigTemplate_65fc3ddc28f124f95559b0a4b0a626d8dc7ca820c07d418d6f6b5fca5bc3b914 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "AppliBundle:Default:contributeur.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bb690ae888bda3f33e796e716b67d0b8f754d142ea8fb910f84603757de18239 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bb690ae888bda3f33e796e716b67d0b8f754d142ea8fb910f84603757de18239->enter($__internal_bb690ae888bda3f33e796e716b67d0b8f754d142ea8fb910f84603757de18239_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppliBundle:Default:contributeur.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bb690ae888bda3f33e796e716b67d0b8f754d142ea8fb910f84603757de18239->leave($__internal_bb690ae888bda3f33e796e716b67d0b8f754d142ea8fb910f84603757de18239_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_fd5e29ca8f4074697593b59c85c0ea92e833cb8741adca2ae18da0e4cf18190f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fd5e29ca8f4074697593b59c85c0ea92e833cb8741adca2ae18da0e4cf18190f->enter($__internal_fd5e29ca8f4074697593b59c85c0ea92e833cb8741adca2ae18da0e4cf18190f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_fd5e29ca8f4074697593b59c85c0ea92e833cb8741adca2ae18da0e4cf18190f->leave($__internal_fd5e29ca8f4074697593b59c85c0ea92e833cb8741adca2ae18da0e4cf18190f_prof);

    }

    // line 9
    public function block_content($context, array $blocks = array())
    {
        $__internal_3d97e52622b30369c0636f3629a95aa181143d04fb62ea68949963873129b495 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3d97e52622b30369c0636f3629a95aa181143d04fb62ea68949963873129b495->enter($__internal_3d97e52622b30369c0636f3629a95aa181143d04fb62ea68949963873129b495_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 10
        echo "    ";
        // line 11
        echo "    contributeur page

";
        
        $__internal_3d97e52622b30369c0636f3629a95aa181143d04fb62ea68949963873129b495->leave($__internal_3d97e52622b30369c0636f3629a95aa181143d04fb62ea68949963873129b495_prof);

    }

    public function getTemplateName()
    {
        return "AppliBundle:Default:contributeur.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  54 => 11,  52 => 10,  46 => 9,  35 => 7,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layout.html.twig\" %}





{% block title %}{% endblock %}

{% block content %}
    {#{% block fos_user_content %}{% endblock %}#}
    contributeur page

{% endblock %}", "AppliBundle:Default:contributeur.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/src/AppliBundle/Resources/views/Default/contributeur.html.twig");
    }
}
