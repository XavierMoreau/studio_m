<?php

/* AppliBundle:Default:contributeur.html.twig */
class __TwigTemplate_65fc3ddc28f124f95559b0a4b0a626d8dc7ca820c07d418d6f6b5fca5bc3b914 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "AppliBundle:Default:contributeur.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e46bd57a2e820a1bd66653b7aeed8c5c0e58403ffabc12d9cc494d7377f3d87e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e46bd57a2e820a1bd66653b7aeed8c5c0e58403ffabc12d9cc494d7377f3d87e->enter($__internal_e46bd57a2e820a1bd66653b7aeed8c5c0e58403ffabc12d9cc494d7377f3d87e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppliBundle:Default:contributeur.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e46bd57a2e820a1bd66653b7aeed8c5c0e58403ffabc12d9cc494d7377f3d87e->leave($__internal_e46bd57a2e820a1bd66653b7aeed8c5c0e58403ffabc12d9cc494d7377f3d87e_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_156d60a2495fc578b3fc8ef1297368812caa12b81470775790223945f3529356 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_156d60a2495fc578b3fc8ef1297368812caa12b81470775790223945f3529356->enter($__internal_156d60a2495fc578b3fc8ef1297368812caa12b81470775790223945f3529356_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_156d60a2495fc578b3fc8ef1297368812caa12b81470775790223945f3529356->leave($__internal_156d60a2495fc578b3fc8ef1297368812caa12b81470775790223945f3529356_prof);

    }

    // line 9
    public function block_content($context, array $blocks = array())
    {
        $__internal_f36f802419a2a575e38a58806d71e73d2a98fbc7e115b20cf2b9a90b3d2b25a5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f36f802419a2a575e38a58806d71e73d2a98fbc7e115b20cf2b9a90b3d2b25a5->enter($__internal_f36f802419a2a575e38a58806d71e73d2a98fbc7e115b20cf2b9a90b3d2b25a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 10
        echo "    ";
        // line 11
        echo "    contributeur page

";
        
        $__internal_f36f802419a2a575e38a58806d71e73d2a98fbc7e115b20cf2b9a90b3d2b25a5->leave($__internal_f36f802419a2a575e38a58806d71e73d2a98fbc7e115b20cf2b9a90b3d2b25a5_prof);

    }

    public function getTemplateName()
    {
        return "AppliBundle:Default:contributeur.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  54 => 11,  52 => 10,  46 => 9,  35 => 7,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layout.html.twig\" %}





{% block title %}{% endblock %}

{% block content %}
    {#{% block fos_user_content %}{% endblock %}#}
    contributeur page

{% endblock %}", "AppliBundle:Default:contributeur.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/src/AppliBundle/Resources/views/Default/contributeur.html.twig");
    }
}
