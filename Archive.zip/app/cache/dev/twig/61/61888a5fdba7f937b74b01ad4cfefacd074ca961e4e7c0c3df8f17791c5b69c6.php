<?php

/* WebProfilerBundle:Collector:router.html.twig */
class __TwigTemplate_b31cba6de5a4d45320191647c632b3df5be44a3d65604d6e9a7ad77aa614de07 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2e64e6114a694b914fe4eb51774a320e1aa9460b4afc3160dff8cccefd70aef0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2e64e6114a694b914fe4eb51774a320e1aa9460b4afc3160dff8cccefd70aef0->enter($__internal_2e64e6114a694b914fe4eb51774a320e1aa9460b4afc3160dff8cccefd70aef0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2e64e6114a694b914fe4eb51774a320e1aa9460b4afc3160dff8cccefd70aef0->leave($__internal_2e64e6114a694b914fe4eb51774a320e1aa9460b4afc3160dff8cccefd70aef0_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_bfd3a30c857b4d83fd391acfc1ade486e9c3bef593b45ff7da81f837a859b942 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bfd3a30c857b4d83fd391acfc1ade486e9c3bef593b45ff7da81f837a859b942->enter($__internal_bfd3a30c857b4d83fd391acfc1ade486e9c3bef593b45ff7da81f837a859b942_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_bfd3a30c857b4d83fd391acfc1ade486e9c3bef593b45ff7da81f837a859b942->leave($__internal_bfd3a30c857b4d83fd391acfc1ade486e9c3bef593b45ff7da81f837a859b942_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_c4f6e0211abe4aada120f3176367f3a3c91ab1f456d0d7e8abaa484989cd08c4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c4f6e0211abe4aada120f3176367f3a3c91ab1f456d0d7e8abaa484989cd08c4->enter($__internal_c4f6e0211abe4aada120f3176367f3a3c91ab1f456d0d7e8abaa484989cd08c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_c4f6e0211abe4aada120f3176367f3a3c91ab1f456d0d7e8abaa484989cd08c4->leave($__internal_c4f6e0211abe4aada120f3176367f3a3c91ab1f456d0d7e8abaa484989cd08c4_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_debc80437345f8e96e9967184fe51680e654a57890a908e94ea1e0f3959274ba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_debc80437345f8e96e9967184fe51680e654a57890a908e94ea1e0f3959274ba->enter($__internal_debc80437345f8e96e9967184fe51680e654a57890a908e94ea1e0f3959274ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_debc80437345f8e96e9967184fe51680e654a57890a908e94ea1e0f3959274ba->leave($__internal_debc80437345f8e96e9967184fe51680e654a57890a908e94ea1e0f3959274ba_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "WebProfilerBundle:Collector:router.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
