<?php

/* FOSUserBundle:Registration:register.html.twig */
class __TwigTemplate_19b02689692ca6108d9c027b4f455aeeada64b2592bce697397e95280a18dcbb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Registration:register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7c4436c6b7b2fe964a38f0836fe1339179be1c18bc4cbc7af9debee65a1bb35f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7c4436c6b7b2fe964a38f0836fe1339179be1c18bc4cbc7af9debee65a1bb35f->enter($__internal_7c4436c6b7b2fe964a38f0836fe1339179be1c18bc4cbc7af9debee65a1bb35f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7c4436c6b7b2fe964a38f0836fe1339179be1c18bc4cbc7af9debee65a1bb35f->leave($__internal_7c4436c6b7b2fe964a38f0836fe1339179be1c18bc4cbc7af9debee65a1bb35f_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_5d9a43bc60e36360cc30e0f42f0743b8f655d1069151f660e0c6766751378cef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5d9a43bc60e36360cc30e0f42f0743b8f655d1069151f660e0c6766751378cef->enter($__internal_5d9a43bc60e36360cc30e0f42f0743b8f655d1069151f660e0c6766751378cef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Registration/register_content.html.twig", "FOSUserBundle:Registration:register.html.twig", 4)->display($context);
        
        $__internal_5d9a43bc60e36360cc30e0f42f0743b8f655d1069151f660e0c6766751378cef->leave($__internal_5d9a43bc60e36360cc30e0f42f0743b8f655d1069151f660e0c6766751378cef_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Registration/register_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Registration:register.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/friendsofsymfony/user-bundle/Resources/views/Registration/register.html.twig");
    }
}
