<?php

/* FOSUserBundle:Registration:register.html.twig */
class __TwigTemplate_19b02689692ca6108d9c027b4f455aeeada64b2592bce697397e95280a18dcbb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Registration:register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1addd3d321e2e796203b91bf6613dcae5a28821aed334f2e8e7799cf1c55f33e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1addd3d321e2e796203b91bf6613dcae5a28821aed334f2e8e7799cf1c55f33e->enter($__internal_1addd3d321e2e796203b91bf6613dcae5a28821aed334f2e8e7799cf1c55f33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1addd3d321e2e796203b91bf6613dcae5a28821aed334f2e8e7799cf1c55f33e->leave($__internal_1addd3d321e2e796203b91bf6613dcae5a28821aed334f2e8e7799cf1c55f33e_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_d47ca756e6c0927b7ebf54df2ce5bceb7b124683c43baf9a30b04a88f5190a13 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d47ca756e6c0927b7ebf54df2ce5bceb7b124683c43baf9a30b04a88f5190a13->enter($__internal_d47ca756e6c0927b7ebf54df2ce5bceb7b124683c43baf9a30b04a88f5190a13_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Registration/register_content.html.twig", "FOSUserBundle:Registration:register.html.twig", 4)->display($context);
        
        $__internal_d47ca756e6c0927b7ebf54df2ce5bceb7b124683c43baf9a30b04a88f5190a13->leave($__internal_d47ca756e6c0927b7ebf54df2ce5bceb7b124683c43baf9a30b04a88f5190a13_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Registration/register_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Registration:register.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/friendsofsymfony/user-bundle/Resources/views/Registration/register.html.twig");
    }
}
