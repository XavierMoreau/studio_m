<?php

/* ::admin.html.twig */
class __TwigTemplate_88e7e149f3eea36d3420e6f93faae003382e58ae1ff77e1890869f3fff0baf38 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "::admin.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6669f10e2512fba3a36e1ef8089349c5c453e7da5049ee13c1546133df4f29be = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6669f10e2512fba3a36e1ef8089349c5c453e7da5049ee13c1546133df4f29be->enter($__internal_6669f10e2512fba3a36e1ef8089349c5c453e7da5049ee13c1546133df4f29be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::admin.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6669f10e2512fba3a36e1ef8089349c5c453e7da5049ee13c1546133df4f29be->leave($__internal_6669f10e2512fba3a36e1ef8089349c5c453e7da5049ee13c1546133df4f29be_prof);

    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        $__internal_2b60d3f450ad5ec1f109111e8bf27bc0386c66c279fff2a4a6c9a7bae40b05df = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2b60d3f450ad5ec1f109111e8bf27bc0386c66c279fff2a4a6c9a7bae40b05df->enter($__internal_2b60d3f450ad5ec1f109111e8bf27bc0386c66c279fff2a4a6c9a7bae40b05df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "
    <div>
";
        // line 10
        echo "    </div>




";
        
        $__internal_2b60d3f450ad5ec1f109111e8bf27bc0386c66c279fff2a4a6c9a7bae40b05df->leave($__internal_2b60d3f450ad5ec1f109111e8bf27bc0386c66c279fff2a4a6c9a7bae40b05df_prof);

    }

    public function getTemplateName()
    {
        return "::admin.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  44 => 10,  40 => 7,  34 => 6,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}




{% block body %}

    <div>
{#{% include \"utilisation/index.html.twig\" %}#}
    </div>




{% endblock body %}", "::admin.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/admin.html.twig");
    }
}
