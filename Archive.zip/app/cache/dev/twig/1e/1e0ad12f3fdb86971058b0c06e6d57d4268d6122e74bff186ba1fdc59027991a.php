<?php

/* ::admin.html.twig */
class __TwigTemplate_88e7e149f3eea36d3420e6f93faae003382e58ae1ff77e1890869f3fff0baf38 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "::admin.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_152ba8acbeda40c28fa17a97f3acf580192ac380d3b9326b28223c8fc13ff474 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_152ba8acbeda40c28fa17a97f3acf580192ac380d3b9326b28223c8fc13ff474->enter($__internal_152ba8acbeda40c28fa17a97f3acf580192ac380d3b9326b28223c8fc13ff474_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::admin.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_152ba8acbeda40c28fa17a97f3acf580192ac380d3b9326b28223c8fc13ff474->leave($__internal_152ba8acbeda40c28fa17a97f3acf580192ac380d3b9326b28223c8fc13ff474_prof);

    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        $__internal_d8c36c6855cd17777295dd7e7cc6274312714f5aa8862cec2b5b215b46a4d450 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d8c36c6855cd17777295dd7e7cc6274312714f5aa8862cec2b5b215b46a4d450->enter($__internal_d8c36c6855cd17777295dd7e7cc6274312714f5aa8862cec2b5b215b46a4d450_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "
    <div>
";
        // line 10
        echo "    </div>




";
        
        $__internal_d8c36c6855cd17777295dd7e7cc6274312714f5aa8862cec2b5b215b46a4d450->leave($__internal_d8c36c6855cd17777295dd7e7cc6274312714f5aa8862cec2b5b215b46a4d450_prof);

    }

    public function getTemplateName()
    {
        return "::admin.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  44 => 10,  40 => 7,  34 => 6,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}




{% block body %}

    <div>
{#{% include \"utilisation/index.html.twig\" %}#}
    </div>




{% endblock body %}", "::admin.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/admin.html.twig");
    }
}
