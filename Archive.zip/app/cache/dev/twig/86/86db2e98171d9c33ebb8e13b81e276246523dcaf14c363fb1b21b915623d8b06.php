<?php

/* @FOSUser/layout.html.twig */
class __TwigTemplate_cac5cfcd1771803bc66b08cca9e5126b505e0952df4658088a0f591bec40e10d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "@FOSUser/layout.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'connection' => array($this, 'block_connection'),
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a09ba99bfa428a1150802eecdf16fb34604cb1792c9614f112018a73d3c56fb7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a09ba99bfa428a1150802eecdf16fb34604cb1792c9614f112018a73d3c56fb7->enter($__internal_a09ba99bfa428a1150802eecdf16fb34604cb1792c9614f112018a73d3c56fb7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a09ba99bfa428a1150802eecdf16fb34604cb1792c9614f112018a73d3c56fb7->leave($__internal_a09ba99bfa428a1150802eecdf16fb34604cb1792c9614f112018a73d3c56fb7_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_9c7916644d0f2b8aa3805f9cb87101959d8231b4d7bdfad65bb3dd8989712303 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9c7916644d0f2b8aa3805f9cb87101959d8231b4d7bdfad65bb3dd8989712303->enter($__internal_9c7916644d0f2b8aa3805f9cb87101959d8231b4d7bdfad65bb3dd8989712303_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_9c7916644d0f2b8aa3805f9cb87101959d8231b4d7bdfad65bb3dd8989712303->leave($__internal_9c7916644d0f2b8aa3805f9cb87101959d8231b4d7bdfad65bb3dd8989712303_prof);

    }

    // line 5
    public function block_connection($context, array $blocks = array())
    {
        $__internal_fd482e3fbadc02f4d94b7c39e1a5632c0b1cdc5a5e0957b142b16aa4de00dfdd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fd482e3fbadc02f4d94b7c39e1a5632c0b1cdc5a5e0957b142b16aa4de00dfdd->enter($__internal_fd482e3fbadc02f4d94b7c39e1a5632c0b1cdc5a5e0957b142b16aa4de00dfdd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "connection"));

        // line 6
        echo "    <div class=\"connection\">

        <div class=\"conn-middle\">

            ";
        // line 10
        $this->displayBlock('fos_user_content', $context, $blocks);
        // line 11
        echo "
        </div>



    </div>

";
        
        $__internal_fd482e3fbadc02f4d94b7c39e1a5632c0b1cdc5a5e0957b142b16aa4de00dfdd->leave($__internal_fd482e3fbadc02f4d94b7c39e1a5632c0b1cdc5a5e0957b142b16aa4de00dfdd_prof);

    }

    // line 10
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_32e5065a09804a761002d466b28b3e857594db7bfef70727db821019109c209f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_32e5065a09804a761002d466b28b3e857594db7bfef70727db821019109c209f->enter($__internal_32e5065a09804a761002d466b28b3e857594db7bfef70727db821019109c209f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        
        $__internal_32e5065a09804a761002d466b28b3e857594db7bfef70727db821019109c209f->leave($__internal_32e5065a09804a761002d466b28b3e857594db7bfef70727db821019109c209f_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  75 => 10,  61 => 11,  59 => 10,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layout.html.twig\" %}

{% block title %}{% endblock %}

{% block connection %}
    <div class=\"connection\">

        <div class=\"conn-middle\">

            {% block fos_user_content %}{% endblock %}

        </div>



    </div>

{% endblock %}", "@FOSUser/layout.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/friendsofsymfony/user-bundle/Resources/views/layout.html.twig");
    }
}
