<?php

/* @FOSUser/layout.html.twig */
class __TwigTemplate_cac5cfcd1771803bc66b08cca9e5126b505e0952df4658088a0f591bec40e10d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "@FOSUser/layout.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'connection' => array($this, 'block_connection'),
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b57e117b393b0d41e517c0ec0cb0c841789406c64af11a4c072d6c80b2e0f7d9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b57e117b393b0d41e517c0ec0cb0c841789406c64af11a4c072d6c80b2e0f7d9->enter($__internal_b57e117b393b0d41e517c0ec0cb0c841789406c64af11a4c072d6c80b2e0f7d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b57e117b393b0d41e517c0ec0cb0c841789406c64af11a4c072d6c80b2e0f7d9->leave($__internal_b57e117b393b0d41e517c0ec0cb0c841789406c64af11a4c072d6c80b2e0f7d9_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_bd6c11729c1efd848d4ff8d0efc61263c564f7da61c4e2b286f39ec827a28d59 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bd6c11729c1efd848d4ff8d0efc61263c564f7da61c4e2b286f39ec827a28d59->enter($__internal_bd6c11729c1efd848d4ff8d0efc61263c564f7da61c4e2b286f39ec827a28d59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_bd6c11729c1efd848d4ff8d0efc61263c564f7da61c4e2b286f39ec827a28d59->leave($__internal_bd6c11729c1efd848d4ff8d0efc61263c564f7da61c4e2b286f39ec827a28d59_prof);

    }

    // line 5
    public function block_connection($context, array $blocks = array())
    {
        $__internal_a131e68aadf213c4f853e8a5b89ab1c656af14972503ee85ff9fb6c671b3dc70 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a131e68aadf213c4f853e8a5b89ab1c656af14972503ee85ff9fb6c671b3dc70->enter($__internal_a131e68aadf213c4f853e8a5b89ab1c656af14972503ee85ff9fb6c671b3dc70_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "connection"));

        // line 6
        echo "    <div class=\"connection\">

        <div class=\"conn-middle\">

            ";
        // line 10
        $this->displayBlock('fos_user_content', $context, $blocks);
        // line 11
        echo "
        </div>



    </div>

";
        
        $__internal_a131e68aadf213c4f853e8a5b89ab1c656af14972503ee85ff9fb6c671b3dc70->leave($__internal_a131e68aadf213c4f853e8a5b89ab1c656af14972503ee85ff9fb6c671b3dc70_prof);

    }

    // line 10
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_6f3777c7b40f5c18be36c8466b218e3431c1c01df270e0d176a39683a47d7da6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6f3777c7b40f5c18be36c8466b218e3431c1c01df270e0d176a39683a47d7da6->enter($__internal_6f3777c7b40f5c18be36c8466b218e3431c1c01df270e0d176a39683a47d7da6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        
        $__internal_6f3777c7b40f5c18be36c8466b218e3431c1c01df270e0d176a39683a47d7da6->leave($__internal_6f3777c7b40f5c18be36c8466b218e3431c1c01df270e0d176a39683a47d7da6_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  75 => 10,  61 => 11,  59 => 10,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layout.html.twig\" %}

{% block title %}{% endblock %}

{% block connection %}
    <div class=\"connection\">

        <div class=\"conn-middle\">

            {% block fos_user_content %}{% endblock %}

        </div>



    </div>

{% endblock %}", "@FOSUser/layout.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/friendsofsymfony/user-bundle/Resources/views/layout.html.twig");
    }
}
