<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_37597e2e857f451f487af544a7aa7a7547582257c5768e6e44ca66ca18ec5179 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c6f3f1081f3ddd3ad4160aeb61db305a833271c4f9338d5e7f2dae9dab64cfa3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c6f3f1081f3ddd3ad4160aeb61db305a833271c4f9338d5e7f2dae9dab64cfa3->enter($__internal_c6f3f1081f3ddd3ad4160aeb61db305a833271c4f9338d5e7f2dae9dab64cfa3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_c6f3f1081f3ddd3ad4160aeb61db305a833271c4f9338d5e7f2dae9dab64cfa3->leave($__internal_c6f3f1081f3ddd3ad4160aeb61db305a833271c4f9338d5e7f2dae9dab64cfa3_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
", "@Framework/Form/percent_widget.html.php", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/percent_widget.html.php");
    }
}
