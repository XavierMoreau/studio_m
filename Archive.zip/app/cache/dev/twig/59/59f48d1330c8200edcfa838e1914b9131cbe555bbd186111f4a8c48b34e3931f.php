<?php

/* FOSUserBundle:Resetting:email.txt.twig */
class __TwigTemplate_6df510ebba2302f8e98d4aea1c5c9a10ae548b1a63db4b3bd564ea4b61a1188b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9b32a4580cf8335551ee472f1e9ee26931f19f5df8b5b9418070b9a8381b80e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9b32a4580cf8335551ee472f1e9ee26931f19f5df8b5b9418070b9a8381b80e0->enter($__internal_9b32a4580cf8335551ee472f1e9ee26931f19f5df8b5b9418070b9a8381b80e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        echo "
";
        // line 8
        $this->displayBlock('body_text', $context, $blocks);
        // line 13
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_9b32a4580cf8335551ee472f1e9ee26931f19f5df8b5b9418070b9a8381b80e0->leave($__internal_9b32a4580cf8335551ee472f1e9ee26931f19f5df8b5b9418070b9a8381b80e0_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_9624074bd3c9d67372485b3cdd0d9cc3589c736c79a50f69444352c86f5187ee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9624074bd3c9d67372485b3cdd0d9cc3589c736c79a50f69444352c86f5187ee->enter($__internal_9624074bd3c9d67372485b3cdd0d9cc3589c736c79a50f69444352c86f5187ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.email.subject", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array())), "FOSUserBundle");
        
        $__internal_9624074bd3c9d67372485b3cdd0d9cc3589c736c79a50f69444352c86f5187ee->leave($__internal_9624074bd3c9d67372485b3cdd0d9cc3589c736c79a50f69444352c86f5187ee_prof);

    }

    // line 8
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_fd76de96a20a7097f7fadcc022fc95090911c95dacaed50a9f1e613bd0545673 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fd76de96a20a7097f7fadcc022fc95090911c95dacaed50a9f1e613bd0545673->enter($__internal_fd76de96a20a7097f7fadcc022fc95090911c95dacaed50a9f1e613bd0545673_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.email.message", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_fd76de96a20a7097f7fadcc022fc95090911c95dacaed50a9f1e613bd0545673->leave($__internal_fd76de96a20a7097f7fadcc022fc95090911c95dacaed50a9f1e613bd0545673_prof);

    }

    // line 13
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_da5b0422f8446a057b61d0a2e19e0b1fd894aef97146cb5bdec88fa89d300eb8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_da5b0422f8446a057b61d0a2e19e0b1fd894aef97146cb5bdec88fa89d300eb8->enter($__internal_da5b0422f8446a057b61d0a2e19e0b1fd894aef97146cb5bdec88fa89d300eb8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_da5b0422f8446a057b61d0a2e19e0b1fd894aef97146cb5bdec88fa89d300eb8->leave($__internal_da5b0422f8446a057b61d0a2e19e0b1fd894aef97146cb5bdec88fa89d300eb8_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  67 => 13,  58 => 10,  52 => 8,  45 => 4,  39 => 2,  32 => 13,  30 => 8,  27 => 7,  25 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}
{% block subject %}
{%- autoescape false -%}
{{ 'resetting.email.subject'|trans({'%username%': user.username}) }}
{%- endautoescape -%}
{% endblock %}

{% block body_text %}
{% autoescape false %}
{{ 'resetting.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}
{% endautoescape %}
{% endblock %}
{% block body_html %}{% endblock %}
", "FOSUserBundle:Resetting:email.txt.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/friendsofsymfony/user-bundle/Resources/views/Resetting/email.txt.twig");
    }
}
