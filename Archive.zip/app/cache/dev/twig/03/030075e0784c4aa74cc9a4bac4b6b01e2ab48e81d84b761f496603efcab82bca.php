<?php

/* UserBundle:Default:index.html.twig */
class __TwigTemplate_47283511b3d394a880c3961898b44c41358140b636714ec2ce4c5049f7580ae5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_104c6abc3c8a5a789ae184bad8cb0ae86ced54c17d926fbca134f9cf92710c71 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_104c6abc3c8a5a789ae184bad8cb0ae86ced54c17d926fbca134f9cf92710c71->enter($__internal_104c6abc3c8a5a789ae184bad8cb0ae86ced54c17d926fbca134f9cf92710c71_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "UserBundle:Default:index.html.twig"));

        // line 1
        echo "Hello World!
";
        
        $__internal_104c6abc3c8a5a789ae184bad8cb0ae86ced54c17d926fbca134f9cf92710c71->leave($__internal_104c6abc3c8a5a789ae184bad8cb0ae86ced54c17d926fbca134f9cf92710c71_prof);

    }

    public function getTemplateName()
    {
        return "UserBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Hello World!
", "UserBundle:Default:index.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/src/UserBundle/Resources/views/Default/index.html.twig");
    }
}
