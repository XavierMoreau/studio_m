<?php

/* FOSUserBundle:Profile:show.html.twig */
class __TwigTemplate_68f4ab65a525ce5eadbe1856b7960db8280c5842e5ac243297ad68ed2fafd489 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Profile:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e4bf40d0fdbc3beea38bb5326faffff7ac4f216d3bb5e257414ad56541a7b364 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e4bf40d0fdbc3beea38bb5326faffff7ac4f216d3bb5e257414ad56541a7b364->enter($__internal_e4bf40d0fdbc3beea38bb5326faffff7ac4f216d3bb5e257414ad56541a7b364_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e4bf40d0fdbc3beea38bb5326faffff7ac4f216d3bb5e257414ad56541a7b364->leave($__internal_e4bf40d0fdbc3beea38bb5326faffff7ac4f216d3bb5e257414ad56541a7b364_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_ff528d9323f74bc42b1ecac3a4af9a4674f696a6db9931f043e41fb27cce9d77 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ff528d9323f74bc42b1ecac3a4af9a4674f696a6db9931f043e41fb27cce9d77->enter($__internal_ff528d9323f74bc42b1ecac3a4af9a4674f696a6db9931f043e41fb27cce9d77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Profile:show_content.html.twig", "FOSUserBundle:Profile:show.html.twig", 4)->display($context);
        
        $__internal_ff528d9323f74bc42b1ecac3a4af9a4674f696a6db9931f043e41fb27cce9d77->leave($__internal_ff528d9323f74bc42b1ecac3a4af9a4674f696a6db9931f043e41fb27cce9d77_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:Profile:show_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Profile:show.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/src/UserBundle/Resources/views/Profile/show.html.twig");
    }
}
