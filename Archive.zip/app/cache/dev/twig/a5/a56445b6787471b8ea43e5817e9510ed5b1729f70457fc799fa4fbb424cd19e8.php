<?php

/* FOSUserBundle:Profile:show.html.twig */
class __TwigTemplate_68f4ab65a525ce5eadbe1856b7960db8280c5842e5ac243297ad68ed2fafd489 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Profile:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0e7f5a4951ca1d64b677714eb984e39a7422447914c4e461bd10207da7eca3ab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0e7f5a4951ca1d64b677714eb984e39a7422447914c4e461bd10207da7eca3ab->enter($__internal_0e7f5a4951ca1d64b677714eb984e39a7422447914c4e461bd10207da7eca3ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0e7f5a4951ca1d64b677714eb984e39a7422447914c4e461bd10207da7eca3ab->leave($__internal_0e7f5a4951ca1d64b677714eb984e39a7422447914c4e461bd10207da7eca3ab_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_4ea986c1def169e2fb467cfb16675e433895432e53c4b4faf63145fa34577d95 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4ea986c1def169e2fb467cfb16675e433895432e53c4b4faf63145fa34577d95->enter($__internal_4ea986c1def169e2fb467cfb16675e433895432e53c4b4faf63145fa34577d95_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Profile:show_content.html.twig", "FOSUserBundle:Profile:show.html.twig", 4)->display($context);
        
        $__internal_4ea986c1def169e2fb467cfb16675e433895432e53c4b4faf63145fa34577d95->leave($__internal_4ea986c1def169e2fb467cfb16675e433895432e53c4b4faf63145fa34577d95_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:Profile:show_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Profile:show.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/src/UserBundle/Resources/views/Profile/show.html.twig");
    }
}
