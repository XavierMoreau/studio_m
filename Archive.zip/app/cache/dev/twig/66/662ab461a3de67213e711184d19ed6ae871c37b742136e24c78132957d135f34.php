<?php

/* @Framework/Form/form_rows.html.php */
class __TwigTemplate_1748f82e0d072ddd45afa6299ed458cf5939f110549011c809cf82163294f27c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1b20bdffbb6e6b65465da891af6e1078e3c8847a05a31f9dcec9f673c81ff979 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1b20bdffbb6e6b65465da891af6e1078e3c8847a05a31f9dcec9f673c81ff979->enter($__internal_1b20bdffbb6e6b65465da891af6e1078e3c8847a05a31f9dcec9f673c81ff979_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
        
        $__internal_1b20bdffbb6e6b65465da891af6e1078e3c8847a05a31f9dcec9f673c81ff979->leave($__internal_1b20bdffbb6e6b65465da891af6e1078e3c8847a05a31f9dcec9f673c81ff979_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rows.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
", "@Framework/Form/form_rows.html.php", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_rows.html.php");
    }
}
