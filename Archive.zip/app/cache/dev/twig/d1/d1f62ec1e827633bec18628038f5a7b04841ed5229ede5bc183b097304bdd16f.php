<?php

/* :script:show.html.twig */
class __TwigTemplate_288f1a9b55ad1c76953f04b7e8630727eade2d5f75b7cc58516f4422b19c2611 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":script:show.html.twig", 1);
        $this->blocks = array(
            'contentlarge' => array($this, 'block_contentlarge'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e7cccaef3b171f27eec3835feb6462c4f4d630ccb9a5f9e546cc02f0b00f53a4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e7cccaef3b171f27eec3835feb6462c4f4d630ccb9a5f9e546cc02f0b00f53a4->enter($__internal_e7cccaef3b171f27eec3835feb6462c4f4d630ccb9a5f9e546cc02f0b00f53a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":script:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e7cccaef3b171f27eec3835feb6462c4f4d630ccb9a5f9e546cc02f0b00f53a4->leave($__internal_e7cccaef3b171f27eec3835feb6462c4f4d630ccb9a5f9e546cc02f0b00f53a4_prof);

    }

    // line 3
    public function block_contentlarge($context, array $blocks = array())
    {
        $__internal_8c17f4731e1e4c53946dd05ec70de6d14b557531856a22f9170e061683ff0d8b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8c17f4731e1e4c53946dd05ec70de6d14b557531856a22f9170e061683ff0d8b->enter($__internal_8c17f4731e1e4c53946dd05ec70de6d14b557531856a22f9170e061683ff0d8b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contentlarge"));

        // line 4
        echo "






    <div style=\"width: 100%; text-align: center\">

    <a href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_print", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\" target=_blank>
    <img class=\"imgflat\" src=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/printer.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"70\"><h4 style=\"color: #ed7425\">Imprimer</h4></a>

    </div>
    <br>
    <div style=\"width: 100%; text-align: center\">

    <a href=\"#\">
    <img class=\"imgflat\" src=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/hand-shake.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"70\"><h4 style=\"color: #273b7a\">Faire appel à un expert</h4></a>

    </div>
    <br>
    <div style=\"width: 100%; text-align: center\">

    <a href=\"#\">
    <img class=\"imgflat\" src=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/trophy.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"70\"><h4 style=\"color: #c92f00\">Valider le script</h4></a>

    </div>


";
        
        $__internal_8c17f4731e1e4c53946dd05ec70de6d14b557531856a22f9170e061683ff0d8b->leave($__internal_8c17f4731e1e4c53946dd05ec70de6d14b557531856a22f9170e061683ff0d8b_prof);

    }

    public function getTemplateName()
    {
        return ":script:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  75 => 28,  65 => 21,  55 => 14,  51 => 13,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block contentlarge %}







    <div style=\"width: 100%; text-align: center\">

    <a href=\"{{ path('script_print', {'id':app.user.id, 'projet': projet.id, 'script' : script.id})  }}\" target=_blank>
    <img class=\"imgflat\" src=\"{{ asset('images/printer.png')}}\" alt=\"Enregistrer\" height=\"70\"><h4 style=\"color: #ed7425\">Imprimer</h4></a>

    </div>
    <br>
    <div style=\"width: 100%; text-align: center\">

    <a href=\"#\">
    <img class=\"imgflat\" src=\"{{ asset('images/hand-shake.png')}}\" alt=\"Enregistrer\" height=\"70\"><h4 style=\"color: #273b7a\">Faire appel à un expert</h4></a>

    </div>
    <br>
    <div style=\"width: 100%; text-align: center\">

    <a href=\"#\">
    <img class=\"imgflat\" src=\"{{ asset('images/trophy.png')}}\" alt=\"Enregistrer\" height=\"70\"><h4 style=\"color: #c92f00\">Valider le script</h4></a>

    </div>


{% endblock %}", ":script:show.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/script/show.html.twig");
    }
}
