<?php

/* @FOSUser/Security/login.html.twig */
class __TwigTemplate_10cedc1042ed718e2244ca67ef71cc4efa42e42f7954ea79ddef6d18f854ac65 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "@FOSUser/Security/login.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5347bfedfd479b37a95fe481afd19c61ee8d4161c87ee9e6c05bd4689f419f03 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5347bfedfd479b37a95fe481afd19c61ee8d4161c87ee9e6c05bd4689f419f03->enter($__internal_5347bfedfd479b37a95fe481afd19c61ee8d4161c87ee9e6c05bd4689f419f03_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Security/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5347bfedfd479b37a95fe481afd19c61ee8d4161c87ee9e6c05bd4689f419f03->leave($__internal_5347bfedfd479b37a95fe481afd19c61ee8d4161c87ee9e6c05bd4689f419f03_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_04cb1c0b2ef45304572d349f2bd5ac11f8abee89fdfa31fcde1e623b1adeb362 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_04cb1c0b2ef45304572d349f2bd5ac11f8abee89fdfa31fcde1e623b1adeb362->enter($__internal_04cb1c0b2ef45304572d349f2bd5ac11f8abee89fdfa31fcde1e623b1adeb362_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        echo "    ";
        echo twig_include($this->env, $context, "@FOSUser/Security/login_content.html.twig");
        echo "

";
        
        $__internal_04cb1c0b2ef45304572d349f2bd5ac11f8abee89fdfa31fcde1e623b1adeb362->leave($__internal_04cb1c0b2ef45304572d349f2bd5ac11f8abee89fdfa31fcde1e623b1adeb362_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
    {{ include('@FOSUser/Security/login_content.html.twig') }}

{% endblock fos_user_content %}
", "@FOSUser/Security/login.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/friendsofsymfony/user-bundle/Resources/views/Security/login.html.twig");
    }
}
