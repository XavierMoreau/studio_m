<?php

/* TwigBundle:Exception:error403.html.twig */
class __TwigTemplate_c1bd679c47a787dd787f724f7b2467f824e6c8dd2e656382b3df6a637e11f985 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "TwigBundle:Exception:error403.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b4dc2319cca923516e7dfb2d7e4d89e1ae49df3f852d03cd2e0f256cb9a3a48e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b4dc2319cca923516e7dfb2d7e4d89e1ae49df3f852d03cd2e0f256cb9a3a48e->enter($__internal_b4dc2319cca923516e7dfb2d7e4d89e1ae49df3f852d03cd2e0f256cb9a3a48e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error403.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b4dc2319cca923516e7dfb2d7e4d89e1ae49df3f852d03cd2e0f256cb9a3a48e->leave($__internal_b4dc2319cca923516e7dfb2d7e4d89e1ae49df3f852d03cd2e0f256cb9a3a48e_prof);

    }

    // line 4
    public function block_content($context, array $blocks = array())
    {
        $__internal_d23713c13e5c30f5510bc8866d8c8cf025e6f374638adf82e6cee83d41e81d9d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d23713c13e5c30f5510bc8866d8c8cf025e6f374638adf82e6cee83d41e81d9d->enter($__internal_d23713c13e5c30f5510bc8866d8c8cf025e6f374638adf82e6cee83d41e81d9d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 5
        echo "<h1>Accès non autorisé</h1>

";
        
        $__internal_d23713c13e5c30f5510bc8866d8c8cf025e6f374638adf82e6cee83d41e81d9d->leave($__internal_d23713c13e5c30f5510bc8866d8c8cf025e6f374638adf82e6cee83d41e81d9d_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error403.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 5,  34 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layout.html.twig\" %}


{% block content %}
<h1>Accès non autorisé</h1>

{% endblock %}", "TwigBundle:Exception:error403.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/TwigBundle/views/Exception/error403.html.twig");
    }
}
