<?php

/* :scriptquestion:new.html.twig */
class __TwigTemplate_8e7bbef0c7f0c725de194ab6eeb9f7876d24938fb2b503c30c0fea71bf3173be extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":scriptquestion:new.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9dd36663374aa113a8983fee3c73d28b80ec95c4595f1cdc6a9bd7c7c1913f5e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9dd36663374aa113a8983fee3c73d28b80ec95c4595f1cdc6a9bd7c7c1913f5e->enter($__internal_9dd36663374aa113a8983fee3c73d28b80ec95c4595f1cdc6a9bd7c7c1913f5e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":scriptquestion:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9dd36663374aa113a8983fee3c73d28b80ec95c4595f1cdc6a9bd7c7c1913f5e->leave($__internal_9dd36663374aa113a8983fee3c73d28b80ec95c4595f1cdc6a9bd7c7c1913f5e_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_7b428ad8e31ecc63c68794024e1ebc560201ba3a9db7bbbdfeb6269a07640b4d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7b428ad8e31ecc63c68794024e1ebc560201ba3a9db7bbbdfeb6269a07640b4d->enter($__internal_7b428ad8e31ecc63c68794024e1ebc560201ba3a9db7bbbdfeb6269a07640b4d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <h1>Nouvelle question</h1>

    ";
        // line 6
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input class=\"btn btn-primary\" type=\"submit\" value=\"Créer\" />
    <a class=\"btn btn-default\" href=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptquestion_index");
        echo "\">Retour</a>
    ";
        // line 10
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "


";
        
        $__internal_7b428ad8e31ecc63c68794024e1ebc560201ba3a9db7bbbdfeb6269a07640b4d->leave($__internal_7b428ad8e31ecc63c68794024e1ebc560201ba3a9db7bbbdfeb6269a07640b4d_prof);

    }

    public function getTemplateName()
    {
        return ":scriptquestion:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 10,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block content %}
    <h1>Nouvelle question</h1>

    {{ form_start(form) }}
        {{ form_widget(form) }}
        <input class=\"btn btn-primary\" type=\"submit\" value=\"Créer\" />
    <a class=\"btn btn-default\" href=\"{{ path('scriptquestion_index') }}\">Retour</a>
    {{ form_end(form) }}


{% endblock %}
", ":scriptquestion:new.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/scriptquestion/new.html.twig");
    }
}
