<?php

/* :scriptquestion:index.html.twig */
class __TwigTemplate_00ed0497a030defaa548972b8e16e7a913875fe134cc812ee19cb0b5ef23edd1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":scriptquestion:index.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_86e50807ee4a51331c4948c29b629843dbb6ad37f233eb21e8620029646651a4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_86e50807ee4a51331c4948c29b629843dbb6ad37f233eb21e8620029646651a4->enter($__internal_86e50807ee4a51331c4948c29b629843dbb6ad37f233eb21e8620029646651a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":scriptquestion:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_86e50807ee4a51331c4948c29b629843dbb6ad37f233eb21e8620029646651a4->leave($__internal_86e50807ee4a51331c4948c29b629843dbb6ad37f233eb21e8620029646651a4_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_45d492c57dbc7486efcb549f210dcaa9acc5f25ae2a64502cd74fde5b77aab30 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_45d492c57dbc7486efcb549f210dcaa9acc5f25ae2a64502cd74fde5b77aab30->enter($__internal_45d492c57dbc7486efcb549f210dcaa9acc5f25ae2a64502cd74fde5b77aab30_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <h2>Questions posées pour le script :</h2>

    <table>
        <thead>
            <tr>
                <th height=\"30\"></th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["scriptQuestions"]) ? $context["scriptQuestions"] : $this->getContext($context, "scriptQuestions")));
        foreach ($context['_seq'] as $context["_key"] => $context["scriptQuestion"]) {
            // line 16
            echo "            <tr>
                <td height=\"30\">";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($context["scriptQuestion"], "question", array()), "html", null, true);
            echo "</td>
                <td width =\"50\" style=\"text-align: center\"><a class=\"btn-modifier\" href=\"";
            // line 18
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptquestion_edit", array("id" => $this->getAttribute($context["scriptQuestion"], "id", array()))), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-edit\" aria-hidden=\"true\"></span></a></td>
                <td width =\"50\" style=\"text-align: center\"><a class=\"btn-delete\"  href=\"";
            // line 19
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptquestion_delete", array("id" => $this->getAttribute($context["scriptQuestion"], "id", array()))), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-trash\" aria-hidden=\"true\"></span></a></td>

            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['scriptQuestion'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 23
        echo "        <tr>
            <td height=\"40\"></td>
        </tr>
        </tbody>
    </table>



    <h3>Nouvelle question :</h3>
    ";
        // line 32
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
    ";
        // line 33
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
    <input class=\"btn btn-primary\" type=\"submit\" value=\"Créer\" />
    <a class=\"btn btn-default\" href=\"";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_index");
        echo "\">Retour</a>
    ";
        // line 36
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "








";
        
        $__internal_45d492c57dbc7486efcb549f210dcaa9acc5f25ae2a64502cd74fde5b77aab30->leave($__internal_45d492c57dbc7486efcb549f210dcaa9acc5f25ae2a64502cd74fde5b77aab30_prof);

    }

    public function getTemplateName()
    {
        return ":scriptquestion:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  102 => 36,  98 => 35,  93 => 33,  89 => 32,  78 => 23,  68 => 19,  64 => 18,  60 => 17,  57 => 16,  53 => 15,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block content %}
    <h2>Questions posées pour le script :</h2>

    <table>
        <thead>
            <tr>
                <th height=\"30\"></th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        {% for scriptQuestion in scriptQuestions %}
            <tr>
                <td height=\"30\">{{ scriptQuestion.question }}</td>
                <td width =\"50\" style=\"text-align: center\"><a class=\"btn-modifier\" href=\"{{ path('scriptquestion_edit', { 'id': scriptQuestion.id }) }}\"><span class=\"glyphicon glyphicon-edit\" aria-hidden=\"true\"></span></a></td>
                <td width =\"50\" style=\"text-align: center\"><a class=\"btn-delete\"  href=\"{{ path('scriptquestion_delete', { 'id': scriptQuestion.id }) }}\"><span class=\"glyphicon glyphicon-trash\" aria-hidden=\"true\"></span></a></td>

            </tr>
        {% endfor %}
        <tr>
            <td height=\"40\"></td>
        </tr>
        </tbody>
    </table>



    <h3>Nouvelle question :</h3>
    {{ form_start(form) }}
    {{ form_widget(form) }}
    <input class=\"btn btn-primary\" type=\"submit\" value=\"Créer\" />
    <a class=\"btn btn-default\" href=\"{{ path('admin_index') }}\">Retour</a>
    {{ form_end(form) }}








{% endblock %}
", ":scriptquestion:index.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/scriptquestion/index.html.twig");
    }
}
