<?php

/* FOSUserBundle:Group:edit.html.twig */
class __TwigTemplate_0bef8ed6eee0d99ef1c0365006f1e013f78ab6aea7d6cd62dbe8c85b2dcc0ff0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Group:edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d0a0cb057dc81a07286487ec0f6f905ffcdac1ecd8754d178dab17b96a04c065 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d0a0cb057dc81a07286487ec0f6f905ffcdac1ecd8754d178dab17b96a04c065->enter($__internal_d0a0cb057dc81a07286487ec0f6f905ffcdac1ecd8754d178dab17b96a04c065_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d0a0cb057dc81a07286487ec0f6f905ffcdac1ecd8754d178dab17b96a04c065->leave($__internal_d0a0cb057dc81a07286487ec0f6f905ffcdac1ecd8754d178dab17b96a04c065_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_57bc0e7bfcea738e61168e3ece9de6b71a88272495ce3f4d64ee5de8f4903758 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_57bc0e7bfcea738e61168e3ece9de6b71a88272495ce3f4d64ee5de8f4903758->enter($__internal_57bc0e7bfcea738e61168e3ece9de6b71a88272495ce3f4d64ee5de8f4903758_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Group/edit_content.html.twig", "FOSUserBundle:Group:edit.html.twig", 4)->display($context);
        
        $__internal_57bc0e7bfcea738e61168e3ece9de6b71a88272495ce3f4d64ee5de8f4903758->leave($__internal_57bc0e7bfcea738e61168e3ece9de6b71a88272495ce3f4d64ee5de8f4903758_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Group/edit_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:edit.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/friendsofsymfony/user-bundle/Resources/views/Group/edit.html.twig");
    }
}
