<?php

/* FOSUserBundle:Group:edit.html.twig */
class __TwigTemplate_0bef8ed6eee0d99ef1c0365006f1e013f78ab6aea7d6cd62dbe8c85b2dcc0ff0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Group:edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8ec84b343326ab1fbba9a9d765def1310774bf7e240b25ee69fd8e06a3816d7d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ec84b343326ab1fbba9a9d765def1310774bf7e240b25ee69fd8e06a3816d7d->enter($__internal_8ec84b343326ab1fbba9a9d765def1310774bf7e240b25ee69fd8e06a3816d7d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8ec84b343326ab1fbba9a9d765def1310774bf7e240b25ee69fd8e06a3816d7d->leave($__internal_8ec84b343326ab1fbba9a9d765def1310774bf7e240b25ee69fd8e06a3816d7d_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_4904310fd678d1bbb7ec5aad22a0cb1b4d7a24884bb1e6133d50dc1227d8b952 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4904310fd678d1bbb7ec5aad22a0cb1b4d7a24884bb1e6133d50dc1227d8b952->enter($__internal_4904310fd678d1bbb7ec5aad22a0cb1b4d7a24884bb1e6133d50dc1227d8b952_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Group/edit_content.html.twig", "FOSUserBundle:Group:edit.html.twig", 4)->display($context);
        
        $__internal_4904310fd678d1bbb7ec5aad22a0cb1b4d7a24884bb1e6133d50dc1227d8b952->leave($__internal_4904310fd678d1bbb7ec5aad22a0cb1b4d7a24884bb1e6133d50dc1227d8b952_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Group/edit_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:edit.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/friendsofsymfony/user-bundle/Resources/views/Group/edit.html.twig");
    }
}
