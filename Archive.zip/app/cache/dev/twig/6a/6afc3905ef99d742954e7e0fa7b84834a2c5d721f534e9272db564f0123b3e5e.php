<?php

/* :script:edit.html.twig */
class __TwigTemplate_9875414dc8715bd1ace39f43ffc144d4bb1563319194eb63b18d2797a6f9c691 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":script:edit.html.twig", 1);
        $this->blocks = array(
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
            'right' => array($this, 'block_right'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cad23b7c90d0feed483d4850f5d0f4995a27aa3a384dc3886c5019cf66da5011 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cad23b7c90d0feed483d4850f5d0f4995a27aa3a384dc3886c5019cf66da5011->enter($__internal_cad23b7c90d0feed483d4850f5d0f4995a27aa3a384dc3886c5019cf66da5011_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":script:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cad23b7c90d0feed483d4850f5d0f4995a27aa3a384dc3886c5019cf66da5011->leave($__internal_cad23b7c90d0feed483d4850f5d0f4995a27aa3a384dc3886c5019cf66da5011_prof);

    }

    // line 4
    public function block_ariane($context, array $blocks = array())
    {
        $__internal_7068b7c746125e98581eabb736f4861c371c69b4294c03352bde8a4a0e84b42b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7068b7c746125e98581eabb736f4861c371c69b4294c03352bde8a4a0e84b42b->enter($__internal_7068b7c746125e98581eabb736f4861c371c69b4294c03352bde8a4a0e84b42b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ariane"));

        // line 5
        echo "
     <div class=\"ariane grey\">
         <div class=\"ib sub-txt-small fine grey\">Projet en cours : </div><div class=\"ib fine lightgrey bord-droit\"> ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "nomProjet", array()), "html", null, true);
        echo "</div>

         <a href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine\">PROJETS</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Paramètres</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <a href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_orientation", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine\">SCRIPT</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Guide</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_voixoff", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Voix-Off</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Ecriture</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <div class=\"ib fine\">STORYBOARD</div>
         <div class=\"ib fine\">></div>
         <div class=\"ib fine petite\">Ecriture</div>

     </div>

 ";
        
        $__internal_7068b7c746125e98581eabb736f4861c371c69b4294c03352bde8a4a0e84b42b->leave($__internal_7068b7c746125e98581eabb736f4861c371c69b4294c03352bde8a4a0e84b42b_prof);

    }

    // line 41
    public function block_left($context, array $blocks = array())
    {
        $__internal_c793158ebc9f62059ecd9c982fe7b3489434c2f3dbfafcc596fbc4442c01d6aa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c793158ebc9f62059ecd9c982fe7b3489434c2f3dbfafcc596fbc4442c01d6aa->enter($__internal_c793158ebc9f62059ecd9c982fe7b3489434c2f3dbfafcc596fbc4442c01d6aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "left"));

        // line 42
        echo "

<div class=\"ib largeur-questions\">


<table class=\"title-tab\">
        <td class=\"padding-ten hand script-questions\"><h3>Afin d'écrire votre script, répondez aux questions suivantes</h3></td>
    </table>




    <form>


        ";
        // line 57
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["reponses"]) ? $context["reponses"] : $this->getContext($context, "reponses")));
        foreach ($context['_seq'] as $context["_key"] => $context["reponse"]) {
            // line 58
            echo "
        <div class=\"padding-ten\">
            <div class=\"largeur-totale title-txt-petit script-questions\">";
            // line 60
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["reponse"], "question", array()), "question", array()), "html", null, true);
            echo "</div>

                <label for=\"";
            // line 62
            echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "id", array()), "html", null, true);
            echo "\"></label><br>
                <textarea style=\"width:97%\" placeholder=\"Entrez votre réponse...\" rows=\"6\" class=\"questionnaire\" name=\"";
            // line 63
            echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "reponse", array()), "html", null, true);
            echo "</textarea>


            </div>


        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['reponse'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 70
        echo "

        <div class=\"largeur-totale txt-center ib\">
            <button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\" formmethod=\"post\" formaction=\"";
        // line 73
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_reponses_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
                <table class=\"tab-buttons shadow back-questions\">
                    <td>
                        <div class=\"lightgrey\">Enregistrer</div>
                    </td>
                    <td>
                        <img src=\"";
        // line 79
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/save-file-option.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"19\">
                    </td>
                </table>
            </button>
        </div>


    </form>

</div>

";
        
        $__internal_c793158ebc9f62059ecd9c982fe7b3489434c2f3dbfafcc596fbc4442c01d6aa->leave($__internal_c793158ebc9f62059ecd9c982fe7b3489434c2f3dbfafcc596fbc4442c01d6aa_prof);

    }

    // line 94
    public function block_right($context, array $blocks = array())
    {
        $__internal_ed0f460a1221d50dc6678ff7b7124aef838885c5f93165f209fa67500b2b263e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ed0f460a1221d50dc6678ff7b7124aef838885c5f93165f209fa67500b2b263e->enter($__internal_ed0f460a1221d50dc6678ff7b7124aef838885c5f93165f209fa67500b2b263e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "right"));

        // line 95
        echo "
        <table class=\"largeur-totale voixoff-boxes\">

            <td style=\"width:33%\" class=\"txt-center\">
                <div class=\"script-voixoff-box1 back-projet\">
                    <a href=\"";
        // line 100
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_orientation", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
                        <div class=\"ib\">
                            <img src=\"";
        // line 102
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/compass.png"), "html", null, true);
        echo "\" alt=\"Retour\" height=\"30\">
                        </div>
                        <div>
                            <h3 class=\"ib hand petite\"><- Retour</h3>
                        </div>
                        <div class=\"ib txtround2 fine\">
                            <h4 class=\"script-questions\">1</h4>
                        </div>
                        <div class=\"ib hand\">| </div>
                        <div class=\"ib txtround2 fine\">
                            <h4 class=\"script-questions\">2</h4>
                        </div>
                        <div class=\"ib hand\">| </div>
                        <div class=\"ib txtround2 fine\">
                            <h4 class=\"script-questions\">3</h4>
                        </div>
                    </a>
                </div>
            </td>
            <td style=\"width:30%\"></td>

            <td style=\"width:33%\" class=\"txt-center\">
                <div class=\"script-voixoff-box3 back-voixoff\">
                    <a href=\"";
        // line 125
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_voixoff", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">

                    <div class=\"ib\">
                            <img src=\"";
        // line 128
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/microphone.png"), "html", null, true);
        echo "\" alt=\"Retour\" height=\"30\">
                        </div>
                        <div>
                            <h3 class=\"ib hand petite\">Ecrire la voix-off -></h3>
                        </div>
                        <div class=\"ib txtround2 fine\">
                            <h4 class=\"script-voixoff\">3</h4>
                        </div>
                    </a>
                </div>
            </td>

        </table>



";
        
        $__internal_ed0f460a1221d50dc6678ff7b7124aef838885c5f93165f209fa67500b2b263e->leave($__internal_ed0f460a1221d50dc6678ff7b7124aef838885c5f93165f209fa67500b2b263e_prof);

    }

    public function getTemplateName()
    {
        return ":script:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  242 => 128,  236 => 125,  210 => 102,  205 => 100,  198 => 95,  192 => 94,  173 => 79,  164 => 73,  159 => 70,  144 => 63,  140 => 62,  135 => 60,  131 => 58,  127 => 57,  110 => 42,  104 => 41,  86 => 29,  79 => 25,  72 => 21,  65 => 17,  58 => 13,  51 => 9,  46 => 7,  42 => 5,  36 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


 {% block ariane %}

     <div class=\"ariane grey\">
         <div class=\"ib sub-txt-small fine grey\">Projet en cours : </div><div class=\"ib fine lightgrey bord-droit\"> {{ projet.nomProjet }}</div>

         <a href=\"{{ path('projet_index', {'id':app.user.id}) }}\">
             <div class=\"ib fine\">PROJETS</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('projet_edit', {'id':app.user.id, 'projet': projet.id, 'script' : script.id }) }}\">
             <div class=\"ib fine petite\">Paramètres</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <a href=\"{{ path('script_orientation', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine\">SCRIPT</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('script_questions', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine petite\">Guide</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('script_voixoff', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine petite\">Voix-Off</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('scriptecriture_index', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine petite\">Ecriture</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <div class=\"ib fine\">STORYBOARD</div>
         <div class=\"ib fine\">></div>
         <div class=\"ib fine petite\">Ecriture</div>

     </div>

 {% endblock %}

{% block left %}


<div class=\"ib largeur-questions\">


<table class=\"title-tab\">
        <td class=\"padding-ten hand script-questions\"><h3>Afin d'écrire votre script, répondez aux questions suivantes</h3></td>
    </table>




    <form>


        {% for reponse in reponses %}

        <div class=\"padding-ten\">
            <div class=\"largeur-totale title-txt-petit script-questions\">{{ reponse.question.question }}</div>

                <label for=\"{{ reponse.id }}\"></label><br>
                <textarea style=\"width:97%\" placeholder=\"Entrez votre réponse...\" rows=\"6\" class=\"questionnaire\" name=\"{{ reponse.id }}\">{{ reponse.reponse }}</textarea>


            </div>


        {%  endfor %}


        <div class=\"largeur-totale txt-center ib\">
            <button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\" formmethod=\"post\" formaction=\"{{ path('script_reponses_edit',{'id':app.user.id, 'projet': projet.id,'script': projet.script.id})}}\">
                <table class=\"tab-buttons shadow back-questions\">
                    <td>
                        <div class=\"lightgrey\">Enregistrer</div>
                    </td>
                    <td>
                        <img src=\"{{ asset('images/save-file-option.png')}}\" alt=\"Enregistrer\" height=\"19\">
                    </td>
                </table>
            </button>
        </div>


    </form>

</div>

{% endblock %}



{% block right %}

        <table class=\"largeur-totale voixoff-boxes\">

            <td style=\"width:33%\" class=\"txt-center\">
                <div class=\"script-voixoff-box1 back-projet\">
                    <a href=\"{{ path('script_orientation', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
                        <div class=\"ib\">
                            <img src=\"{{ asset('images/compass.png')}}\" alt=\"Retour\" height=\"30\">
                        </div>
                        <div>
                            <h3 class=\"ib hand petite\"><- Retour</h3>
                        </div>
                        <div class=\"ib txtround2 fine\">
                            <h4 class=\"script-questions\">1</h4>
                        </div>
                        <div class=\"ib hand\">| </div>
                        <div class=\"ib txtround2 fine\">
                            <h4 class=\"script-questions\">2</h4>
                        </div>
                        <div class=\"ib hand\">| </div>
                        <div class=\"ib txtround2 fine\">
                            <h4 class=\"script-questions\">3</h4>
                        </div>
                    </a>
                </div>
            </td>
            <td style=\"width:30%\"></td>

            <td style=\"width:33%\" class=\"txt-center\">
                <div class=\"script-voixoff-box3 back-voixoff\">
                    <a href=\"{{ path('script_voixoff', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">

                    <div class=\"ib\">
                            <img src=\"{{ asset('images/microphone.png')}}\" alt=\"Retour\" height=\"30\">
                        </div>
                        <div>
                            <h3 class=\"ib hand petite\">Ecrire la voix-off -></h3>
                        </div>
                        <div class=\"ib txtround2 fine\">
                            <h4 class=\"script-voixoff\">3</h4>
                        </div>
                    </a>
                </div>
            </td>

        </table>



{% endblock %}
", ":script:edit.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/script/edit.html.twig");
    }
}
