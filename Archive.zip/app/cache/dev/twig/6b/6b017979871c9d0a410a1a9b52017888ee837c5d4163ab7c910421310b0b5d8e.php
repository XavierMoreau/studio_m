<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_66f14bb712585e14b5ad57bab2c797eacce9fc8db33c37e00c51f4fa3d59cb33 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6f00e459a89c494f4c1548322d4ff35ef90da5ad6da0081d0cbe8acb874df401 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6f00e459a89c494f4c1548322d4ff35ef90da5ad6da0081d0cbe8acb874df401->enter($__internal_6f00e459a89c494f4c1548322d4ff35ef90da5ad6da0081d0cbe8acb874df401_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_6f00e459a89c494f4c1548322d4ff35ef90da5ad6da0081d0cbe8acb874df401->leave($__internal_6f00e459a89c494f4c1548322d4ff35ef90da5ad6da0081d0cbe8acb874df401_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/hidden_row.html.php");
    }
}
