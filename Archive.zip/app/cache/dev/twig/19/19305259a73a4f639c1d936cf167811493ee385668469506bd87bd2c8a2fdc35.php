<?php

/* :support:new.html.twig */
class __TwigTemplate_108ab556ba20bcff0e61904658152d2410697b4dc7e071d615b5e5bba3c6ae6b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":support:new.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ddd128ef934c3d6bbc2d869730d1ec79a89536797d812cc838b72d0e346a26e5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ddd128ef934c3d6bbc2d869730d1ec79a89536797d812cc838b72d0e346a26e5->enter($__internal_ddd128ef934c3d6bbc2d869730d1ec79a89536797d812cc838b72d0e346a26e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":support:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ddd128ef934c3d6bbc2d869730d1ec79a89536797d812cc838b72d0e346a26e5->leave($__internal_ddd128ef934c3d6bbc2d869730d1ec79a89536797d812cc838b72d0e346a26e5_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_279414aac3f1f83a2938742dde03221cc54713242956ab7868b89b023fc41f5e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_279414aac3f1f83a2938742dde03221cc54713242956ab7868b89b023fc41f5e->enter($__internal_279414aac3f1f83a2938742dde03221cc54713242956ab7868b89b023fc41f5e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <h1>Nouveau type de support</h1>

    ";
        // line 6
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input class=\"btn btn-primary\" type=\"submit\" value=\"Créer\" />
    <a class=\"btn btn-default\" href=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("support_index");
        echo "\">Retour</a>
    ";
        // line 10
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "




";
        
        $__internal_279414aac3f1f83a2938742dde03221cc54713242956ab7868b89b023fc41f5e->leave($__internal_279414aac3f1f83a2938742dde03221cc54713242956ab7868b89b023fc41f5e_prof);

    }

    public function getTemplateName()
    {
        return ":support:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 10,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block content %}
    <h1>Nouveau type de support</h1>

    {{ form_start(form) }}
        {{ form_widget(form) }}
        <input class=\"btn btn-primary\" type=\"submit\" value=\"Créer\" />
    <a class=\"btn btn-default\" href=\"{{ path('support_index') }}\">Retour</a>
    {{ form_end(form) }}




{% endblock %}

", ":support:new.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/support/new.html.twig");
    }
}
