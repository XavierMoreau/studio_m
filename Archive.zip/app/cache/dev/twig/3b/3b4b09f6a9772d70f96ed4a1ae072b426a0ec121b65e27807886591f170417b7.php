<?php

/* :diffusion:new.html.twig */
class __TwigTemplate_dff22d92c23501e9b9818872b65ca9b4329592a881a46b10c4f2d8d56655d460 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":diffusion:new.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_434982488ffa96180dd584336f6bcc0805ea0737ab8ed5231268356ef6b8f252 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_434982488ffa96180dd584336f6bcc0805ea0737ab8ed5231268356ef6b8f252->enter($__internal_434982488ffa96180dd584336f6bcc0805ea0737ab8ed5231268356ef6b8f252_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":diffusion:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_434982488ffa96180dd584336f6bcc0805ea0737ab8ed5231268356ef6b8f252->leave($__internal_434982488ffa96180dd584336f6bcc0805ea0737ab8ed5231268356ef6b8f252_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_cbf2f451e0e12759783ad203c03f6553eafe303c168a0bcebf8649cb0a6aecfb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cbf2f451e0e12759783ad203c03f6553eafe303c168a0bcebf8649cb0a6aecfb->enter($__internal_cbf2f451e0e12759783ad203c03f6553eafe303c168a0bcebf8649cb0a6aecfb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <h1>Nouveau type de diffusion</h1>

    ";
        // line 6
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input class=\"btn btn-primary\" type=\"submit\" value=\"Créer\" />
    <a class=\"btn btn-default\" href=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("diffusion_index");
        echo "\">Retour</a>
    ";
        // line 10
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "


";
        
        $__internal_cbf2f451e0e12759783ad203c03f6553eafe303c168a0bcebf8649cb0a6aecfb->leave($__internal_cbf2f451e0e12759783ad203c03f6553eafe303c168a0bcebf8649cb0a6aecfb_prof);

    }

    public function getTemplateName()
    {
        return ":diffusion:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 10,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block content %}
    <h1>Nouveau type de diffusion</h1>

    {{ form_start(form) }}
        {{ form_widget(form) }}
        <input class=\"btn btn-primary\" type=\"submit\" value=\"Créer\" />
    <a class=\"btn btn-default\" href=\"{{ path('diffusion_index') }}\">Retour</a>
    {{ form_end(form) }}


{% endblock %}
", ":diffusion:new.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/diffusion/new.html.twig");
    }
}
