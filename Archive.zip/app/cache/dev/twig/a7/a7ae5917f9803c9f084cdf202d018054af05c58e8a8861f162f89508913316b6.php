<?php

/* @FOSUser/Profile/show.html.twig */
class __TwigTemplate_ecc42d2ec2a92a7096489e284bf9708f8fe9dcc620799ecea479808eb0a614b3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "@FOSUser/Profile/show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2099e649ce41a74fa9c476fdd96f7d55825c89d498fd0645517357af17c8e77a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2099e649ce41a74fa9c476fdd96f7d55825c89d498fd0645517357af17c8e77a->enter($__internal_2099e649ce41a74fa9c476fdd96f7d55825c89d498fd0645517357af17c8e77a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Profile/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2099e649ce41a74fa9c476fdd96f7d55825c89d498fd0645517357af17c8e77a->leave($__internal_2099e649ce41a74fa9c476fdd96f7d55825c89d498fd0645517357af17c8e77a_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_3fdf55704952bdcbe7745a65bed4d08b12250e737c42754a60e4adca24b77817 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3fdf55704952bdcbe7745a65bed4d08b12250e737c42754a60e4adca24b77817->enter($__internal_3fdf55704952bdcbe7745a65bed4d08b12250e737c42754a60e4adca24b77817_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Profile/show_content.html.twig", "@FOSUser/Profile/show.html.twig", 4)->display($context);
        
        $__internal_3fdf55704952bdcbe7745a65bed4d08b12250e737c42754a60e4adca24b77817->leave($__internal_3fdf55704952bdcbe7745a65bed4d08b12250e737c42754a60e4adca24b77817_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Profile/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Profile/show_content.html.twig\" %}
{% endblock fos_user_content %}
", "@FOSUser/Profile/show.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/friendsofsymfony/user-bundle/Resources/views/Profile/show.html.twig");
    }
}
