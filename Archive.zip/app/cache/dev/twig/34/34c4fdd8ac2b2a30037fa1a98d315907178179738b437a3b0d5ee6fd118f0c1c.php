<?php

/* FOSUserBundle:Profile:edit.html.twig */
class __TwigTemplate_2317e4abe85580b1a47df97e53bbb64612d4c734ae13d8d3ffc82476e090327c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Profile:edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b0a62b8a5884e86d58f5d101277b64fd16daa0107b0ec7e08410679201bd88f8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b0a62b8a5884e86d58f5d101277b64fd16daa0107b0ec7e08410679201bd88f8->enter($__internal_b0a62b8a5884e86d58f5d101277b64fd16daa0107b0ec7e08410679201bd88f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b0a62b8a5884e86d58f5d101277b64fd16daa0107b0ec7e08410679201bd88f8->leave($__internal_b0a62b8a5884e86d58f5d101277b64fd16daa0107b0ec7e08410679201bd88f8_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_f11aaa5b46de1ac13dc2d393682d8b5439c6e535d959ad1ba2ee6db194691fe8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f11aaa5b46de1ac13dc2d393682d8b5439c6e535d959ad1ba2ee6db194691fe8->enter($__internal_f11aaa5b46de1ac13dc2d393682d8b5439c6e535d959ad1ba2ee6db194691fe8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Profile:edit_content.html.twig", "FOSUserBundle:Profile:edit.html.twig", 4)->display($context);
        
        $__internal_f11aaa5b46de1ac13dc2d393682d8b5439c6e535d959ad1ba2ee6db194691fe8->leave($__internal_f11aaa5b46de1ac13dc2d393682d8b5439c6e535d959ad1ba2ee6db194691fe8_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:Profile:edit_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Profile:edit.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/src/UserBundle/Resources/views/Profile/edit.html.twig");
    }
}
