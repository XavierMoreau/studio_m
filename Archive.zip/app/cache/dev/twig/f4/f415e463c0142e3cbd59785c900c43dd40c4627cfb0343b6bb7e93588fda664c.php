<?php

/* :conseiltype:show.html.twig */
class __TwigTemplate_ec0c434396b6be7b359f2f0b885161f18a807545fc32ce02febc90957165f729 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":conseiltype:show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_abd8b1cea880689342d5d9effd0feb98fda9b1ee32138bd32e1ce169b282484a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_abd8b1cea880689342d5d9effd0feb98fda9b1ee32138bd32e1ce169b282484a->enter($__internal_abd8b1cea880689342d5d9effd0feb98fda9b1ee32138bd32e1ce169b282484a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":conseiltype:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_abd8b1cea880689342d5d9effd0feb98fda9b1ee32138bd32e1ce169b282484a->leave($__internal_abd8b1cea880689342d5d9effd0feb98fda9b1ee32138bd32e1ce169b282484a_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_185576261aa1cb495e862e97009c8b97a30886ade19cf46f76f2143312bc85f6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_185576261aa1cb495e862e97009c8b97a30886ade19cf46f76f2143312bc85f6->enter($__internal_185576261aa1cb495e862e97009c8b97a30886ade19cf46f76f2143312bc85f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Conseiltype</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["conseilType"]) ? $context["conseilType"] : $this->getContext($context, "conseilType")), "id", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Type</th>
                <td>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["conseilType"]) ? $context["conseilType"] : $this->getContext($context, "conseilType")), "type", array()), "html", null, true);
        echo "</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("conseiltype_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            <a href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("conseiltype_edit", array("id" => $this->getAttribute((isset($context["conseilType"]) ? $context["conseilType"] : $this->getContext($context, "conseilType")), "id", array()))), "html", null, true);
        echo "\">Edit</a>
        </li>
        <li>
            ";
        // line 27
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 29
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_185576261aa1cb495e862e97009c8b97a30886ade19cf46f76f2143312bc85f6->leave($__internal_185576261aa1cb495e862e97009c8b97a30886ade19cf46f76f2143312bc85f6_prof);

    }

    public function getTemplateName()
    {
        return ":conseiltype:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 29,  77 => 27,  71 => 24,  65 => 21,  55 => 14,  48 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Conseiltype</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>{{ conseilType.id }}</td>
            </tr>
            <tr>
                <th>Type</th>
                <td>{{ conseilType.type }}</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"{{ path('conseiltype_index') }}\">Back to the list</a>
        </li>
        <li>
            <a href=\"{{ path('conseiltype_edit', { 'id': conseilType.id }) }}\">Edit</a>
        </li>
        <li>
            {{ form_start(delete_form) }}
                <input type=\"submit\" value=\"Delete\">
            {{ form_end(delete_form) }}
        </li>
    </ul>
{% endblock %}
", ":conseiltype:show.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/conseiltype/show.html.twig");
    }
}
