<?php

/* :projet:index.html.twig */
class __TwigTemplate_bc760e7ea25945a69cb7565ad3362704dd7cce6de698891d761a64ed988b5199 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":projet:index.html.twig", 1);
        $this->blocks = array(
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
            'right' => array($this, 'block_right'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a8aadee31979b29283604aa8ab2d735f03fb92bde7d54f9044be6fd59da1147e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a8aadee31979b29283604aa8ab2d735f03fb92bde7d54f9044be6fd59da1147e->enter($__internal_a8aadee31979b29283604aa8ab2d735f03fb92bde7d54f9044be6fd59da1147e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":projet:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a8aadee31979b29283604aa8ab2d735f03fb92bde7d54f9044be6fd59da1147e->leave($__internal_a8aadee31979b29283604aa8ab2d735f03fb92bde7d54f9044be6fd59da1147e_prof);

    }

    // line 4
    public function block_ariane($context, array $blocks = array())
    {
        $__internal_c08d9af94619789b61d136105ebba0a829f47a290125f8a145ab8902bd9dfaf4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c08d9af94619789b61d136105ebba0a829f47a290125f8a145ab8902bd9dfaf4->enter($__internal_c08d9af94619789b61d136105ebba0a829f47a290125f8a145ab8902bd9dfaf4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ariane"));

        // line 5
        echo "


     ";
        
        $__internal_c08d9af94619789b61d136105ebba0a829f47a290125f8a145ab8902bd9dfaf4->leave($__internal_c08d9af94619789b61d136105ebba0a829f47a290125f8a145ab8902bd9dfaf4_prof);

    }

    // line 11
    public function block_left($context, array $blocks = array())
    {
        $__internal_90a7ec112f76abfa43c0162f14b9744aeaf28356077bfde8107f2f3be6f880a7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_90a7ec112f76abfa43c0162f14b9744aeaf28356077bfde8107f2f3be6f880a7->enter($__internal_90a7ec112f76abfa43c0162f14b9744aeaf28356077bfde8107f2f3be6f880a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "left"));

        // line 12
        echo "<div class=\"ib leftprojet\">

<div class=\"leftprojet-top\">

        <div class=\"txt-center\">
            <div class=\"ib imground\">
                <img src=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/idea.png"), "html", null, true);
        echo "\" alt=\"Nouveau Projet\">
            </div>
            <div>
                <h3 class=\"ib hand\">Vos projets</h3>
            </div>

        </div>

</div>
    <div class=\"leftprojet-photo\">
        <img src=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pic1.jpg"), "html", null, true);
        echo "\" alt=\"Nouveau Projet\">
    </div>
    <div class=\"leftprojet-bottom\">
        <div class=\"fine petite\">
            <p>Créez votre projet, renseignez les types de supports, les types diffusions, les types d'utilisations.
                Vous pouvez aussi indiquer pour quand votre projet est prévu ainsi que sa surée dans le temps.
            </p>
            <p>Toutes ces données nous permettront de calculer les droits et le montant approximatif de votre projet.
            </p>
            <p>Ensuite vous pourrez écrire votre script, puis votre stroy-board</p>



            </div>
        </div>



</div>

";
        
        $__internal_90a7ec112f76abfa43c0162f14b9744aeaf28356077bfde8107f2f3be6f880a7->leave($__internal_90a7ec112f76abfa43c0162f14b9744aeaf28356077bfde8107f2f3be6f880a7_prof);

    }

    // line 50
    public function block_right($context, array $blocks = array())
    {
        $__internal_08d3bf019cd5d0856c6790b0caf180b0b4652e7b5e5913abac76e9796c2a7557 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_08d3bf019cd5d0856c6790b0caf180b0b4652e7b5e5913abac76e9796c2a7557->enter($__internal_08d3bf019cd5d0856c6790b0caf180b0b4652e7b5e5913abac76e9796c2a7557_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "right"));

        // line 51
        echo "
<div class=\"ib rightprojet\">
    <div class=\"rightprojet-photo\">

        <a href=\"";
        // line 55
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_new", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()))), "html", null, true);
        echo "\">
            <div class=\"leftprojet-photo\">
                <img src=\"";
        // line 57
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pic2.jpg"), "html", null, true);
        echo "\" alt=\"Nouveau Projet\">
                <div class=\"rightprojet-photo-txt hand\">Créez votre nouveau projet ici...</div>
            </div>
        </a>

    </div>



<div class=\"rightprojet-list\">

    ";
        // line 68
        if ((isset($context["projets"]) ? $context["projets"] : $this->getContext($context, "projets"))) {
            // line 69
            echo "
        ";
            // line 70
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["projets"]) ? $context["projets"] : $this->getContext($context, "projets")));
            foreach ($context['_seq'] as $context["_key"] => $context["projet"]) {
                // line 71
                echo "
            <div class=\"padding-ten\" style=\"background-color: white\">
                <table style=\"width:100%\">
                    <tr>
                        <td colspan=\"4\">
                            <div>

                                <h4 class=\"ib sub-txt-big projet\">";
                // line 78
                echo twig_escape_filter($this->env, $this->getAttribute($context["projet"], "nomProjet", array()), "html", null, true);
                echo "</h4>


                                <div class=\"ib\">
                                    <div class=\"ib sub-txt-small grey\">
                                        Créé le :
                                    </div>
                                    <div class=\"ib sub-txt-small projet\">
                                        ";
                // line 86
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($context["projet"], "dateCreation", array()), "date", array()), "d/m/Y"), "html", null, true);
                echo "
                                    </div>

                                    ";
                // line 89
                if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_ADMIN")) {
                    // line 90
                    echo "                                        <div class=\"ib sub-txt-small grey\">
                                            par
                                        </div>
                                        <div class=\"ib sub-txt-small projet\">
                                            ";
                    // line 94
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["projet"], "utilisateur", array()), "prenom", array()), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["projet"], "utilisateur", array()), "nom", array()), "html", null, true);
                    echo " (";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["projet"], "utilisateur", array()), "username", array()), "html", null, true);
                    echo ")
                                        </div>
                                    ";
                }
                // line 97
                echo "                                </div>

                                <div>
                                    <div class=\"ib sub-txt-small grey\">
                                        Supports :
                                    </div>
                                    ";
                // line 103
                $context["arraySupport"] = $this->getAttribute($this->getAttribute($context["projet"], "support", array()), "getValues", array());
                // line 104
                echo "                                    ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["arraySupport"]) ? $context["arraySupport"] : $this->getContext($context, "arraySupport")));
                foreach ($context['_seq'] as $context["_key"] => $context["support"]) {
                    // line 105
                    echo "                                        <div class=\"ib  sub-txt-small projet bord-droit\">
                                            ";
                    // line 106
                    echo twig_escape_filter($this->env, $this->getAttribute($context["support"], "supportType", array()), "html", null, true);
                    echo "
                                        </div>
                                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['support'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 109
                echo "                                </div>
                                <div>
                                    <div class=\"ib sub-txt-small grey\">
                                        Diffusion :
                                    </div>
                                    ";
                // line 114
                $context["arrayDiffusion"] = $this->getAttribute($this->getAttribute($context["projet"], "diffusion", array()), "getValues", array());
                // line 115
                echo "                                    ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["arrayDiffusion"]) ? $context["arrayDiffusion"] : $this->getContext($context, "arrayDiffusion")));
                foreach ($context['_seq'] as $context["_key"] => $context["diffusion"]) {
                    // line 116
                    echo "                                        <div class=\"ib  sub-txt-small projet bord-droit\">
                                            ";
                    // line 117
                    echo twig_escape_filter($this->env, $this->getAttribute($context["diffusion"], "diffusionType", array()), "html", null, true);
                    echo "
                                        </div>
                                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['diffusion'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 120
                echo "                                </div>
                                <div>
                                    <div class=\"ib sub-txt-small grey\">
                                        Utilisation :
                                    </div>
                                    ";
                // line 125
                $context["arrayUtilisation"] = $this->getAttribute($this->getAttribute($context["projet"], "utilisation", array()), "getValues", array());
                // line 126
                echo "                                    ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["arrayUtilisation"]) ? $context["arrayUtilisation"] : $this->getContext($context, "arrayUtilisation")));
                foreach ($context['_seq'] as $context["_key"] => $context["utilisation"]) {
                    // line 127
                    echo "                                        <div class=\"ib  sub-txt-small projet bord-droit\">
                                            ";
                    // line 128
                    echo twig_escape_filter($this->env, $this->getAttribute($context["utilisation"], "utilisationType", array()), "html", null, true);
                    echo "
                                        </div>
                                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['utilisation'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 131
                echo "                                </div>

                                <div class=\"ib\">
                                    <div class=\"ib sub-txt-small grey\">
                                        Diffusion prévue à partir du
                                    </div>
                                    <div class=\"ib  sub-txt-small projet\">
                                        ";
                // line 138
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($context["projet"], "dateDiffusion", array()), "date", array()), "d/m/Y"), "html", null, true);
                echo "
                                    </div>
                                </div>
                                <div class=\"ib\">
                                    <div class=\"ib sub-txt-small grey\">
                                        pour
                                    </div>
                                    <div class=\"ib  sub-txt-small projet\">
                                        ";
                // line 146
                echo twig_escape_filter($this->env, $this->getAttribute($context["projet"], "tempsDiffusion", array()), "html", null, true);
                echo " an(s).
                                    </div>
                                </div>





                            </div>
                    </tr>
                    <tr>

                        </td>
                        <td style=\"text-align: center\"><a href=\"";
                // line 159
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute($context["projet"], "id", array()), "script" => $this->getAttribute($this->getAttribute($context["projet"], "script", array()), "id", array()))), "html", null, true);
                echo "\">
                                <img class=\"imgflat\" src=\"";
                // line 160
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/file.png"), "html", null, true);
                echo "\" alt=\"Modifier projet\" height=\"30\">
                                <div class=\"sub-txt-small projet\">Modifier le projet</div></a></td>
                        <td style=\"text-align: center\">

                            <a href=\"";
                // line 164
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_orientation", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute($context["projet"], "id", array()), "script" => $this->getAttribute($this->getAttribute($context["projet"], "script", array()), "id", array()))), "html", null, true);
                echo "\">
                                <img class=\"imgflat\" src=\"";
                // line 165
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pen.png"), "html", null, true);
                echo "\" alt=\"Script\" height=\"30\">
                                <div class=\"sub-txt-small script\">Ecrire le script</div></a></td>

                        <td style=\"text-align: center\">";
                // line 168
                if ($this->getAttribute($context["projet"], "storyboard", array())) {
                    echo "Accéder au storyboard";
                } else {
                    // line 169
                    echo "                                <img class=\"imgflat\" src=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/play-video.png"), "html", null, true);
                    echo "\" alt=\"Storyboard\" height=\"30\">
                                <div class=\"sub-txt-small\" style=\"color: #9db138\">Ecrire le storyboard</div>";
                }
                // line 170
                echo "</td>

                        <td style=\"text-align: center\"><a href=\"";
                // line 172
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_delete", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute($context["projet"], "id", array()), "script" => $this->getAttribute($this->getAttribute($context["projet"], "script", array()), "id", array()))), "html", null, true);
                echo "\">
                                <img class=\"imgflat\" src=\"";
                // line 173
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/garbage.png"), "html", null, true);
                echo "\" alt=\"Modifier projet\" height=\"30\">
                                <div class=\"sub-txt-small script\">Supprimer le projet</div></a></td>


                    </tr>
                </table>
            </div>
            <div class=\"title-tab\"></div>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['projet'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 182
            echo "
    ";
        } else {
            // line 184
            echo "
        <div class=\"ib sub-txt-small grey\">

            Pas de projet enregistré

        </div>
    ";
        }
        // line 191
        echo "
</div>

</div>
";
        
        $__internal_08d3bf019cd5d0856c6790b0caf180b0b4652e7b5e5913abac76e9796c2a7557->leave($__internal_08d3bf019cd5d0856c6790b0caf180b0b4652e7b5e5913abac76e9796c2a7557_prof);

    }

    public function getTemplateName()
    {
        return ":projet:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  373 => 191,  364 => 184,  360 => 182,  345 => 173,  341 => 172,  337 => 170,  331 => 169,  327 => 168,  321 => 165,  317 => 164,  310 => 160,  306 => 159,  290 => 146,  279 => 138,  270 => 131,  261 => 128,  258 => 127,  253 => 126,  251 => 125,  244 => 120,  235 => 117,  232 => 116,  227 => 115,  225 => 114,  218 => 109,  209 => 106,  206 => 105,  201 => 104,  199 => 103,  191 => 97,  181 => 94,  175 => 90,  173 => 89,  167 => 86,  156 => 78,  147 => 71,  143 => 70,  140 => 69,  138 => 68,  124 => 57,  119 => 55,  113 => 51,  107 => 50,  79 => 28,  66 => 18,  58 => 12,  52 => 11,  42 => 5,  36 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


     {% block ariane %}



     {% endblock %}


{% block left %}
<div class=\"ib leftprojet\">

<div class=\"leftprojet-top\">

        <div class=\"txt-center\">
            <div class=\"ib imground\">
                <img src=\"{{ asset('images/idea.png')}}\" alt=\"Nouveau Projet\">
            </div>
            <div>
                <h3 class=\"ib hand\">Vos projets</h3>
            </div>

        </div>

</div>
    <div class=\"leftprojet-photo\">
        <img src=\"{{ asset('images/pic1.jpg')}}\" alt=\"Nouveau Projet\">
    </div>
    <div class=\"leftprojet-bottom\">
        <div class=\"fine petite\">
            <p>Créez votre projet, renseignez les types de supports, les types diffusions, les types d'utilisations.
                Vous pouvez aussi indiquer pour quand votre projet est prévu ainsi que sa surée dans le temps.
            </p>
            <p>Toutes ces données nous permettront de calculer les droits et le montant approximatif de votre projet.
            </p>
            <p>Ensuite vous pourrez écrire votre script, puis votre stroy-board</p>



            </div>
        </div>



</div>

{% endblock %}

{% block right %}

<div class=\"ib rightprojet\">
    <div class=\"rightprojet-photo\">

        <a href=\"{{ path('projet_new', {'id': app.user.id }) }}\">
            <div class=\"leftprojet-photo\">
                <img src=\"{{ asset('images/pic2.jpg')}}\" alt=\"Nouveau Projet\">
                <div class=\"rightprojet-photo-txt hand\">Créez votre nouveau projet ici...</div>
            </div>
        </a>

    </div>



<div class=\"rightprojet-list\">

    {% if projets %}

        {% for projet in projets %}

            <div class=\"padding-ten\" style=\"background-color: white\">
                <table style=\"width:100%\">
                    <tr>
                        <td colspan=\"4\">
                            <div>

                                <h4 class=\"ib sub-txt-big projet\">{{ projet.nomProjet }}</h4>


                                <div class=\"ib\">
                                    <div class=\"ib sub-txt-small grey\">
                                        Créé le :
                                    </div>
                                    <div class=\"ib sub-txt-small projet\">
                                        {{ projet.dateCreation.date|date('d/m/Y') }}
                                    </div>

                                    {% if is_granted(\"ROLE_ADMIN\") %}
                                        <div class=\"ib sub-txt-small grey\">
                                            par
                                        </div>
                                        <div class=\"ib sub-txt-small projet\">
                                            {{ projet.utilisateur.prenom }} {{ projet.utilisateur.nom}} ({{ projet.utilisateur.username }})
                                        </div>
                                    {% endif %}
                                </div>

                                <div>
                                    <div class=\"ib sub-txt-small grey\">
                                        Supports :
                                    </div>
                                    {% set arraySupport = projet.support.getValues %}
                                    {% for support in arraySupport %}
                                        <div class=\"ib  sub-txt-small projet bord-droit\">
                                            {{ support.supportType }}
                                        </div>
                                    {% endfor %}
                                </div>
                                <div>
                                    <div class=\"ib sub-txt-small grey\">
                                        Diffusion :
                                    </div>
                                    {% set arrayDiffusion = projet.diffusion.getValues %}
                                    {% for diffusion in arrayDiffusion %}
                                        <div class=\"ib  sub-txt-small projet bord-droit\">
                                            {{ diffusion.diffusionType }}
                                        </div>
                                    {% endfor %}
                                </div>
                                <div>
                                    <div class=\"ib sub-txt-small grey\">
                                        Utilisation :
                                    </div>
                                    {% set arrayUtilisation = projet.utilisation.getValues %}
                                    {% for utilisation in arrayUtilisation %}
                                        <div class=\"ib  sub-txt-small projet bord-droit\">
                                            {{ utilisation.utilisationType }}
                                        </div>
                                    {% endfor %}
                                </div>

                                <div class=\"ib\">
                                    <div class=\"ib sub-txt-small grey\">
                                        Diffusion prévue à partir du
                                    </div>
                                    <div class=\"ib  sub-txt-small projet\">
                                        {{ projet.dateDiffusion.date|date('d/m/Y') }}
                                    </div>
                                </div>
                                <div class=\"ib\">
                                    <div class=\"ib sub-txt-small grey\">
                                        pour
                                    </div>
                                    <div class=\"ib  sub-txt-small projet\">
                                        {{ projet.tempsDiffusion }} an(s).
                                    </div>
                                </div>





                            </div>
                    </tr>
                    <tr>

                        </td>
                        <td style=\"text-align: center\"><a href=\"{{ path('projet_edit', {'id':app.user.id, 'projet': projet.id, 'script' : projet.script.id }) }}\">
                                <img class=\"imgflat\" src=\"{{ asset('images/file.png')}}\" alt=\"Modifier projet\" height=\"30\">
                                <div class=\"sub-txt-small projet\">Modifier le projet</div></a></td>
                        <td style=\"text-align: center\">

                            <a href=\"{{ path('script_orientation', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
                                <img class=\"imgflat\" src=\"{{ asset('images/pen.png')}}\" alt=\"Script\" height=\"30\">
                                <div class=\"sub-txt-small script\">Ecrire le script</div></a></td>

                        <td style=\"text-align: center\">{% if projet.storyboard %}Accéder au storyboard{% else %}
                                <img class=\"imgflat\" src=\"{{ asset('images/play-video.png')}}\" alt=\"Storyboard\" height=\"30\">
                                <div class=\"sub-txt-small\" style=\"color: #9db138\">Ecrire le storyboard</div>{% endif %}</td>

                        <td style=\"text-align: center\"><a href=\"{{ path('projet_delete', {'id':app.user.id, 'projet': projet.id, 'script': projet.script.id}) }}\">
                                <img class=\"imgflat\" src=\"{{ asset('images/garbage.png')}}\" alt=\"Modifier projet\" height=\"30\">
                                <div class=\"sub-txt-small script\">Supprimer le projet</div></a></td>


                    </tr>
                </table>
            </div>
            <div class=\"title-tab\"></div>
        {% endfor %}

    {% else %}

        <div class=\"ib sub-txt-small grey\">

            Pas de projet enregistré

        </div>
    {% endif %}

</div>

</div>
{% endblock %}

", ":projet:index.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/projet/index.html.twig");
    }
}
