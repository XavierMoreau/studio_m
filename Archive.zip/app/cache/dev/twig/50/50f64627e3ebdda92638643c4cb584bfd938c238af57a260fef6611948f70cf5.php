<?php

/* :projet:index.html.twig */
class __TwigTemplate_bc760e7ea25945a69cb7565ad3362704dd7cce6de698891d761a64ed988b5199 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":projet:index.html.twig", 1);
        $this->blocks = array(
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
            'right' => array($this, 'block_right'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_313bef50706fe6a258bbe12f7353370eb4bf3fb864ae9b50b7eb252fea0a9db8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_313bef50706fe6a258bbe12f7353370eb4bf3fb864ae9b50b7eb252fea0a9db8->enter($__internal_313bef50706fe6a258bbe12f7353370eb4bf3fb864ae9b50b7eb252fea0a9db8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":projet:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_313bef50706fe6a258bbe12f7353370eb4bf3fb864ae9b50b7eb252fea0a9db8->leave($__internal_313bef50706fe6a258bbe12f7353370eb4bf3fb864ae9b50b7eb252fea0a9db8_prof);

    }

    // line 4
    public function block_ariane($context, array $blocks = array())
    {
        $__internal_280788d9e83e5c064ba023fa4a28d749be31eb2f30e2b6e3e73e5a530d9e934b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_280788d9e83e5c064ba023fa4a28d749be31eb2f30e2b6e3e73e5a530d9e934b->enter($__internal_280788d9e83e5c064ba023fa4a28d749be31eb2f30e2b6e3e73e5a530d9e934b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ariane"));

        // line 5
        echo "
         <div class=\"ariane grey\">
             <div class=\"ib fine\">PROJETS</div>
             <div class=\"ib fine petite\">Paramètres</div>
             <div class=\"ib padding-ten fine\">></div>
             <div class=\"ib fine\">SCRIPT</div>
             <div class=\"ib fine petite\">Guide</div>
             <div class=\"ib fine petite\">Voix-Off</div>
             <div class=\"ib fine petite\">Ecriture</div>
             <div class=\"ib padding-ten fine\">></div>
             <div class=\"ib fine\">STORYBOARD</div>
             <div class=\"ib fine petite\">Ecriture</div>

         </div>

     ";
        
        $__internal_280788d9e83e5c064ba023fa4a28d749be31eb2f30e2b6e3e73e5a530d9e934b->leave($__internal_280788d9e83e5c064ba023fa4a28d749be31eb2f30e2b6e3e73e5a530d9e934b_prof);

    }

    // line 23
    public function block_left($context, array $blocks = array())
    {
        $__internal_351aac275756bfe04b2906863aa24ab164d992efffbfb0bd5aed1af2f817bd8e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_351aac275756bfe04b2906863aa24ab164d992efffbfb0bd5aed1af2f817bd8e->enter($__internal_351aac275756bfe04b2906863aa24ab164d992efffbfb0bd5aed1af2f817bd8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "left"));

        // line 24
        echo "<div class=\"ib largeur-half  leftprojet\">


    <a href=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_new", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()))), "html", null, true);
        echo "\">
    <div class=\"txt-center\">
        <div class=\"ib imground\">
            <img src=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/idea.png"), "html", null, true);
        echo "\" alt=\"Nouveau Projet\">
        </div>
       <div>
           <h3 class=\"ib hand\">Créer un nouveau projet</h3>
       </div>

    </div>
    </a>




</div>

";
        
        $__internal_351aac275756bfe04b2906863aa24ab164d992efffbfb0bd5aed1af2f817bd8e->leave($__internal_351aac275756bfe04b2906863aa24ab164d992efffbfb0bd5aed1af2f817bd8e_prof);

    }

    // line 46
    public function block_right($context, array $blocks = array())
    {
        $__internal_ea7f95367d542cff217e02d399dd3cc4be4beb791af511a8bc6a339a97c92b38 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ea7f95367d542cff217e02d399dd3cc4be4beb791af511a8bc6a339a97c92b38->enter($__internal_ea7f95367d542cff217e02d399dd3cc4be4beb791af511a8bc6a339a97c92b38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "right"));

        // line 47
        echo "
<div class=\"ib largeur-half rightprojet\">

    <table class=\"title-tab hand\">
        <td class=\"padding-ten projet hand\"><h3>Vos projets</h3></td>
    </table>


    ";
        // line 55
        if ((isset($context["projets"]) ? $context["projets"] : $this->getContext($context, "projets"))) {
            // line 56
            echo "
";
            // line 57
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["projets"]) ? $context["projets"] : $this->getContext($context, "projets")));
            foreach ($context['_seq'] as $context["_key"] => $context["projet"]) {
                // line 58
                echo "
    <div class=\"padding-ten\" style=\"background-color: white\">
    <table style=\"width:100%\">
            <tr>
               <td colspan=\"4\">
                    <div>

                       <h4 class=\"ib sub-txt-big projet\">";
                // line 65
                echo twig_escape_filter($this->env, $this->getAttribute($context["projet"], "nomProjet", array()), "html", null, true);
                echo "</h4>


                        <div class=\"ib\">
                            <div class=\"ib sub-txt-small grey\">
                                Créé le :
                            </div>
                            <div class=\"ib sub-txt-small projet\">
                                ";
                // line 73
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($context["projet"], "dateCreation", array()), "date", array()), "d/m/Y"), "html", null, true);
                echo "
                            </div>

                            ";
                // line 76
                if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_ADMIN")) {
                    // line 77
                    echo "                                <div class=\"ib sub-txt-small grey\">
                                    par
                                </div>
                                <div class=\"ib sub-txt-small projet\">
                                    ";
                    // line 81
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["projet"], "utilisateur", array()), "prenom", array()), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["projet"], "utilisateur", array()), "nom", array()), "html", null, true);
                    echo " (";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["projet"], "utilisateur", array()), "username", array()), "html", null, true);
                    echo ")
                                </div>
                            ";
                }
                // line 84
                echo "                        </div>

                        <div>
                            <div class=\"ib sub-txt-small grey\">
                                Supports :
                            </div>
                            ";
                // line 90
                $context["arraySupport"] = $this->getAttribute($this->getAttribute($context["projet"], "support", array()), "getValues", array());
                // line 91
                echo "                            ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["arraySupport"]) ? $context["arraySupport"] : $this->getContext($context, "arraySupport")));
                foreach ($context['_seq'] as $context["_key"] => $context["support"]) {
                    // line 92
                    echo "                                <div class=\"ib  sub-txt-small projet bord-droit\">
                                    ";
                    // line 93
                    echo twig_escape_filter($this->env, $this->getAttribute($context["support"], "supportType", array()), "html", null, true);
                    echo "
                                </div>
                            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['support'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 96
                echo "                        </div>
                        <div>
                            <div class=\"ib sub-txt-small grey\">
                                Diffusion :
                            </div>
                            ";
                // line 101
                $context["arrayDiffusion"] = $this->getAttribute($this->getAttribute($context["projet"], "diffusion", array()), "getValues", array());
                // line 102
                echo "                            ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["arrayDiffusion"]) ? $context["arrayDiffusion"] : $this->getContext($context, "arrayDiffusion")));
                foreach ($context['_seq'] as $context["_key"] => $context["diffusion"]) {
                    // line 103
                    echo "                                <div class=\"ib  sub-txt-small projet bord-droit\">
                                    ";
                    // line 104
                    echo twig_escape_filter($this->env, $this->getAttribute($context["diffusion"], "diffusionType", array()), "html", null, true);
                    echo "
                                </div>
                            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['diffusion'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 107
                echo "                        </div>
                        <div>
                            <div class=\"ib sub-txt-small grey\">
                                Utilisation :
                            </div>
                            ";
                // line 112
                $context["arrayUtilisation"] = $this->getAttribute($this->getAttribute($context["projet"], "utilisation", array()), "getValues", array());
                // line 113
                echo "                            ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["arrayUtilisation"]) ? $context["arrayUtilisation"] : $this->getContext($context, "arrayUtilisation")));
                foreach ($context['_seq'] as $context["_key"] => $context["utilisation"]) {
                    // line 114
                    echo "                                <div class=\"ib  sub-txt-small projet bord-droit\">
                                    ";
                    // line 115
                    echo twig_escape_filter($this->env, $this->getAttribute($context["utilisation"], "utilisationType", array()), "html", null, true);
                    echo "
                                </div>
                            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['utilisation'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 118
                echo "                        </div>

                        <div class=\"ib\">
                            <div class=\"ib sub-txt-small grey\">
                                Diffusion prévue à partir du
                            </div>
                            <div class=\"ib  sub-txt-small projet\">
                                ";
                // line 125
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute($context["projet"], "dateDiffusion", array()), "date", array()), "d/m/Y"), "html", null, true);
                echo "
                            </div>
                        </div>
                        <div class=\"ib\">
                            <div class=\"ib sub-txt-small grey\">
                                pour
                            </div>
                            <div class=\"ib  sub-txt-small projet\">
                                ";
                // line 133
                echo twig_escape_filter($this->env, $this->getAttribute($context["projet"], "tempsDiffusion", array()), "html", null, true);
                echo " an(s).
                            </div>
                        </div>





                    </div>
            </tr>
        <tr>

                </td>
                <td style=\"text-align: center\"><a href=\"";
                // line 146
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute($context["projet"], "id", array()), "script" => $this->getAttribute($this->getAttribute($context["projet"], "script", array()), "id", array()))), "html", null, true);
                echo "\">
                        <img class=\"imgflat\" src=\"";
                // line 147
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/file.png"), "html", null, true);
                echo "\" alt=\"Modifier projet\" height=\"30\">
                        <div class=\"sub-txt-small projet\">Modifier le projet</div></a></td>
                <td style=\"text-align: center\">

                    <a href=\"";
                // line 151
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_orientation", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute($context["projet"], "id", array()), "script" => $this->getAttribute($this->getAttribute($context["projet"], "script", array()), "id", array()))), "html", null, true);
                echo "\">
                        <img class=\"imgflat\" src=\"";
                // line 152
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pen.png"), "html", null, true);
                echo "\" alt=\"Script\" height=\"30\">
                        <div class=\"sub-txt-small script\">Ecrire le script</div></a></td>

                <td style=\"text-align: center\">";
                // line 155
                if ($this->getAttribute($context["projet"], "storyboard", array())) {
                    echo "Accéder au storyboard";
                } else {
                    // line 156
                    echo "                        <img class=\"imgflat\" src=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/play-video.png"), "html", null, true);
                    echo "\" alt=\"Storyboard\" height=\"30\">
                        <div class=\"sub-txt-small\" style=\"color: #9db138\">Ecrire le storyboard</div>";
                }
                // line 157
                echo "</td>

                <td style=\"text-align: center\"><a href=\"";
                // line 159
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_delete", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute($context["projet"], "id", array()), "script" => $this->getAttribute($this->getAttribute($context["projet"], "script", array()), "id", array()))), "html", null, true);
                echo "\">
                        <img class=\"imgflat\" src=\"";
                // line 160
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/garbage.png"), "html", null, true);
                echo "\" alt=\"Modifier projet\" height=\"30\">
                        <div class=\"sub-txt-small script\">Supprimer le projet</div></a></td>


            </tr>
    </table>
    </div>
    <div class=\"title-tab\"></div>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['projet'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 169
            echo "
    ";
        } else {
            // line 171
            echo "
    <div class=\"ib sub-txt-small grey\">

        Pas de projet enregistré

    </div>
";
        }
        // line 178
        echo "
</div>
";
        
        $__internal_ea7f95367d542cff217e02d399dd3cc4be4beb791af511a8bc6a339a97c92b38->leave($__internal_ea7f95367d542cff217e02d399dd3cc4be4beb791af511a8bc6a339a97c92b38_prof);

    }

    public function getTemplateName()
    {
        return ":projet:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  354 => 178,  345 => 171,  341 => 169,  326 => 160,  322 => 159,  318 => 157,  312 => 156,  308 => 155,  302 => 152,  298 => 151,  291 => 147,  287 => 146,  271 => 133,  260 => 125,  251 => 118,  242 => 115,  239 => 114,  234 => 113,  232 => 112,  225 => 107,  216 => 104,  213 => 103,  208 => 102,  206 => 101,  199 => 96,  190 => 93,  187 => 92,  182 => 91,  180 => 90,  172 => 84,  162 => 81,  156 => 77,  154 => 76,  148 => 73,  137 => 65,  128 => 58,  124 => 57,  121 => 56,  119 => 55,  109 => 47,  103 => 46,  81 => 30,  75 => 27,  70 => 24,  64 => 23,  42 => 5,  36 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


     {% block ariane %}

         <div class=\"ariane grey\">
             <div class=\"ib fine\">PROJETS</div>
             <div class=\"ib fine petite\">Paramètres</div>
             <div class=\"ib padding-ten fine\">></div>
             <div class=\"ib fine\">SCRIPT</div>
             <div class=\"ib fine petite\">Guide</div>
             <div class=\"ib fine petite\">Voix-Off</div>
             <div class=\"ib fine petite\">Ecriture</div>
             <div class=\"ib padding-ten fine\">></div>
             <div class=\"ib fine\">STORYBOARD</div>
             <div class=\"ib fine petite\">Ecriture</div>

         </div>

     {% endblock %}


{% block left %}
<div class=\"ib largeur-half  leftprojet\">


    <a href=\"{{ path('projet_new', {'id': app.user.id }) }}\">
    <div class=\"txt-center\">
        <div class=\"ib imground\">
            <img src=\"{{ asset('images/idea.png')}}\" alt=\"Nouveau Projet\">
        </div>
       <div>
           <h3 class=\"ib hand\">Créer un nouveau projet</h3>
       </div>

    </div>
    </a>




</div>

{% endblock %}

{% block right %}

<div class=\"ib largeur-half rightprojet\">

    <table class=\"title-tab hand\">
        <td class=\"padding-ten projet hand\"><h3>Vos projets</h3></td>
    </table>


    {% if projets %}

{% for projet in projets %}

    <div class=\"padding-ten\" style=\"background-color: white\">
    <table style=\"width:100%\">
            <tr>
               <td colspan=\"4\">
                    <div>

                       <h4 class=\"ib sub-txt-big projet\">{{ projet.nomProjet }}</h4>


                        <div class=\"ib\">
                            <div class=\"ib sub-txt-small grey\">
                                Créé le :
                            </div>
                            <div class=\"ib sub-txt-small projet\">
                                {{ projet.dateCreation.date|date('d/m/Y') }}
                            </div>

                            {% if is_granted(\"ROLE_ADMIN\") %}
                                <div class=\"ib sub-txt-small grey\">
                                    par
                                </div>
                                <div class=\"ib sub-txt-small projet\">
                                    {{ projet.utilisateur.prenom }} {{ projet.utilisateur.nom}} ({{ projet.utilisateur.username }})
                                </div>
                            {% endif %}
                        </div>

                        <div>
                            <div class=\"ib sub-txt-small grey\">
                                Supports :
                            </div>
                            {% set arraySupport = projet.support.getValues %}
                            {% for support in arraySupport %}
                                <div class=\"ib  sub-txt-small projet bord-droit\">
                                    {{ support.supportType }}
                                </div>
                            {% endfor %}
                        </div>
                        <div>
                            <div class=\"ib sub-txt-small grey\">
                                Diffusion :
                            </div>
                            {% set arrayDiffusion = projet.diffusion.getValues %}
                            {% for diffusion in arrayDiffusion %}
                                <div class=\"ib  sub-txt-small projet bord-droit\">
                                    {{ diffusion.diffusionType }}
                                </div>
                            {% endfor %}
                        </div>
                        <div>
                            <div class=\"ib sub-txt-small grey\">
                                Utilisation :
                            </div>
                            {% set arrayUtilisation = projet.utilisation.getValues %}
                            {% for utilisation in arrayUtilisation %}
                                <div class=\"ib  sub-txt-small projet bord-droit\">
                                    {{ utilisation.utilisationType }}
                                </div>
                            {% endfor %}
                        </div>

                        <div class=\"ib\">
                            <div class=\"ib sub-txt-small grey\">
                                Diffusion prévue à partir du
                            </div>
                            <div class=\"ib  sub-txt-small projet\">
                                {{ projet.dateDiffusion.date|date('d/m/Y') }}
                            </div>
                        </div>
                        <div class=\"ib\">
                            <div class=\"ib sub-txt-small grey\">
                                pour
                            </div>
                            <div class=\"ib  sub-txt-small projet\">
                                {{ projet.tempsDiffusion }} an(s).
                            </div>
                        </div>





                    </div>
            </tr>
        <tr>

                </td>
                <td style=\"text-align: center\"><a href=\"{{ path('projet_edit', {'id':app.user.id, 'projet': projet.id, 'script' : projet.script.id }) }}\">
                        <img class=\"imgflat\" src=\"{{ asset('images/file.png')}}\" alt=\"Modifier projet\" height=\"30\">
                        <div class=\"sub-txt-small projet\">Modifier le projet</div></a></td>
                <td style=\"text-align: center\">

                    <a href=\"{{ path('script_orientation', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
                        <img class=\"imgflat\" src=\"{{ asset('images/pen.png')}}\" alt=\"Script\" height=\"30\">
                        <div class=\"sub-txt-small script\">Ecrire le script</div></a></td>

                <td style=\"text-align: center\">{% if projet.storyboard %}Accéder au storyboard{% else %}
                        <img class=\"imgflat\" src=\"{{ asset('images/play-video.png')}}\" alt=\"Storyboard\" height=\"30\">
                        <div class=\"sub-txt-small\" style=\"color: #9db138\">Ecrire le storyboard</div>{% endif %}</td>

                <td style=\"text-align: center\"><a href=\"{{ path('projet_delete', {'id':app.user.id, 'projet': projet.id, 'script': projet.script.id}) }}\">
                        <img class=\"imgflat\" src=\"{{ asset('images/garbage.png')}}\" alt=\"Modifier projet\" height=\"30\">
                        <div class=\"sub-txt-small script\">Supprimer le projet</div></a></td>


            </tr>
    </table>
    </div>
    <div class=\"title-tab\"></div>
        {% endfor %}

    {% else %}

    <div class=\"ib sub-txt-small grey\">

        Pas de projet enregistré

    </div>
{% endif %}

</div>
{% endblock %}

", ":projet:index.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/projet/index.html.twig");
    }
}
