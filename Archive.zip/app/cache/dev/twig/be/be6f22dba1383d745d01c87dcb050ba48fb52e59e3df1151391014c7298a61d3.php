<?php

/* :projet:edit.html.twig */
class __TwigTemplate_1583ec42ce43b2901608784442a396eea844d5dd5aa0029de9800e5ee9569a61 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":projet:edit.html.twig", 1);
        $this->blocks = array(
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
            'right' => array($this, 'block_right'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_907383a8cfbe4666867ba255e332a27145e66876371ac24c035af12db9644dee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_907383a8cfbe4666867ba255e332a27145e66876371ac24c035af12db9644dee->enter($__internal_907383a8cfbe4666867ba255e332a27145e66876371ac24c035af12db9644dee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":projet:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_907383a8cfbe4666867ba255e332a27145e66876371ac24c035af12db9644dee->leave($__internal_907383a8cfbe4666867ba255e332a27145e66876371ac24c035af12db9644dee_prof);

    }

    // line 3
    public function block_ariane($context, array $blocks = array())
    {
        $__internal_c7e93991a5a82de19d1d90381c3404d0383e8ed6ceccc71b84761f79535eb829 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c7e93991a5a82de19d1d90381c3404d0383e8ed6ceccc71b84761f79535eb829->enter($__internal_c7e93991a5a82de19d1d90381c3404d0383e8ed6ceccc71b84761f79535eb829_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ariane"));

        // line 4
        echo "


";
        
        $__internal_c7e93991a5a82de19d1d90381c3404d0383e8ed6ceccc71b84761f79535eb829->leave($__internal_c7e93991a5a82de19d1d90381c3404d0383e8ed6ceccc71b84761f79535eb829_prof);

    }

    // line 9
    public function block_left($context, array $blocks = array())
    {
        $__internal_753268b9c70dca348fcd54c5e68efd05f2508661b536500c0f115d2e2def5c52 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_753268b9c70dca348fcd54c5e68efd05f2508661b536500c0f115d2e2def5c52->enter($__internal_753268b9c70dca348fcd54c5e68efd05f2508661b536500c0f115d2e2def5c52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "left"));

        // line 10
        echo "<div class=\"ib leftprojet\">

<div class=\"leftprojet-top\">

        <div class=\"txt-center\">
            <div class=\"ib imground\">
                <img src=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/idea.png"), "html", null, true);
        echo "\" alt=\"Nouveau Projet\">
            </div>
            <div>
                <h3 class=\"ib hand\">Modifiez votre projet</h3>
            </div>

        </div>

</div>
    <div class=\"leftprojet-photo\">
        <img src=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pic5.jpg"), "html", null, true);
        echo "\" alt=\"Nouveau Projet\">
    </div>
    <div class=\"leftprojet-bottom\">
        <div class=\"fine petite\"> Créez votre projet, renseignez les types de supports, les types diffusions, les types d'utilisations.
                Vous pouvez aussi indiquer pour quand votre projet est prévu ainsi que sa surée dans le temps.
                Toutes ces données nous permettront de calculer les droits et le montant approximatif de votre projet.



            </div>
        </div>



</div>

";
        
        $__internal_753268b9c70dca348fcd54c5e68efd05f2508661b536500c0f115d2e2def5c52->leave($__internal_753268b9c70dca348fcd54c5e68efd05f2508661b536500c0f115d2e2def5c52_prof);

    }

    // line 44
    public function block_right($context, array $blocks = array())
    {
        $__internal_d22cba10891d63d1cc3ce9db27b50a83c004bb1820760bd3ee5dafff410d3fdd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d22cba10891d63d1cc3ce9db27b50a83c004bb1820760bd3ee5dafff410d3fdd->enter($__internal_d22cba10891d63d1cc3ce9db27b50a83c004bb1820760bd3ee5dafff410d3fdd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "right"));

        // line 45
        echo "
   <div class=\"ib rightprojet-new-edit\">



    ";
        // line 50
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
        ";
        // line 51
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "

<button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\">
    <table class=\"tab-buttons shadow back-projet\">
        <td>
            <div class=\"lightgrey\">Enregistrer</div>
        </td>
        <td>
         <img src=\"";
        // line 59
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/save-file-option.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"19\">
        </td>
    </table>
</button>






    ";
        // line 69
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "



</div>



";
        
        $__internal_d22cba10891d63d1cc3ce9db27b50a83c004bb1820760bd3ee5dafff410d3fdd->leave($__internal_d22cba10891d63d1cc3ce9db27b50a83c004bb1820760bd3ee5dafff410d3fdd_prof);

    }

    public function getTemplateName()
    {
        return ":projet:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  144 => 69,  131 => 59,  120 => 51,  116 => 50,  109 => 45,  103 => 44,  79 => 26,  66 => 16,  58 => 10,  52 => 9,  42 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block ariane %}



{% endblock %}

{% block left %}
<div class=\"ib leftprojet\">

<div class=\"leftprojet-top\">

        <div class=\"txt-center\">
            <div class=\"ib imground\">
                <img src=\"{{ asset('images/idea.png')}}\" alt=\"Nouveau Projet\">
            </div>
            <div>
                <h3 class=\"ib hand\">Modifiez votre projet</h3>
            </div>

        </div>

</div>
    <div class=\"leftprojet-photo\">
        <img src=\"{{ asset('images/pic5.jpg')}}\" alt=\"Nouveau Projet\">
    </div>
    <div class=\"leftprojet-bottom\">
        <div class=\"fine petite\"> Créez votre projet, renseignez les types de supports, les types diffusions, les types d'utilisations.
                Vous pouvez aussi indiquer pour quand votre projet est prévu ainsi que sa surée dans le temps.
                Toutes ces données nous permettront de calculer les droits et le montant approximatif de votre projet.



            </div>
        </div>



</div>

{% endblock %}

{% block right %}

   <div class=\"ib rightprojet-new-edit\">



    {{ form_start(edit_form) }}
        {{ form_widget(edit_form) }}

<button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\">
    <table class=\"tab-buttons shadow back-projet\">
        <td>
            <div class=\"lightgrey\">Enregistrer</div>
        </td>
        <td>
         <img src=\"{{ asset('images/save-file-option.png')}}\" alt=\"Enregistrer\" height=\"19\">
        </td>
    </table>
</button>






    {{ form_end(edit_form) }}



</div>



{% endblock %}

", ":projet:edit.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/projet/edit.html.twig");
    }
}
