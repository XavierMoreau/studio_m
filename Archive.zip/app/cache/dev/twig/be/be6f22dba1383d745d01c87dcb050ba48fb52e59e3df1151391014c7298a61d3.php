<?php

/* :projet:edit.html.twig */
class __TwigTemplate_1583ec42ce43b2901608784442a396eea844d5dd5aa0029de9800e5ee9569a61 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":projet:edit.html.twig", 1);
        $this->blocks = array(
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
            'right' => array($this, 'block_right'),
            'aside' => array($this, 'block_aside'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c49cc026c8778a8600ec53d4bca6ff4014061d7a32496f6af6a7f3998021efa2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c49cc026c8778a8600ec53d4bca6ff4014061d7a32496f6af6a7f3998021efa2->enter($__internal_c49cc026c8778a8600ec53d4bca6ff4014061d7a32496f6af6a7f3998021efa2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":projet:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c49cc026c8778a8600ec53d4bca6ff4014061d7a32496f6af6a7f3998021efa2->leave($__internal_c49cc026c8778a8600ec53d4bca6ff4014061d7a32496f6af6a7f3998021efa2_prof);

    }

    // line 3
    public function block_ariane($context, array $blocks = array())
    {
        $__internal_a8f4c4a37fb08f0faf54b2a96b9cdd22d7172a1099da95fabafcae6df97d5aa6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a8f4c4a37fb08f0faf54b2a96b9cdd22d7172a1099da95fabafcae6df97d5aa6->enter($__internal_a8f4c4a37fb08f0faf54b2a96b9cdd22d7172a1099da95fabafcae6df97d5aa6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ariane"));

        // line 4
        echo "
    <div class=\"ariane grey\">
        <div class=\"ib fine\">PROJETS</div>
        <div class=\"ib fine petite\">Paramètres</div>
        <div class=\"ib padding-ten fine\">></div>
        <div class=\"ib fine\">SCRIPT</div>
        <div class=\"ib fine petite\">Guide</div>
        <div class=\"ib fine petite\">Voix-Off</div>
        <div class=\"ib fine petite\">Ecriture</div>
        <div class=\"ib padding-ten fine\">></div>
        <div class=\"ib fine\">STORYBOARD</div>
        <div class=\"ib fine petite\">Ecriture</div>

    </div>

";
        
        $__internal_a8f4c4a37fb08f0faf54b2a96b9cdd22d7172a1099da95fabafcae6df97d5aa6->leave($__internal_a8f4c4a37fb08f0faf54b2a96b9cdd22d7172a1099da95fabafcae6df97d5aa6_prof);

    }

    // line 21
    public function block_left($context, array $blocks = array())
    {
        $__internal_556ade11118e886aed9da6dfa2b84ca42599f2c795931a59af0b75a120f21c9e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_556ade11118e886aed9da6dfa2b84ca42599f2c795931a59af0b75a120f21c9e->enter($__internal_556ade11118e886aed9da6dfa2b84ca42599f2c795931a59af0b75a120f21c9e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "left"));

        // line 22
        echo "
    <div class=\"ib largeur-un-quart  leftprojet-new-edit\">



        <div class=\"txt-center\">
            <div class=\"ib imground\">
                <img src=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/light-bulb.png"), "html", null, true);
        echo "\" alt=\"Nouveau Projet\">
            </div>


        </div>





    </div>

";
        
        $__internal_556ade11118e886aed9da6dfa2b84ca42599f2c795931a59af0b75a120f21c9e->leave($__internal_556ade11118e886aed9da6dfa2b84ca42599f2c795931a59af0b75a120f21c9e_prof);

    }

    // line 43
    public function block_right($context, array $blocks = array())
    {
        $__internal_18416007c0c7ef63bd56ba2cd7f4f7cdecbad80f430ef481652fbc031f28eb45 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_18416007c0c7ef63bd56ba2cd7f4f7cdecbad80f430ef481652fbc031f28eb45->enter($__internal_18416007c0c7ef63bd56ba2cd7f4f7cdecbad80f430ef481652fbc031f28eb45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "right"));

        // line 44
        echo "
   <div class=\"ib largeur-trois-quarts rightprojet-new-edit\">

    <table class=\"title-tab\">
        <td class=\"padding-ten projet hand\"><h3>Modifiez votre projet</h3></td>
    </table>

    ";
        // line 51
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
        ";
        // line 52
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "

<button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\">
    <table class=\"tab-buttons shadow back-projet\">
        <td>
            <div class=\"lightgrey\">Enregistrer</div>
        </td>
        <td>
         <img src=\"";
        // line 60
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/save-file-option.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"19\">
        </td>
    </table>
</button>






    ";
        // line 70
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "







";
        
        $__internal_18416007c0c7ef63bd56ba2cd7f4f7cdecbad80f430ef481652fbc031f28eb45->leave($__internal_18416007c0c7ef63bd56ba2cd7f4f7cdecbad80f430ef481652fbc031f28eb45_prof);

    }

    // line 81
    public function block_aside($context, array $blocks = array())
    {
        $__internal_09f16a1321dfb0f860ca559d023981cab9da943ceea084b896546ba65c3232db = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_09f16a1321dfb0f860ca559d023981cab9da943ceea084b896546ba65c3232db->enter($__internal_09f16a1321dfb0f860ca559d023981cab9da943ceea084b896546ba65c3232db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "aside"));

        // line 82
        echo "


    <div class=\"largeur-totale txt-center\">
        <img class=\"imgflat\" src=\"";
        // line 86
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/file.png"), "html", null, true);
        echo "\" alt=\"Script\" height=\"50\"><h4 style=\"color: #ff5419\">Projet</h4>
    </div>




    <div class=\"largeur-totale left-menu actuel\">
        <a href=\"";
        // line 93
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\">
            <img class=\"imgflat\" src=\"";
        // line 94
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/parameters.png"), "html", null, true);
        echo "\" alt=\"Voix-off\" height=\"30\">
            <div class=\"ib title-txt-petit projet\">Paramètres</div>
        </a>
    </div>

    <div class=\"largeur-totale txt-center padding-ten\">

        <div class=\"title-tab\">
        </div>
    </div>




    <div class=\"largeur-totale txt-center\">
        <img class=\"imgflat\" src=\"";
        // line 109
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pen.png"), "html", null, true);
        echo "\" alt=\"Script\" height=\"50\"><h4 style=\"color: #34495e\">Script</h4>
    </div>

    <div class=\"largeur-totale left-menu\">
        <a href=\"";
        // line 113
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\">
            <img class=\"imgflat\" src=\"";
        // line 114
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/guide.png"), "html", null, true);
        echo "\" alt=\"Questionnaire\" height=\"30\">
            <div class=\"ib title-txt-petit script\">Questionnaire</div>
        </a>
    </div>

    <div class=\"largeur-totale left-menu\">
        <a href=\"";
        // line 120
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_voixoff", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\">
            <img class=\"imgflat\" src=\"";
        // line 121
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/voixoff1.png"), "html", null, true);
        echo "\" alt=\"Voix-off\" height=\"30\">
            <div class=\"ib title-txt-petit script\">Voix-off</div>
        </a>
    </div>

    <div class=\"largeur-totale left-menu\">
        <a href=\"";
        // line 127
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\">
            <img class=\"imgflat\" src=\"";
        // line 128
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pen-plume.png"), "html", null, true);
        echo "\" alt=\"Script\" height=\"30\">
            <div class=\"ib title-txt-petit script\">Script</div>
        </a>
    </div>





    <div class=\"largeur-totale txt-center padding-ten\">

        <br>
        <div class=\"title-tab\">
        </div>
    </div>

";
        
        $__internal_09f16a1321dfb0f860ca559d023981cab9da943ceea084b896546ba65c3232db->leave($__internal_09f16a1321dfb0f860ca559d023981cab9da943ceea084b896546ba65c3232db_prof);

    }

    public function getTemplateName()
    {
        return ":projet:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  240 => 128,  236 => 127,  227 => 121,  223 => 120,  214 => 114,  210 => 113,  203 => 109,  185 => 94,  181 => 93,  171 => 86,  165 => 82,  159 => 81,  143 => 70,  130 => 60,  119 => 52,  115 => 51,  106 => 44,  100 => 43,  80 => 29,  71 => 22,  65 => 21,  43 => 4,  37 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block ariane %}

    <div class=\"ariane grey\">
        <div class=\"ib fine\">PROJETS</div>
        <div class=\"ib fine petite\">Paramètres</div>
        <div class=\"ib padding-ten fine\">></div>
        <div class=\"ib fine\">SCRIPT</div>
        <div class=\"ib fine petite\">Guide</div>
        <div class=\"ib fine petite\">Voix-Off</div>
        <div class=\"ib fine petite\">Ecriture</div>
        <div class=\"ib padding-ten fine\">></div>
        <div class=\"ib fine\">STORYBOARD</div>
        <div class=\"ib fine petite\">Ecriture</div>

    </div>

{% endblock %}

{% block left %}

    <div class=\"ib largeur-un-quart  leftprojet-new-edit\">



        <div class=\"txt-center\">
            <div class=\"ib imground\">
                <img src=\"{{ asset('images/light-bulb.png')}}\" alt=\"Nouveau Projet\">
            </div>


        </div>





    </div>

{% endblock %}

{% block right %}

   <div class=\"ib largeur-trois-quarts rightprojet-new-edit\">

    <table class=\"title-tab\">
        <td class=\"padding-ten projet hand\"><h3>Modifiez votre projet</h3></td>
    </table>

    {{ form_start(edit_form) }}
        {{ form_widget(edit_form) }}

<button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\">
    <table class=\"tab-buttons shadow back-projet\">
        <td>
            <div class=\"lightgrey\">Enregistrer</div>
        </td>
        <td>
         <img src=\"{{ asset('images/save-file-option.png')}}\" alt=\"Enregistrer\" height=\"19\">
        </td>
    </table>
</button>






    {{ form_end(edit_form) }}







{% endblock %}


{% block aside %}



    <div class=\"largeur-totale txt-center\">
        <img class=\"imgflat\" src=\"{{ asset('images/file.png')}}\" alt=\"Script\" height=\"50\"><h4 style=\"color: #ff5419\">Projet</h4>
    </div>




    <div class=\"largeur-totale left-menu actuel\">
        <a href=\"{{ path('projet_edit', {'id':app.user.id, 'projet': projet.id, 'script' : script.id }) }}\">
            <img class=\"imgflat\" src=\"{{ asset('images/parameters.png')}}\" alt=\"Voix-off\" height=\"30\">
            <div class=\"ib title-txt-petit projet\">Paramètres</div>
        </a>
    </div>

    <div class=\"largeur-totale txt-center padding-ten\">

        <div class=\"title-tab\">
        </div>
    </div>




    <div class=\"largeur-totale txt-center\">
        <img class=\"imgflat\" src=\"{{ asset('images/pen.png')}}\" alt=\"Script\" height=\"50\"><h4 style=\"color: #34495e\">Script</h4>
    </div>

    <div class=\"largeur-totale left-menu\">
        <a href=\"{{ path('script_questions', {'id':app.user.id, 'projet': projet.id, 'script' : script.id}) }}\">
            <img class=\"imgflat\" src=\"{{ asset('images/guide.png')}}\" alt=\"Questionnaire\" height=\"30\">
            <div class=\"ib title-txt-petit script\">Questionnaire</div>
        </a>
    </div>

    <div class=\"largeur-totale left-menu\">
        <a href=\"{{ path('script_voixoff', {'id':app.user.id, 'projet': projet.id, 'script' : script.id}) }}\">
            <img class=\"imgflat\" src=\"{{ asset('images/voixoff1.png')}}\" alt=\"Voix-off\" height=\"30\">
            <div class=\"ib title-txt-petit script\">Voix-off</div>
        </a>
    </div>

    <div class=\"largeur-totale left-menu\">
        <a href=\"{{ path('scriptecriture_index', {'id':app.user.id, 'projet': projet.id,'script': script.id}) }}\">
            <img class=\"imgflat\" src=\"{{ asset('images/pen-plume.png')}}\" alt=\"Script\" height=\"30\">
            <div class=\"ib title-txt-petit script\">Script</div>
        </a>
    </div>





    <div class=\"largeur-totale txt-center padding-ten\">

        <br>
        <div class=\"title-tab\">
        </div>
    </div>

{% endblock %}", ":projet:edit.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/projet/edit.html.twig");
    }
}
