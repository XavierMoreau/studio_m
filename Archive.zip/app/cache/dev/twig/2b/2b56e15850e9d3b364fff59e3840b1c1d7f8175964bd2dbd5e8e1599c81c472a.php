<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_02bff6b5c9a1eb29c7a05f636cbdf8338ced43da71212a10569a8237110deb63 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b5a5a3a2bdaf6091d38a7644ea3d6791a1605b1a4dcbd3e3aeffc03b9cb63aca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b5a5a3a2bdaf6091d38a7644ea3d6791a1605b1a4dcbd3e3aeffc03b9cb63aca->enter($__internal_b5a5a3a2bdaf6091d38a7644ea3d6791a1605b1a4dcbd3e3aeffc03b9cb63aca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_b5a5a3a2bdaf6091d38a7644ea3d6791a1605b1a4dcbd3e3aeffc03b9cb63aca->leave($__internal_b5a5a3a2bdaf6091d38a7644ea3d6791a1605b1a4dcbd3e3aeffc03b9cb63aca_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_row.html.php");
    }
}
