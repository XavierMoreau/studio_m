<?php

/* :script:orientation.html.twig */
class __TwigTemplate_9b1c465eb661f0218d22bb81071ad453d11d03c5dd8722096b9d368d3a7b264d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":script:orientation.html.twig", 1);
        $this->blocks = array(
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_94a980fd0ffbc70296e6f362fb874285d88e2fefce50e8d0ac2dfab196c9853c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_94a980fd0ffbc70296e6f362fb874285d88e2fefce50e8d0ac2dfab196c9853c->enter($__internal_94a980fd0ffbc70296e6f362fb874285d88e2fefce50e8d0ac2dfab196c9853c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":script:orientation.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_94a980fd0ffbc70296e6f362fb874285d88e2fefce50e8d0ac2dfab196c9853c->leave($__internal_94a980fd0ffbc70296e6f362fb874285d88e2fefce50e8d0ac2dfab196c9853c_prof);

    }

    // line 3
    public function block_ariane($context, array $blocks = array())
    {
        $__internal_893af38629388ea614322475a5317acc0d7c3867202cf093c56066669941dbb3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_893af38629388ea614322475a5317acc0d7c3867202cf093c56066669941dbb3->enter($__internal_893af38629388ea614322475a5317acc0d7c3867202cf093c56066669941dbb3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ariane"));

        // line 4
        echo "
     <div class=\"ib ariane grey\">
         <div>
            <div class=\"ib sub-txt-small fine grey\">Projet en cours : </div>
             <div class=\"ib fine lightgrey\"> ";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "nomProjet", array()), "html", null, true);
        echo "</div>
         </div>
         <div class=\"ib\">
             <a href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine\">PROJETS</div>
            </a>
             <div class=\"ib fine\">></div>
             <a href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\">
                 <div class=\"ib fine petite\">Paramètres</div>
             </a>
         </div>
             <div class=\"ib\">
             <div class=\"ib chevron fine\">></div>
             <a href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_orientation", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
                 <div class=\"ib fine\">SCRIPT</div>
             </a>
             <div class=\"ib fine\">></div>
             <a href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
                 <div class=\"ib fine petite\">Guide</div>
             </a>
             <div class=\"ib fine\">></div>
             <a href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_voixoff", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
                 <div class=\"ib fine petite\">Voix-Off</div>
             </a>
             <div class=\"ib fine\">></div>
             <a href=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
                 <div class=\"ib fine petite\">Ecriture</div>
             </a>
         </div>
         <div class=\"ib\">
             <div class=\"ib chevron fine\">></div>
             <div class=\"ib fine\">STORYBOARD</div>
             <div class=\"ib fine\">></div>
             <div class=\"ib fine petite\">Ecriture</div>
         </div>
     </div>


 ";
        
        $__internal_893af38629388ea614322475a5317acc0d7c3867202cf093c56066669941dbb3->leave($__internal_893af38629388ea614322475a5317acc0d7c3867202cf093c56066669941dbb3_prof);

    }

    // line 50
    public function block_left($context, array $blocks = array())
    {
        $__internal_c04a712a8ac8b24929d9e8aed29c71aad2c5237e2f84c83c4e7673532d341393 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c04a712a8ac8b24929d9e8aed29c71aad2c5237e2f84c83c4e7673532d341393->enter($__internal_c04a712a8ac8b24929d9e8aed29c71aad2c5237e2f84c83c4e7673532d341393_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "left"));

        // line 51
        echo "

<div class=\"largeur-totale txt-center\">




    <table class=\"title-tab\">
        <td class=\"padding-ten hand lightgrey\"><h3>Pour écrire votre script, vous souhaitez :</h3></td>
    </table>

    <table class=\"script-orientation-box\">
    <tr>
            <td class=\"largeur-tiers back-questions\">

                <a href=\"";
        // line 66
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">

                <div class=\"ib txtround1 fine\">
                    <h4 class=\"script-questions\">1</h4>
                </div>

                <div>
                    <h3 class=\"ib hand\">Répondre aux questions</h3>
                </div>
                <div class=\"ib imground\">

                    <img src=\"";
        // line 77
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/list.png"), "html", null, true);
        echo "\" alt=\"Script\">
                </div>
                </a>
        <div class=\"img-orientation\">
            <img src=\"";
        // line 81
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pic6.jpg"), "html", null, true);
        echo "\" alt=\"Retour\">
        </div>
            </td>
            <td class=\"largeur-tiers back-voixoff\">

                <a href=\"";
        // line 86
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_voixoff", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">

                <div class=\"ib txtround2 fine\">
                    <h4 class=\"script-voixoff\">2</h4>
                </div>

                <div>
                    <h3 class=\"ib hand\">Ecrire la voix-off</h3>
                </div>
                <div class=\"ib imground\">
                    <img src=\"";
        // line 96
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/microphone.png"), "html", null, true);
        echo "\" alt=\"Script\" >
                </div>
                </a>
        <div class=\"img-orientation\">
            <img src=\"";
        // line 100
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pic9.jpg"), "html", null, true);
        echo "\" alt=\"Retour\">
        </div>

        </td>

            <td class=\"largeur-tiers back-script\">

                <a href=\"";
        // line 107
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">

                <div class=\"ib txtround3 fine\">
                    <h4 class=\"script\">3</h4>
                </div>
                <div>
                    <h3 class=\"ib hand\">Ecrire le script</h3>
                </div>
                <div class=\"ib imground\">
                    <img src=\"";
        // line 116
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pencil.png"), "html", null, true);
        echo "\" alt=\"Retour\">
                </div>
                </a>
                <div class=\"img-orientation\">
                    <img src=\"";
        // line 120
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pic4.jpg"), "html", null, true);
        echo "\" alt=\"Retour\">
                </div>

            </td>
        </tr>


        <tr>

            <td class=\"largeur-tiers orientation-text back-questions fine petite\"> Vous ne maitisez pas l'écriture de script ? Répondez à ces quelques questions qui vous guideront pour la rédaction du script correspondant à votre projet.
            </td>

            <td class=\"largeur-tiers orientation-text back-voixoff fine petite\"> Ecrivez votre voix-off d'un seul bloc et contrôlez la durée estimée en fonction du nombre de mots.
            </td>

            <td class=\"largeur-tiers orientation-text back-script fine petite\"> Ecrivez votre script et votre voix-off en parallèle. Maitrisez le durées des séquences à votre guise.
            </td>
        </tr>


    </table>



</div>





";
        
        $__internal_c04a712a8ac8b24929d9e8aed29c71aad2c5237e2f84c83c4e7673532d341393->leave($__internal_c04a712a8ac8b24929d9e8aed29c71aad2c5237e2f84c83c4e7673532d341393_prof);

    }

    public function getTemplateName()
    {
        return ":script:orientation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  212 => 120,  205 => 116,  193 => 107,  183 => 100,  176 => 96,  163 => 86,  155 => 81,  148 => 77,  134 => 66,  117 => 51,  111 => 50,  90 => 33,  83 => 29,  76 => 25,  69 => 21,  60 => 15,  53 => 11,  47 => 8,  41 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

 {% block ariane %}

     <div class=\"ib ariane grey\">
         <div>
            <div class=\"ib sub-txt-small fine grey\">Projet en cours : </div>
             <div class=\"ib fine lightgrey\"> {{ projet.nomProjet }}</div>
         </div>
         <div class=\"ib\">
             <a href=\"{{ path('projet_index', {'id':app.user.id}) }}\">
             <div class=\"ib fine\">PROJETS</div>
            </a>
             <div class=\"ib fine\">></div>
             <a href=\"{{ path('projet_edit', {'id':app.user.id, 'projet': projet.id, 'script' : script.id }) }}\">
                 <div class=\"ib fine petite\">Paramètres</div>
             </a>
         </div>
             <div class=\"ib\">
             <div class=\"ib chevron fine\">></div>
             <a href=\"{{ path('script_orientation', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
                 <div class=\"ib fine\">SCRIPT</div>
             </a>
             <div class=\"ib fine\">></div>
             <a href=\"{{ path('script_questions', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
                 <div class=\"ib fine petite\">Guide</div>
             </a>
             <div class=\"ib fine\">></div>
             <a href=\"{{ path('script_voixoff', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
                 <div class=\"ib fine petite\">Voix-Off</div>
             </a>
             <div class=\"ib fine\">></div>
             <a href=\"{{ path('scriptecriture_index', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
                 <div class=\"ib fine petite\">Ecriture</div>
             </a>
         </div>
         <div class=\"ib\">
             <div class=\"ib chevron fine\">></div>
             <div class=\"ib fine\">STORYBOARD</div>
             <div class=\"ib fine\">></div>
             <div class=\"ib fine petite\">Ecriture</div>
         </div>
     </div>


 {% endblock %}



{% block left %}


<div class=\"largeur-totale txt-center\">




    <table class=\"title-tab\">
        <td class=\"padding-ten hand lightgrey\"><h3>Pour écrire votre script, vous souhaitez :</h3></td>
    </table>

    <table class=\"script-orientation-box\">
    <tr>
            <td class=\"largeur-tiers back-questions\">

                <a href=\"{{ path('script_questions', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">

                <div class=\"ib txtround1 fine\">
                    <h4 class=\"script-questions\">1</h4>
                </div>

                <div>
                    <h3 class=\"ib hand\">Répondre aux questions</h3>
                </div>
                <div class=\"ib imground\">

                    <img src=\"{{ asset('images/list.png')}}\" alt=\"Script\">
                </div>
                </a>
        <div class=\"img-orientation\">
            <img src=\"{{ asset('images/pic6.jpg')}}\" alt=\"Retour\">
        </div>
            </td>
            <td class=\"largeur-tiers back-voixoff\">

                <a href=\"{{ path('script_voixoff', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">

                <div class=\"ib txtround2 fine\">
                    <h4 class=\"script-voixoff\">2</h4>
                </div>

                <div>
                    <h3 class=\"ib hand\">Ecrire la voix-off</h3>
                </div>
                <div class=\"ib imground\">
                    <img src=\"{{ asset('images/microphone.png')}}\" alt=\"Script\" >
                </div>
                </a>
        <div class=\"img-orientation\">
            <img src=\"{{ asset('images/pic9.jpg')}}\" alt=\"Retour\">
        </div>

        </td>

            <td class=\"largeur-tiers back-script\">

                <a href=\"{{ path('scriptecriture_index', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">

                <div class=\"ib txtround3 fine\">
                    <h4 class=\"script\">3</h4>
                </div>
                <div>
                    <h3 class=\"ib hand\">Ecrire le script</h3>
                </div>
                <div class=\"ib imground\">
                    <img src=\"{{ asset('images/pencil.png')}}\" alt=\"Retour\">
                </div>
                </a>
                <div class=\"img-orientation\">
                    <img src=\"{{ asset('images/pic4.jpg')}}\" alt=\"Retour\">
                </div>

            </td>
        </tr>


        <tr>

            <td class=\"largeur-tiers orientation-text back-questions fine petite\"> Vous ne maitisez pas l'écriture de script ? Répondez à ces quelques questions qui vous guideront pour la rédaction du script correspondant à votre projet.
            </td>

            <td class=\"largeur-tiers orientation-text back-voixoff fine petite\"> Ecrivez votre voix-off d'un seul bloc et contrôlez la durée estimée en fonction du nombre de mots.
            </td>

            <td class=\"largeur-tiers orientation-text back-script fine petite\"> Ecrivez votre script et votre voix-off en parallèle. Maitrisez le durées des séquences à votre guise.
            </td>
        </tr>


    </table>



</div>





{% endblock %}



", ":script:orientation.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/script/orientation.html.twig");
    }
}
