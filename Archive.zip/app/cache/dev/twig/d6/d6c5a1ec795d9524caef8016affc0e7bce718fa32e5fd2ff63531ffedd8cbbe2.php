<?php

/* :script:orientation.html.twig */
class __TwigTemplate_9b1c465eb661f0218d22bb81071ad453d11d03c5dd8722096b9d368d3a7b264d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":script:orientation.html.twig", 1);
        $this->blocks = array(
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ce6694d74b1e69958f4d010b865ecb2d3e7319c62669cebdbd5650b8dcff8c54 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ce6694d74b1e69958f4d010b865ecb2d3e7319c62669cebdbd5650b8dcff8c54->enter($__internal_ce6694d74b1e69958f4d010b865ecb2d3e7319c62669cebdbd5650b8dcff8c54_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":script:orientation.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ce6694d74b1e69958f4d010b865ecb2d3e7319c62669cebdbd5650b8dcff8c54->leave($__internal_ce6694d74b1e69958f4d010b865ecb2d3e7319c62669cebdbd5650b8dcff8c54_prof);

    }

    // line 3
    public function block_ariane($context, array $blocks = array())
    {
        $__internal_9c6e7300ed7adf304ce2bb08c0bc1c4c763f88dac5550aff1c02cc033e6d8531 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9c6e7300ed7adf304ce2bb08c0bc1c4c763f88dac5550aff1c02cc033e6d8531->enter($__internal_9c6e7300ed7adf304ce2bb08c0bc1c4c763f88dac5550aff1c02cc033e6d8531_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ariane"));

        // line 4
        echo "
     <div class=\"ariane grey\">
         <div class=\"ib sub-txt-small fine grey\">Projet en cours : </div><div class=\"ib fine lightgrey bord-droit\"> ";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "nomProjet", array()), "html", null, true);
        echo "</div>

         <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine\">PROJETS</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Paramètres</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <a href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_orientation", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine\">SCRIPT</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Guide</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_voixoff", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Voix-Off</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Ecriture</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <div class=\"ib fine\">STORYBOARD</div>
         <div class=\"ib fine\">></div>
         <div class=\"ib fine petite\">Ecriture</div>

     </div>

 ";
        
        $__internal_9c6e7300ed7adf304ce2bb08c0bc1c4c763f88dac5550aff1c02cc033e6d8531->leave($__internal_9c6e7300ed7adf304ce2bb08c0bc1c4c763f88dac5550aff1c02cc033e6d8531_prof);

    }

    // line 42
    public function block_left($context, array $blocks = array())
    {
        $__internal_60aa4fac5d75880a34e0e651889e94343d275f34f070ea0f4876dbad23c76870 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_60aa4fac5d75880a34e0e651889e94343d275f34f070ea0f4876dbad23c76870->enter($__internal_60aa4fac5d75880a34e0e651889e94343d275f34f070ea0f4876dbad23c76870_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "left"));

        // line 43
        echo "

<div class=\"largeur-totale txt-center\">




    <table class=\"title-tab\">
        <td class=\"padding-ten\"><h3>Pour écrire votre script, vous souhaitez :</h3></td>
    </table>

   <a href=\"";
        // line 54
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">

        <div class=\"ib largeur-un-quart script-orientation-box1 shadow\">
            <div class=\"ib imground\">

                    <img src=\"";
        // line 59
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/list.png"), "html", null, true);
        echo "\" alt=\"Script\">
            </div>
                     <div>
                <h3 class=\"ib hand\">Répondre aux questions</h3>
            </div>
            <div class=\"ib txtround1 fine\">
          <h4 class=\"script-questions\">1</h4>
        </div>
        </div>
    </a>


 <a href=\"";
        // line 71
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_voixoff", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">

     <div class=\"ib largeur-un-quart script-orientation-box2 shadow\">
        <div class=\"ib imground\">
            <img src=\"";
        // line 75
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/microphone.png"), "html", null, true);
        echo "\" alt=\"Script\" >
        </div>
         <div>
            <h3 class=\"ib hand\">Ecrire la voix-off</h3>
        </div>
        <div class=\"ib txtround2 fine\">
          <h4 class=\"script-voixoff\">2</h4>
        </div>
       </div>
            </a>


<a href=\"";
        // line 87
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
    <div class=\"ib largeur-un-quart script-orientation-box3 shadow\">
           <div class=\"ib imground\">
                 <img src=\"";
        // line 90
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pencil.png"), "html", null, true);
        echo "\" alt=\"Retour\">
            </div>
            <div>
                 <h3 class=\"ib hand\">Ecrire le script</h3>
            </div>
            <div class=\"ib txtround3 fine\">
          <h4 class=\"script\">3</h4>
        </div>
    </div>
</a>
</div>

";
        
        $__internal_60aa4fac5d75880a34e0e651889e94343d275f34f070ea0f4876dbad23c76870->leave($__internal_60aa4fac5d75880a34e0e651889e94343d275f34f070ea0f4876dbad23c76870_prof);

    }

    public function getTemplateName()
    {
        return ":script:orientation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  173 => 90,  167 => 87,  152 => 75,  145 => 71,  130 => 59,  122 => 54,  109 => 43,  103 => 42,  85 => 28,  78 => 24,  71 => 20,  64 => 16,  57 => 12,  50 => 8,  45 => 6,  41 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

 {% block ariane %}

     <div class=\"ariane grey\">
         <div class=\"ib sub-txt-small fine grey\">Projet en cours : </div><div class=\"ib fine lightgrey bord-droit\"> {{ projet.nomProjet }}</div>

         <a href=\"{{ path('projet_index', {'id':app.user.id}) }}\">
             <div class=\"ib fine\">PROJETS</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('projet_edit', {'id':app.user.id, 'projet': projet.id, 'script' : script.id }) }}\">
             <div class=\"ib fine petite\">Paramètres</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <a href=\"{{ path('script_orientation', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine\">SCRIPT</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('script_questions', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine petite\">Guide</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('script_voixoff', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine petite\">Voix-Off</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('scriptecriture_index', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine petite\">Ecriture</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <div class=\"ib fine\">STORYBOARD</div>
         <div class=\"ib fine\">></div>
         <div class=\"ib fine petite\">Ecriture</div>

     </div>

 {% endblock %}



{% block left %}


<div class=\"largeur-totale txt-center\">




    <table class=\"title-tab\">
        <td class=\"padding-ten\"><h3>Pour écrire votre script, vous souhaitez :</h3></td>
    </table>

   <a href=\"{{ path('script_questions', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">

        <div class=\"ib largeur-un-quart script-orientation-box1 shadow\">
            <div class=\"ib imground\">

                    <img src=\"{{ asset('images/list.png')}}\" alt=\"Script\">
            </div>
                     <div>
                <h3 class=\"ib hand\">Répondre aux questions</h3>
            </div>
            <div class=\"ib txtround1 fine\">
          <h4 class=\"script-questions\">1</h4>
        </div>
        </div>
    </a>


 <a href=\"{{ path('script_voixoff', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">

     <div class=\"ib largeur-un-quart script-orientation-box2 shadow\">
        <div class=\"ib imground\">
            <img src=\"{{ asset('images/microphone.png')}}\" alt=\"Script\" >
        </div>
         <div>
            <h3 class=\"ib hand\">Ecrire la voix-off</h3>
        </div>
        <div class=\"ib txtround2 fine\">
          <h4 class=\"script-voixoff\">2</h4>
        </div>
       </div>
            </a>


<a href=\"{{ path('scriptecriture_index', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
    <div class=\"ib largeur-un-quart script-orientation-box3 shadow\">
           <div class=\"ib imground\">
                 <img src=\"{{ asset('images/pencil.png')}}\" alt=\"Retour\">
            </div>
            <div>
                 <h3 class=\"ib hand\">Ecrire le script</h3>
            </div>
            <div class=\"ib txtround3 fine\">
          <h4 class=\"script\">3</h4>
        </div>
    </div>
</a>
</div>

{% endblock %}



", ":script:orientation.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/script/orientation.html.twig");
    }
}
