<?php

/* :conseil:new.html.twig */
class __TwigTemplate_8f5e6bc4df2ef83ab327462b336ef08776a7cf0f265258655b5d0bfc5239959d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":conseil:new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_06f3bf923244abf368b213fc4ecee147b21f8e77a5ebe3aa46d2450fc9f1c504 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_06f3bf923244abf368b213fc4ecee147b21f8e77a5ebe3aa46d2450fc9f1c504->enter($__internal_06f3bf923244abf368b213fc4ecee147b21f8e77a5ebe3aa46d2450fc9f1c504_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":conseil:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_06f3bf923244abf368b213fc4ecee147b21f8e77a5ebe3aa46d2450fc9f1c504->leave($__internal_06f3bf923244abf368b213fc4ecee147b21f8e77a5ebe3aa46d2450fc9f1c504_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_82c02a9684ad292d519a5e667e22a00072d83b191968391bae22f64a189b17aa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_82c02a9684ad292d519a5e667e22a00072d83b191968391bae22f64a189b17aa->enter($__internal_82c02a9684ad292d519a5e667e22a00072d83b191968391bae22f64a189b17aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Conseil creation</h1>

    ";
        // line 6
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Create\" />
    ";
        // line 9
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("conseil_index");
        echo "\">Back to the list</a>
        </li>
    </ul>
";
        
        $__internal_82c02a9684ad292d519a5e667e22a00072d83b191968391bae22f64a189b17aa->leave($__internal_82c02a9684ad292d519a5e667e22a00072d83b191968391bae22f64a189b17aa_prof);

    }

    public function getTemplateName()
    {
        return ":conseil:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Conseil creation</h1>

    {{ form_start(form) }}
        {{ form_widget(form) }}
        <input type=\"submit\" value=\"Create\" />
    {{ form_end(form) }}

    <ul>
        <li>
            <a href=\"{{ path('conseil_index') }}\">Back to the list</a>
        </li>
    </ul>
{% endblock %}
", ":conseil:new.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/conseil/new.html.twig");
    }
}
