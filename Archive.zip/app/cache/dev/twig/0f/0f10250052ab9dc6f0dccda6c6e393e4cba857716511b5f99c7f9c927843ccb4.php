<?php

/* layout.html.twig */
class __TwigTemplate_d5979f33548afa47ea10743902cf50c9f624f7c6bdb9498168eb01b9caf82b0f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
            'right' => array($this, 'block_right'),
            'connection' => array($this, 'block_connection'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_07a630405ea802b6eb76f013390447443b880c994b660d752b246fa974f9aab4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_07a630405ea802b6eb76f013390447443b880c994b660d752b246fa974f9aab4->enter($__internal_07a630405ea802b6eb76f013390447443b880c994b660d752b246fa974f9aab4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"fr\">
<head>
    <meta charset=\"UTF-8\">
    <title>
        Bump";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        // line 7
        echo "    </title>
    <link href=\"https://fonts.googleapis.com/css?family=News+Cycle\" rel=\"stylesheet\">
    <link href=\"https://fonts.googleapis.com/css?family=Gloria+Hallelujah|Yanone+Kaffeesatz:200\" rel=\"stylesheet\">
    <link rel=\"stylesheet\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/appli/css/main.css"), "html", null, true);
        echo "\" type=\"text/css\" media=\"all\" />
    ";
        // line 12
        echo "    <link rel=\"icon\" type=\"image/png\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/favicon.png"), "html", null, true);
        echo "\">
</head>
<body>


";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "all", array()));
        foreach ($context['_seq'] as $context["type"] => $context["messages"]) {
            // line 18
            echo "    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["messages"]);
            foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                // line 19
                echo "        <div class=\"";
                echo twig_escape_filter($this->env, $context["type"], "html", null, true);
                echo "\">
            ";
                // line 20
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($context["message"], array(), "FOSUserBundle"), "html", null, true);
                echo "
        </div>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['type'], $context['messages'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "

";
        // line 26
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_USER")) {
            // line 27
            echo "    <header class=\"log\">
            <div class=\"menuleft\">
                <div class=\"headerlogo\">
                   <img src=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/bumplogo-white.png"), "html", null, true);
            echo "\" alt=\"Logo Bump\"></a>
                </div>
                <div class=\"ib sub-txt-small fine grey\">Bonjour</div><div class=\"ib fine lightgrey bord-droit\"> <a href=\"";
            // line 32
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_profile_show");
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "prenom", array()), "html", null, true);
            echo "</a> ! </div>
                ";
            // line 33
            if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_ADMIN")) {
                // line 34
                echo "                    <div class=\"ib fine bord-droit\"><a href=\"";
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_index");
                echo "\">Administration</a></div>
                ";
            }
            // line 36
            echo "                <div class=\" ib fine petite\"><a class=\"deconnexion\" href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_logout");
            echo "\">Déconnexion</a></div>



            </div>



            ";
            // line 44
            $this->displayBlock('ariane', $context, $blocks);
            // line 48
            echo "







    </header>

<main>


        ";
            // line 61
            $this->displayBlock('left', $context, $blocks);
            // line 63
            echo "


        ";
            // line 66
            $this->displayBlock('right', $context, $blocks);
            // line 68
            echo "




</main>



";
        } else {
            // line 78
            echo "    <header>
        <div class=\"headerlogo-nolog\">
            <img src=\"";
            // line 80
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/bumplogo-rouge.png"), "html", null, true);
            echo "\" alt=\"Logo Bump\">
        </div>
    </header>


    <main class=\"nolog\">
        ";
            // line 86
            $this->displayBlock('connection', $context, $blocks);
            // line 88
            echo "    </main>
";
        }
        // line 90
        echo "<footer>Copyright © 2017 Diaphonics <span>●</span> Studio Bump <span>●</span> Contact <span>●</span> Mentions Légales
</footer>

</body>



</html>
";
        
        $__internal_07a630405ea802b6eb76f013390447443b880c994b660d752b246fa974f9aab4->leave($__internal_07a630405ea802b6eb76f013390447443b880c994b660d752b246fa974f9aab4_prof);

    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        $__internal_b1b01803b91e32ea4ec796e681a1ff5b01b347bd6c35987ee8638319d4b93999 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b1b01803b91e32ea4ec796e681a1ff5b01b347bd6c35987ee8638319d4b93999->enter($__internal_b1b01803b91e32ea4ec796e681a1ff5b01b347bd6c35987ee8638319d4b93999_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_b1b01803b91e32ea4ec796e681a1ff5b01b347bd6c35987ee8638319d4b93999->leave($__internal_b1b01803b91e32ea4ec796e681a1ff5b01b347bd6c35987ee8638319d4b93999_prof);

    }

    // line 44
    public function block_ariane($context, array $blocks = array())
    {
        $__internal_a5da2937ff4b0754210958bfb6578d7ff6109cc6beddb8509ffa9d2d6d7ab16f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a5da2937ff4b0754210958bfb6578d7ff6109cc6beddb8509ffa9d2d6d7ab16f->enter($__internal_a5da2937ff4b0754210958bfb6578d7ff6109cc6beddb8509ffa9d2d6d7ab16f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ariane"));

        // line 45
        echo "

            ";
        
        $__internal_a5da2937ff4b0754210958bfb6578d7ff6109cc6beddb8509ffa9d2d6d7ab16f->leave($__internal_a5da2937ff4b0754210958bfb6578d7ff6109cc6beddb8509ffa9d2d6d7ab16f_prof);

    }

    // line 61
    public function block_left($context, array $blocks = array())
    {
        $__internal_f65475d2a49fd36f05de284bdc4c671b49823dda6f64ce700361ffe2dfca3d72 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f65475d2a49fd36f05de284bdc4c671b49823dda6f64ce700361ffe2dfca3d72->enter($__internal_f65475d2a49fd36f05de284bdc4c671b49823dda6f64ce700361ffe2dfca3d72_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "left"));

        // line 62
        echo "        ";
        
        $__internal_f65475d2a49fd36f05de284bdc4c671b49823dda6f64ce700361ffe2dfca3d72->leave($__internal_f65475d2a49fd36f05de284bdc4c671b49823dda6f64ce700361ffe2dfca3d72_prof);

    }

    // line 66
    public function block_right($context, array $blocks = array())
    {
        $__internal_52c015ebccdcd17fda8ed94031325da06e7ee24ebe71fbaaf003375446f62498 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_52c015ebccdcd17fda8ed94031325da06e7ee24ebe71fbaaf003375446f62498->enter($__internal_52c015ebccdcd17fda8ed94031325da06e7ee24ebe71fbaaf003375446f62498_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "right"));

        // line 67
        echo "        ";
        
        $__internal_52c015ebccdcd17fda8ed94031325da06e7ee24ebe71fbaaf003375446f62498->leave($__internal_52c015ebccdcd17fda8ed94031325da06e7ee24ebe71fbaaf003375446f62498_prof);

    }

    // line 86
    public function block_connection($context, array $blocks = array())
    {
        $__internal_db682abe75f6bda1f4b58d6811c1560422145f526a7206d6e94dc7b76aad09b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_db682abe75f6bda1f4b58d6811c1560422145f526a7206d6e94dc7b76aad09b6->enter($__internal_db682abe75f6bda1f4b58d6811c1560422145f526a7206d6e94dc7b76aad09b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "connection"));

        // line 87
        echo "        ";
        
        $__internal_db682abe75f6bda1f4b58d6811c1560422145f526a7206d6e94dc7b76aad09b6->leave($__internal_db682abe75f6bda1f4b58d6811c1560422145f526a7206d6e94dc7b76aad09b6_prof);

    }

    public function getTemplateName()
    {
        return "layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  253 => 87,  247 => 86,  240 => 67,  234 => 66,  227 => 62,  221 => 61,  212 => 45,  206 => 44,  195 => 6,  180 => 90,  176 => 88,  174 => 86,  165 => 80,  161 => 78,  149 => 68,  147 => 66,  142 => 63,  140 => 61,  125 => 48,  123 => 44,  111 => 36,  105 => 34,  103 => 33,  97 => 32,  92 => 30,  87 => 27,  85 => 26,  81 => 24,  68 => 20,  63 => 19,  58 => 18,  54 => 17,  45 => 12,  41 => 10,  36 => 7,  34 => 6,  27 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"fr\">
<head>
    <meta charset=\"UTF-8\">
    <title>
        Bump{% block title %}{% endblock %}
    </title>
    <link href=\"https://fonts.googleapis.com/css?family=News+Cycle\" rel=\"stylesheet\">
    <link href=\"https://fonts.googleapis.com/css?family=Gloria+Hallelujah|Yanone+Kaffeesatz:200\" rel=\"stylesheet\">
    <link rel=\"stylesheet\" href=\"{{ asset('bundles/appli/css/main.css') }}\" type=\"text/css\" media=\"all\" />
    {#<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\" crossorigin=\"anonymous\">#}
    <link rel=\"icon\" type=\"image/png\" href=\"{{ asset('images/favicon.png')}}\">
</head>
<body>


{% for type, messages in app.session.flashBag.all %}
    {% for message in messages %}
        <div class=\"{{ type }}\">
            {{ message|trans({}, 'FOSUserBundle') }}
        </div>
    {% endfor %}
{% endfor %}


{% if is_granted(\"ROLE_USER\") %}
    <header class=\"log\">
            <div class=\"menuleft\">
                <div class=\"headerlogo\">
                   <img src=\"{{ asset('images/bumplogo-white.png')}}\" alt=\"Logo Bump\"></a>
                </div>
                <div class=\"ib sub-txt-small fine grey\">Bonjour</div><div class=\"ib fine lightgrey bord-droit\"> <a href=\"{{ path('fos_user_profile_show') }}\">{{ app.user.prenom }}</a> ! </div>
                {% if is_granted(\"ROLE_ADMIN\") %}
                    <div class=\"ib fine bord-droit\"><a href=\"{{ path('admin_index') }}\">Administration</a></div>
                {% endif %}
                <div class=\" ib fine petite\"><a class=\"deconnexion\" href=\"{{ path('fos_user_security_logout') }}\">Déconnexion</a></div>



            </div>



            {% block ariane %}


            {% endblock %}








    </header>

<main>


        {% block left %}
        {% endblock %}



        {% block right %}
        {% endblock %}





</main>



{% else %}
    <header>
        <div class=\"headerlogo-nolog\">
            <img src=\"{{ asset('images/bumplogo-rouge.png')}}\" alt=\"Logo Bump\">
        </div>
    </header>


    <main class=\"nolog\">
        {% block connection %}
        {% endblock %}
    </main>
{% endif %}
<footer>Copyright © 2017 Diaphonics <span>●</span> Studio Bump <span>●</span> Contact <span>●</span> Mentions Légales
</footer>

</body>



</html>
", "layout.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/layout.html.twig");
    }
}
