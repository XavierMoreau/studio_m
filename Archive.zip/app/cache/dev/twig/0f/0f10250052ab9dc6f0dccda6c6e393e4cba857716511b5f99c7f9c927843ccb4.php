<?php

/* layout.html.twig */
class __TwigTemplate_d5979f33548afa47ea10743902cf50c9f624f7c6bdb9498168eb01b9caf82b0f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
            'right' => array($this, 'block_right'),
            'connection' => array($this, 'block_connection'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6522b89bbaf160bb5d1a0696eb384175f595db7d906de249dfd430b1c36b1f0c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6522b89bbaf160bb5d1a0696eb384175f595db7d906de249dfd430b1c36b1f0c->enter($__internal_6522b89bbaf160bb5d1a0696eb384175f595db7d906de249dfd430b1c36b1f0c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"fr\">
<head>
    <meta charset=\"UTF-8\">
    <title>
        Bump";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        // line 7
        echo "    </title>
    <link href=\"https://fonts.googleapis.com/css?family=News+Cycle\" rel=\"stylesheet\">
    <link href=\"https://fonts.googleapis.com/css?family=Gloria+Hallelujah|Yanone+Kaffeesatz:200\" rel=\"stylesheet\">
    <link rel=\"stylesheet\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/appli/css/main.css"), "html", null, true);
        echo "\" type=\"text/css\" media=\"all\" />
    ";
        // line 12
        echo "    <link rel=\"icon\" type=\"image/png\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/favicon.png"), "html", null, true);
        echo "\">
</head>
<body>


";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "all", array()));
        foreach ($context['_seq'] as $context["type"] => $context["messages"]) {
            // line 18
            echo "    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["messages"]);
            foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                // line 19
                echo "        <div class=\"";
                echo twig_escape_filter($this->env, $context["type"], "html", null, true);
                echo "\">
            ";
                // line 20
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($context["message"], array(), "FOSUserBundle"), "html", null, true);
                echo "
        </div>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['type'], $context['messages'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "

";
        // line 26
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_USER")) {
            // line 27
            echo "    <header class=\"log\">


            <div class=\"menuleft\">
                <div class=\"headerlogo\">
                   <img src=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/bumplogo-white.png"), "html", null, true);
            echo "\" alt=\"Logo Bump\"></a>
                </div>
                <div class=\"ib sub-txt-small fine grey\">Bonjour</div><div class=\"ib fine lightgrey bord-droit\"> <a href=\"";
            // line 34
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_profile_show");
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "prenom", array()), "html", null, true);
            echo "</a> ! </div>
                ";
            // line 35
            if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_ADMIN")) {
                // line 36
                echo "                    <div class=\"ib fine bord-droit\"><a href=\"";
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_index");
                echo "\">Administration</a></div>
                ";
            }
            // line 38
            echo "                <div class=\" ib fine petite\"><a class=\"deconnexion\" href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_logout");
            echo "\">Déconnexion</a></div>



            </div>



            ";
            // line 46
            $this->displayBlock('ariane', $context, $blocks);
            // line 50
            echo "







    </header>

<main>


        ";
            // line 63
            $this->displayBlock('left', $context, $blocks);
            // line 65
            echo "


        ";
            // line 68
            $this->displayBlock('right', $context, $blocks);
            // line 70
            echo "




</main>



";
        } else {
            // line 80
            echo "    <header>
        <div class=\"headerlogo\">
            <img src=\"";
            // line 82
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/bumplogo.png"), "html", null, true);
            echo "\" alt=\"Logo Bump\">
        </div>
    </header>


    <main class=\"nolog\">
        ";
            // line 88
            $this->displayBlock('connection', $context, $blocks);
            // line 90
            echo "    </main>
";
        }
        // line 92
        echo "<footer>Copyright © 2017 Diaphonics <span>●</span> Studio Bump <span>●</span> Contact <span>●</span> Mentions Légales
</footer>

</body>



</html>
";
        
        $__internal_6522b89bbaf160bb5d1a0696eb384175f595db7d906de249dfd430b1c36b1f0c->leave($__internal_6522b89bbaf160bb5d1a0696eb384175f595db7d906de249dfd430b1c36b1f0c_prof);

    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        $__internal_59d2da4e08c602d15a455101a5b44237d07d216d65eb792215d03cd150e270b7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_59d2da4e08c602d15a455101a5b44237d07d216d65eb792215d03cd150e270b7->enter($__internal_59d2da4e08c602d15a455101a5b44237d07d216d65eb792215d03cd150e270b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_59d2da4e08c602d15a455101a5b44237d07d216d65eb792215d03cd150e270b7->leave($__internal_59d2da4e08c602d15a455101a5b44237d07d216d65eb792215d03cd150e270b7_prof);

    }

    // line 46
    public function block_ariane($context, array $blocks = array())
    {
        $__internal_008bbaf990c8f0679e0d49fa7d7af7c8ece2878c102017433f56ebdb4bbaf5ed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_008bbaf990c8f0679e0d49fa7d7af7c8ece2878c102017433f56ebdb4bbaf5ed->enter($__internal_008bbaf990c8f0679e0d49fa7d7af7c8ece2878c102017433f56ebdb4bbaf5ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ariane"));

        // line 47
        echo "

            ";
        
        $__internal_008bbaf990c8f0679e0d49fa7d7af7c8ece2878c102017433f56ebdb4bbaf5ed->leave($__internal_008bbaf990c8f0679e0d49fa7d7af7c8ece2878c102017433f56ebdb4bbaf5ed_prof);

    }

    // line 63
    public function block_left($context, array $blocks = array())
    {
        $__internal_d45dcc3046fd9a099b3f62adda4d05c3a8276a255187fe982c87a5ba5d945a0b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d45dcc3046fd9a099b3f62adda4d05c3a8276a255187fe982c87a5ba5d945a0b->enter($__internal_d45dcc3046fd9a099b3f62adda4d05c3a8276a255187fe982c87a5ba5d945a0b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "left"));

        // line 64
        echo "        ";
        
        $__internal_d45dcc3046fd9a099b3f62adda4d05c3a8276a255187fe982c87a5ba5d945a0b->leave($__internal_d45dcc3046fd9a099b3f62adda4d05c3a8276a255187fe982c87a5ba5d945a0b_prof);

    }

    // line 68
    public function block_right($context, array $blocks = array())
    {
        $__internal_acded191d1348e5439d5901610e9205565f83075b75f02961f93524bb169fef7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_acded191d1348e5439d5901610e9205565f83075b75f02961f93524bb169fef7->enter($__internal_acded191d1348e5439d5901610e9205565f83075b75f02961f93524bb169fef7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "right"));

        // line 69
        echo "        ";
        
        $__internal_acded191d1348e5439d5901610e9205565f83075b75f02961f93524bb169fef7->leave($__internal_acded191d1348e5439d5901610e9205565f83075b75f02961f93524bb169fef7_prof);

    }

    // line 88
    public function block_connection($context, array $blocks = array())
    {
        $__internal_6d081638f18bbfedd65081d6ac0b90acedca9746f05f5db6df3746b6092fc24c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6d081638f18bbfedd65081d6ac0b90acedca9746f05f5db6df3746b6092fc24c->enter($__internal_6d081638f18bbfedd65081d6ac0b90acedca9746f05f5db6df3746b6092fc24c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "connection"));

        // line 89
        echo "        ";
        
        $__internal_6d081638f18bbfedd65081d6ac0b90acedca9746f05f5db6df3746b6092fc24c->leave($__internal_6d081638f18bbfedd65081d6ac0b90acedca9746f05f5db6df3746b6092fc24c_prof);

    }

    public function getTemplateName()
    {
        return "layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  255 => 89,  249 => 88,  242 => 69,  236 => 68,  229 => 64,  223 => 63,  214 => 47,  208 => 46,  197 => 6,  182 => 92,  178 => 90,  176 => 88,  167 => 82,  163 => 80,  151 => 70,  149 => 68,  144 => 65,  142 => 63,  127 => 50,  125 => 46,  113 => 38,  107 => 36,  105 => 35,  99 => 34,  94 => 32,  87 => 27,  85 => 26,  81 => 24,  68 => 20,  63 => 19,  58 => 18,  54 => 17,  45 => 12,  41 => 10,  36 => 7,  34 => 6,  27 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"fr\">
<head>
    <meta charset=\"UTF-8\">
    <title>
        Bump{% block title %}{% endblock %}
    </title>
    <link href=\"https://fonts.googleapis.com/css?family=News+Cycle\" rel=\"stylesheet\">
    <link href=\"https://fonts.googleapis.com/css?family=Gloria+Hallelujah|Yanone+Kaffeesatz:200\" rel=\"stylesheet\">
    <link rel=\"stylesheet\" href=\"{{ asset('bundles/appli/css/main.css') }}\" type=\"text/css\" media=\"all\" />
    {#<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\" crossorigin=\"anonymous\">#}
    <link rel=\"icon\" type=\"image/png\" href=\"{{ asset('images/favicon.png')}}\">
</head>
<body>


{% for type, messages in app.session.flashBag.all %}
    {% for message in messages %}
        <div class=\"{{ type }}\">
            {{ message|trans({}, 'FOSUserBundle') }}
        </div>
    {% endfor %}
{% endfor %}


{% if is_granted(\"ROLE_USER\") %}
    <header class=\"log\">


            <div class=\"menuleft\">
                <div class=\"headerlogo\">
                   <img src=\"{{ asset('images/bumplogo-white.png')}}\" alt=\"Logo Bump\"></a>
                </div>
                <div class=\"ib sub-txt-small fine grey\">Bonjour</div><div class=\"ib fine lightgrey bord-droit\"> <a href=\"{{ path('fos_user_profile_show') }}\">{{ app.user.prenom }}</a> ! </div>
                {% if is_granted(\"ROLE_ADMIN\") %}
                    <div class=\"ib fine bord-droit\"><a href=\"{{ path('admin_index') }}\">Administration</a></div>
                {% endif %}
                <div class=\" ib fine petite\"><a class=\"deconnexion\" href=\"{{ path('fos_user_security_logout') }}\">Déconnexion</a></div>



            </div>



            {% block ariane %}


            {% endblock %}








    </header>

<main>


        {% block left %}
        {% endblock %}



        {% block right %}
        {% endblock %}





</main>



{% else %}
    <header>
        <div class=\"headerlogo\">
            <img src=\"{{ asset('images/bumplogo.png')}}\" alt=\"Logo Bump\">
        </div>
    </header>


    <main class=\"nolog\">
        {% block connection %}
        {% endblock %}
    </main>
{% endif %}
<footer>Copyright © 2017 Diaphonics <span>●</span> Studio Bump <span>●</span> Contact <span>●</span> Mentions Légales
</footer>

</body>



</html>
", "layout.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/layout.html.twig");
    }
}
