<?php

/* FOSUserBundle:Registration:email.txt.twig */
class __TwigTemplate_e7c3cc9e69f7ae50d87186a19627101f3696d80fa93cbb8f58c851e1d7b70f97 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_19a32f4641120749a1aa9c55663f5e3b95cadbb799737951c72d0675a4c5c49c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_19a32f4641120749a1aa9c55663f5e3b95cadbb799737951c72d0675a4c5c49c->enter($__internal_19a32f4641120749a1aa9c55663f5e3b95cadbb799737951c72d0675a4c5c49c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        echo "
";
        // line 8
        $this->displayBlock('body_text', $context, $blocks);
        // line 13
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_19a32f4641120749a1aa9c55663f5e3b95cadbb799737951c72d0675a4c5c49c->leave($__internal_19a32f4641120749a1aa9c55663f5e3b95cadbb799737951c72d0675a4c5c49c_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_cf88c614bf36bd28e336b5f801ddbc087642f655fb36ea811c122a93e299274f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cf88c614bf36bd28e336b5f801ddbc087642f655fb36ea811c122a93e299274f->enter($__internal_cf88c614bf36bd28e336b5f801ddbc087642f655fb36ea811c122a93e299274f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.email.subject", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        
        $__internal_cf88c614bf36bd28e336b5f801ddbc087642f655fb36ea811c122a93e299274f->leave($__internal_cf88c614bf36bd28e336b5f801ddbc087642f655fb36ea811c122a93e299274f_prof);

    }

    // line 8
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_8fcb269216c4a99d577b5c99d819c44ea1aaa6b5259255f0dadf4f60ff12da0a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8fcb269216c4a99d577b5c99d819c44ea1aaa6b5259255f0dadf4f60ff12da0a->enter($__internal_8fcb269216c4a99d577b5c99d819c44ea1aaa6b5259255f0dadf4f60ff12da0a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.email.message", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_8fcb269216c4a99d577b5c99d819c44ea1aaa6b5259255f0dadf4f60ff12da0a->leave($__internal_8fcb269216c4a99d577b5c99d819c44ea1aaa6b5259255f0dadf4f60ff12da0a_prof);

    }

    // line 13
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_a99ab5c98f02830b094efa304d3b2a44ecf66ff95480971954cf25f9070777ce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a99ab5c98f02830b094efa304d3b2a44ecf66ff95480971954cf25f9070777ce->enter($__internal_a99ab5c98f02830b094efa304d3b2a44ecf66ff95480971954cf25f9070777ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_a99ab5c98f02830b094efa304d3b2a44ecf66ff95480971954cf25f9070777ce->leave($__internal_a99ab5c98f02830b094efa304d3b2a44ecf66ff95480971954cf25f9070777ce_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  67 => 13,  58 => 10,  52 => 8,  45 => 4,  39 => 2,  32 => 13,  30 => 8,  27 => 7,  25 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}
{% block subject %}
{%- autoescape false -%}
{{ 'registration.email.subject'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}
{%- endautoescape -%}
{% endblock %}

{% block body_text %}
{% autoescape false %}
{{ 'registration.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}
{% endautoescape %}
{% endblock %}
{% block body_html %}{% endblock %}
", "FOSUserBundle:Registration:email.txt.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/friendsofsymfony/user-bundle/Resources/views/Registration/email.txt.twig");
    }
}
