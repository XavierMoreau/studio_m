<?php

/* FOSUserBundle:Registration:email.txt.twig */
class __TwigTemplate_e7c3cc9e69f7ae50d87186a19627101f3696d80fa93cbb8f58c851e1d7b70f97 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7aaab3b4451037155e46e4bd290058fb1ab0a33be4b6fd5e1535bfff4d602b77 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7aaab3b4451037155e46e4bd290058fb1ab0a33be4b6fd5e1535bfff4d602b77->enter($__internal_7aaab3b4451037155e46e4bd290058fb1ab0a33be4b6fd5e1535bfff4d602b77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        echo "
";
        // line 8
        $this->displayBlock('body_text', $context, $blocks);
        // line 13
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_7aaab3b4451037155e46e4bd290058fb1ab0a33be4b6fd5e1535bfff4d602b77->leave($__internal_7aaab3b4451037155e46e4bd290058fb1ab0a33be4b6fd5e1535bfff4d602b77_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_61a362a60c59297992535d914cb044ee1fe552ae095fabc59f7b9a1a04eb084c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_61a362a60c59297992535d914cb044ee1fe552ae095fabc59f7b9a1a04eb084c->enter($__internal_61a362a60c59297992535d914cb044ee1fe552ae095fabc59f7b9a1a04eb084c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.email.subject", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        
        $__internal_61a362a60c59297992535d914cb044ee1fe552ae095fabc59f7b9a1a04eb084c->leave($__internal_61a362a60c59297992535d914cb044ee1fe552ae095fabc59f7b9a1a04eb084c_prof);

    }

    // line 8
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_ea74472e30fc84e8d193387f8813b3b5512ac3de789506220c367227d52d257a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ea74472e30fc84e8d193387f8813b3b5512ac3de789506220c367227d52d257a->enter($__internal_ea74472e30fc84e8d193387f8813b3b5512ac3de789506220c367227d52d257a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.email.message", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_ea74472e30fc84e8d193387f8813b3b5512ac3de789506220c367227d52d257a->leave($__internal_ea74472e30fc84e8d193387f8813b3b5512ac3de789506220c367227d52d257a_prof);

    }

    // line 13
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_20309681b12b81fae3e6811936fc89e0d2dc86395c1d0bb5e6518853de605798 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_20309681b12b81fae3e6811936fc89e0d2dc86395c1d0bb5e6518853de605798->enter($__internal_20309681b12b81fae3e6811936fc89e0d2dc86395c1d0bb5e6518853de605798_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_20309681b12b81fae3e6811936fc89e0d2dc86395c1d0bb5e6518853de605798->leave($__internal_20309681b12b81fae3e6811936fc89e0d2dc86395c1d0bb5e6518853de605798_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  67 => 13,  58 => 10,  52 => 8,  45 => 4,  39 => 2,  32 => 13,  30 => 8,  27 => 7,  25 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}
{% block subject %}
{%- autoescape false -%}
{{ 'registration.email.subject'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}
{%- endautoescape -%}
{% endblock %}

{% block body_text %}
{% autoescape false %}
{{ 'registration.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}
{% endautoescape %}
{% endblock %}
{% block body_html %}{% endblock %}
", "FOSUserBundle:Registration:email.txt.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/friendsofsymfony/user-bundle/Resources/views/Registration/email.txt.twig");
    }
}
