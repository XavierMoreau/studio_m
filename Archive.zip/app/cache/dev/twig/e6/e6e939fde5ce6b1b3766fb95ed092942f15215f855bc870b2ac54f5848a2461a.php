<?php

/* FOSUserBundle::layout.html.twig */
class __TwigTemplate_09f3a5182215c5c64c16579ef33423cfe3298fdb4d9073b4ce6d790bfc820921 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "FOSUserBundle::layout.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'connection' => array($this, 'block_connection'),
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fde3a47b18a05a8d2f592fb77948bf2d7d6bdedd452303ec29695a10fa272da3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fde3a47b18a05a8d2f592fb77948bf2d7d6bdedd452303ec29695a10fa272da3->enter($__internal_fde3a47b18a05a8d2f592fb77948bf2d7d6bdedd452303ec29695a10fa272da3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle::layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fde3a47b18a05a8d2f592fb77948bf2d7d6bdedd452303ec29695a10fa272da3->leave($__internal_fde3a47b18a05a8d2f592fb77948bf2d7d6bdedd452303ec29695a10fa272da3_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_b24d396b24f8d85a69119fa4047114eaff25fc939c7a3c119a89289f6591c68c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b24d396b24f8d85a69119fa4047114eaff25fc939c7a3c119a89289f6591c68c->enter($__internal_b24d396b24f8d85a69119fa4047114eaff25fc939c7a3c119a89289f6591c68c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo " - Connexion";
        
        $__internal_b24d396b24f8d85a69119fa4047114eaff25fc939c7a3c119a89289f6591c68c->leave($__internal_b24d396b24f8d85a69119fa4047114eaff25fc939c7a3c119a89289f6591c68c_prof);

    }

    // line 5
    public function block_connection($context, array $blocks = array())
    {
        $__internal_5740797f957a2d28d27702a9106889f2c59102292d74d25b1e09bcd577ac25cb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5740797f957a2d28d27702a9106889f2c59102292d74d25b1e09bcd577ac25cb->enter($__internal_5740797f957a2d28d27702a9106889f2c59102292d74d25b1e09bcd577ac25cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "connection"));

        // line 6
        echo "    <div class=\"connection\">

        <div class=\"conn-middle\">

            ";
        // line 10
        $this->displayBlock('fos_user_content', $context, $blocks);
        // line 11
        echo "
        </div>



    </div>

";
        
        $__internal_5740797f957a2d28d27702a9106889f2c59102292d74d25b1e09bcd577ac25cb->leave($__internal_5740797f957a2d28d27702a9106889f2c59102292d74d25b1e09bcd577ac25cb_prof);

    }

    // line 10
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_9f69df67c14c198939391404545f3b884460b690e9dae32629d9766d93c8713d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9f69df67c14c198939391404545f3b884460b690e9dae32629d9766d93c8713d->enter($__internal_9f69df67c14c198939391404545f3b884460b690e9dae32629d9766d93c8713d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        
        $__internal_9f69df67c14c198939391404545f3b884460b690e9dae32629d9766d93c8713d->leave($__internal_9f69df67c14c198939391404545f3b884460b690e9dae32629d9766d93c8713d_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 10,  62 => 11,  60 => 10,  54 => 6,  48 => 5,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layout.html.twig\" %}

{% block title %} - Connexion{% endblock %}

{% block connection %}
    <div class=\"connection\">

        <div class=\"conn-middle\">

            {% block fos_user_content %}{% endblock %}

        </div>



    </div>

{% endblock %}", "FOSUserBundle::layout.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/src/UserBundle/Resources/views/layout.html.twig");
    }
}
