<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_004dcd2b89f46a85a683d2b2fc22150672337aa59e80d19af3c80b1847caa70e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_237db945a62a19cc74f924af3b5e702828e400268103ff53bc7baf3f6ba9e706 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_237db945a62a19cc74f924af3b5e702828e400268103ff53bc7baf3f6ba9e706->enter($__internal_237db945a62a19cc74f924af3b5e702828e400268103ff53bc7baf3f6ba9e706_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_237db945a62a19cc74f924af3b5e702828e400268103ff53bc7baf3f6ba9e706->leave($__internal_237db945a62a19cc74f924af3b5e702828e400268103ff53bc7baf3f6ba9e706_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "TwigBundle:Exception:error.atom.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.atom.twig");
    }
}
