<?php

/* :scriptquestion:edit.html.twig */
class __TwigTemplate_d8c2cde519a67221b38ee68edea27a8fe3a74d9ff22b46f3e5c0512442374162 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":scriptquestion:edit.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a8a85666785a06437e3f8db693ccdb70e81ae124020f241722f08732640e0d00 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a8a85666785a06437e3f8db693ccdb70e81ae124020f241722f08732640e0d00->enter($__internal_a8a85666785a06437e3f8db693ccdb70e81ae124020f241722f08732640e0d00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":scriptquestion:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a8a85666785a06437e3f8db693ccdb70e81ae124020f241722f08732640e0d00->leave($__internal_a8a85666785a06437e3f8db693ccdb70e81ae124020f241722f08732640e0d00_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_ec1fdce56e8a1a225f35115801ff852e97a6e023caeced98f6380819b788b71c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ec1fdce56e8a1a225f35115801ff852e97a6e023caeced98f6380819b788b71c->enter($__internal_ec1fdce56e8a1a225f35115801ff852e97a6e023caeced98f6380819b788b71c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <h3>Modification de question</h3>

    ";
        // line 6
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "
        <input class=\"btn btn-primary\" type=\"submit\" value=\"Modifier\" />
    <a class=\"btn btn-default\" href=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptquestion_index");
        echo "\">Retour</a>
    ";
        // line 10
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "


";
        
        $__internal_ec1fdce56e8a1a225f35115801ff852e97a6e023caeced98f6380819b788b71c->leave($__internal_ec1fdce56e8a1a225f35115801ff852e97a6e023caeced98f6380819b788b71c_prof);

    }

    public function getTemplateName()
    {
        return ":scriptquestion:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 10,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block content %}
    <h3>Modification de question</h3>

    {{ form_start(edit_form) }}
        {{ form_widget(edit_form) }}
        <input class=\"btn btn-primary\" type=\"submit\" value=\"Modifier\" />
    <a class=\"btn btn-default\" href=\"{{ path('scriptquestion_index') }}\">Retour</a>
    {{ form_end(edit_form) }}


{% endblock %}
", ":scriptquestion:edit.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/scriptquestion/edit.html.twig");
    }
}
