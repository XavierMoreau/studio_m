<?php

/* FOSUserBundle:Registration:check_email.html.twig */
class __TwigTemplate_4bb2e265d31d3753790cdeb1632d1291bfbb5101da0984f246bcd79eec94793e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Registration:check_email.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e04416c62a5efe7cd7352d129495e301d8519d147eff3d16bdaf1467cf7e5e4f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e04416c62a5efe7cd7352d129495e301d8519d147eff3d16bdaf1467cf7e5e4f->enter($__internal_e04416c62a5efe7cd7352d129495e301d8519d147eff3d16bdaf1467cf7e5e4f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:check_email.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e04416c62a5efe7cd7352d129495e301d8519d147eff3d16bdaf1467cf7e5e4f->leave($__internal_e04416c62a5efe7cd7352d129495e301d8519d147eff3d16bdaf1467cf7e5e4f_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_d25df8f62712b16d4173c7782ba3635ac157eb02053b0e019b17517a6dfd4382 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d25df8f62712b16d4173c7782ba3635ac157eb02053b0e019b17517a6dfd4382->enter($__internal_d25df8f62712b16d4173c7782ba3635ac157eb02053b0e019b17517a6dfd4382_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "    <p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.check_email", array("%email%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array())), "FOSUserBundle"), "html", null, true);
        echo "</p>
";
        
        $__internal_d25df8f62712b16d4173c7782ba3635ac157eb02053b0e019b17517a6dfd4382->leave($__internal_d25df8f62712b16d4173c7782ba3635ac157eb02053b0e019b17517a6dfd4382_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:check_email.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 6,  34 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% trans_default_domain 'FOSUserBundle' %}

{% block fos_user_content %}
    <p>{{ 'registration.check_email'|trans({'%email%': user.email}) }}</p>
{% endblock fos_user_content %}
", "FOSUserBundle:Registration:check_email.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/friendsofsymfony/user-bundle/Resources/views/Registration/check_email.html.twig");
    }
}
