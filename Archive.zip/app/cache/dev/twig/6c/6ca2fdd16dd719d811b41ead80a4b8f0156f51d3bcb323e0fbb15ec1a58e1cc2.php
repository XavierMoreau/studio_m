<?php

/* FOSUserBundle:Resetting:request.html.twig */
class __TwigTemplate_86bab76fcbfd3e055d862b90a04c7ad5706efb08f3e9eda9c744768b86efb44a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Resetting:request.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_27242a93ea9b5bac55d667b1c52dbdb7f58601315dc260f86535884170f02c98 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_27242a93ea9b5bac55d667b1c52dbdb7f58601315dc260f86535884170f02c98->enter($__internal_27242a93ea9b5bac55d667b1c52dbdb7f58601315dc260f86535884170f02c98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:request.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_27242a93ea9b5bac55d667b1c52dbdb7f58601315dc260f86535884170f02c98->leave($__internal_27242a93ea9b5bac55d667b1c52dbdb7f58601315dc260f86535884170f02c98_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_7605a62b6f60d7ef9cb25cc8d35ed2ebef893d4d9570da07ea36c5df9b92bdb0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7605a62b6f60d7ef9cb25cc8d35ed2ebef893d4d9570da07ea36c5df9b92bdb0->enter($__internal_7605a62b6f60d7ef9cb25cc8d35ed2ebef893d4d9570da07ea36c5df9b92bdb0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Resetting/request_content.html.twig", "FOSUserBundle:Resetting:request.html.twig", 4)->display($context);
        
        $__internal_7605a62b6f60d7ef9cb25cc8d35ed2ebef893d4d9570da07ea36c5df9b92bdb0->leave($__internal_7605a62b6f60d7ef9cb25cc8d35ed2ebef893d4d9570da07ea36c5df9b92bdb0_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:request.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Resetting/request_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Resetting:request.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/friendsofsymfony/user-bundle/Resources/views/Resetting/request.html.twig");
    }
}
