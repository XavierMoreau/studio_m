<?php

/* :projet:new.html.twig */
class __TwigTemplate_4d956c4ab338a7081c5575aff67035b2bf0faf691cd200b45392af6e750883b7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":projet:new.html.twig", 1);
        $this->blocks = array(
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
            'right' => array($this, 'block_right'),
            'aside' => array($this, 'block_aside'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_885bd9cb02b89813a7ddd83a84ca62319a02d15e354e00c9abe833a55010f92f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_885bd9cb02b89813a7ddd83a84ca62319a02d15e354e00c9abe833a55010f92f->enter($__internal_885bd9cb02b89813a7ddd83a84ca62319a02d15e354e00c9abe833a55010f92f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":projet:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_885bd9cb02b89813a7ddd83a84ca62319a02d15e354e00c9abe833a55010f92f->leave($__internal_885bd9cb02b89813a7ddd83a84ca62319a02d15e354e00c9abe833a55010f92f_prof);

    }

    // line 3
    public function block_ariane($context, array $blocks = array())
    {
        $__internal_7517cb60fed4448ca4f0b4bbf74b1180c1c9974b9137bca636f6590e245dfe3a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7517cb60fed4448ca4f0b4bbf74b1180c1c9974b9137bca636f6590e245dfe3a->enter($__internal_7517cb60fed4448ca4f0b4bbf74b1180c1c9974b9137bca636f6590e245dfe3a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ariane"));

        // line 4
        echo "
    <div class=\"ariane grey\">
        <div class=\"ib fine\">PROJETS</div>
        <div class=\"ib fine petite\">Paramètres</div>
        <div class=\"ib padding-ten fine\">></div>
        <div class=\"ib fine\">SCRIPT</div>
        <div class=\"ib fine petite\">Guide</div>
        <div class=\"ib fine petite\">Voix-Off</div>
        <div class=\"ib fine petite\">Ecriture</div>
        <div class=\"ib padding-ten fine\">></div>
        <div class=\"ib fine\">STORYBOARD</div>
        <div class=\"ib fine petite\">Ecriture</div>

    </div>

";
        
        $__internal_7517cb60fed4448ca4f0b4bbf74b1180c1c9974b9137bca636f6590e245dfe3a->leave($__internal_7517cb60fed4448ca4f0b4bbf74b1180c1c9974b9137bca636f6590e245dfe3a_prof);

    }

    // line 21
    public function block_left($context, array $blocks = array())
    {
        $__internal_691bb055752fa1d8b72bc95fe2d12447a65c6d8ba7d2ee6885261b2915b171dc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_691bb055752fa1d8b72bc95fe2d12447a65c6d8ba7d2ee6885261b2915b171dc->enter($__internal_691bb055752fa1d8b72bc95fe2d12447a65c6d8ba7d2ee6885261b2915b171dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "left"));

        // line 22
        echo "
    <div class=\"ib largeur-un-quart  leftprojet-new-edit\">



            <div class=\"txt-center\">
                <div class=\"ib imground\">
                    <img src=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/light-bulb.png"), "html", null, true);
        echo "\" alt=\"Nouveau Projet\">
                </div>


            </div>





    </div>

";
        
        $__internal_691bb055752fa1d8b72bc95fe2d12447a65c6d8ba7d2ee6885261b2915b171dc->leave($__internal_691bb055752fa1d8b72bc95fe2d12447a65c6d8ba7d2ee6885261b2915b171dc_prof);

    }

    // line 43
    public function block_right($context, array $blocks = array())
    {
        $__internal_590bceb83b3a773a61db21f86ad1649c3115493c12785647fd037dabcc8b03ee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_590bceb83b3a773a61db21f86ad1649c3115493c12785647fd037dabcc8b03ee->enter($__internal_590bceb83b3a773a61db21f86ad1649c3115493c12785647fd037dabcc8b03ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "right"));

        // line 44
        echo "<div class=\"ib largeur-trois-quarts rightprojet-new-edit\">

    <table class=\"title-tab\">
        <td class=\"padding-ten projet hand\"><h3>Nouveau projet</h3></td>
    </table>



    ";
        // line 52
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 53
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "

    <button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\">
        <table class=\"tab-buttons shadow back-projet\">
            <td>
                <div class=\"lightgrey\">Enregistrer</div>
            </td>
            <td>
                <img src=\"";
        // line 61
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/save-file-option.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"19\">
            </td>
        </table>
    </button>



    ";
        // line 68
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "



";
        
        $__internal_590bceb83b3a773a61db21f86ad1649c3115493c12785647fd037dabcc8b03ee->leave($__internal_590bceb83b3a773a61db21f86ad1649c3115493c12785647fd037dabcc8b03ee_prof);

    }

    // line 77
    public function block_aside($context, array $blocks = array())
    {
        $__internal_bce3b609ef9e08d9e6c6cfb1bc639f7955f712edea1cda6d1eea63597ffaea1c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bce3b609ef9e08d9e6c6cfb1bc639f7955f712edea1cda6d1eea63597ffaea1c->enter($__internal_bce3b609ef9e08d9e6c6cfb1bc639f7955f712edea1cda6d1eea63597ffaea1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "aside"));

        // line 78
        echo "
    <div class=\"largeur-totale txt-center\">
        <img class=\"imgflat\" src=\"";
        // line 80
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/file.png"), "html", null, true);
        echo "\" alt=\"Script\" height=\"50\"><h4 style=\"color: #ff5419\">Projet</h4>
    </div>




    <div class=\"largeur-totale left-menu actuel\">

            <img class=\"imgflat\" src=\"";
        // line 88
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/parameters.png"), "html", null, true);
        echo "\" alt=\"Voix-off\" height=\"30\">
            <div class=\"ib title-txt-petit projet\">Paramètres</div>
        </a>
    </div>

    <div class=\"largeur-totale txt-center padding-ten\">

        <div class=\"title-tab\">
        </div>
    </div>




<div>
";
        
        $__internal_bce3b609ef9e08d9e6c6cfb1bc639f7955f712edea1cda6d1eea63597ffaea1c->leave($__internal_bce3b609ef9e08d9e6c6cfb1bc639f7955f712edea1cda6d1eea63597ffaea1c_prof);

    }

    public function getTemplateName()
    {
        return ":projet:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  174 => 88,  163 => 80,  159 => 78,  153 => 77,  141 => 68,  131 => 61,  120 => 53,  116 => 52,  106 => 44,  100 => 43,  80 => 29,  71 => 22,  65 => 21,  43 => 4,  37 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block ariane %}

    <div class=\"ariane grey\">
        <div class=\"ib fine\">PROJETS</div>
        <div class=\"ib fine petite\">Paramètres</div>
        <div class=\"ib padding-ten fine\">></div>
        <div class=\"ib fine\">SCRIPT</div>
        <div class=\"ib fine petite\">Guide</div>
        <div class=\"ib fine petite\">Voix-Off</div>
        <div class=\"ib fine petite\">Ecriture</div>
        <div class=\"ib padding-ten fine\">></div>
        <div class=\"ib fine\">STORYBOARD</div>
        <div class=\"ib fine petite\">Ecriture</div>

    </div>

{% endblock %}

{% block left %}

    <div class=\"ib largeur-un-quart  leftprojet-new-edit\">



            <div class=\"txt-center\">
                <div class=\"ib imground\">
                    <img src=\"{{ asset('images/light-bulb.png')}}\" alt=\"Nouveau Projet\">
                </div>


            </div>





    </div>

{% endblock %}

{% block right %}
<div class=\"ib largeur-trois-quarts rightprojet-new-edit\">

    <table class=\"title-tab\">
        <td class=\"padding-ten projet hand\"><h3>Nouveau projet</h3></td>
    </table>



    {{ form_start(form) }}
        {{ form_widget(form) }}

    <button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\">
        <table class=\"tab-buttons shadow back-projet\">
            <td>
                <div class=\"lightgrey\">Enregistrer</div>
            </td>
            <td>
                <img src=\"{{ asset('images/save-file-option.png')}}\" alt=\"Enregistrer\" height=\"19\">
            </td>
        </table>
    </button>



    {{ form_end(form) }}



{% endblock %}




{% block aside %}

    <div class=\"largeur-totale txt-center\">
        <img class=\"imgflat\" src=\"{{ asset('images/file.png')}}\" alt=\"Script\" height=\"50\"><h4 style=\"color: #ff5419\">Projet</h4>
    </div>




    <div class=\"largeur-totale left-menu actuel\">

            <img class=\"imgflat\" src=\"{{ asset('images/parameters.png')}}\" alt=\"Voix-off\" height=\"30\">
            <div class=\"ib title-txt-petit projet\">Paramètres</div>
        </a>
    </div>

    <div class=\"largeur-totale txt-center padding-ten\">

        <div class=\"title-tab\">
        </div>
    </div>




<div>
{% endblock %}", ":projet:new.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/projet/new.html.twig");
    }
}
