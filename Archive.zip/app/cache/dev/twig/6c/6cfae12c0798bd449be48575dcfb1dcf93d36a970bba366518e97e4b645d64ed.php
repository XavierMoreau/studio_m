<?php

/* :utilisation:new.html.twig */
class __TwigTemplate_af59c5308bff525aa5dfce7cd89492ebb6126d5ec779dd26c28a96cee1d59bd4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":utilisation:new.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2f1bb34d5a6c2ef8dc4765c4206b81afcaaaf8ab4d7eb1d59ce8eab79c6db8fa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2f1bb34d5a6c2ef8dc4765c4206b81afcaaaf8ab4d7eb1d59ce8eab79c6db8fa->enter($__internal_2f1bb34d5a6c2ef8dc4765c4206b81afcaaaf8ab4d7eb1d59ce8eab79c6db8fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":utilisation:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2f1bb34d5a6c2ef8dc4765c4206b81afcaaaf8ab4d7eb1d59ce8eab79c6db8fa->leave($__internal_2f1bb34d5a6c2ef8dc4765c4206b81afcaaaf8ab4d7eb1d59ce8eab79c6db8fa_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_fe52a47ab04386cc58b0d7383d1e16fc1556208690a90ecff3bd0b88ca90546d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fe52a47ab04386cc58b0d7383d1e16fc1556208690a90ecff3bd0b88ca90546d->enter($__internal_fe52a47ab04386cc58b0d7383d1e16fc1556208690a90ecff3bd0b88ca90546d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <h1>Nouveau type d'utilisation</h1>

    ";
        // line 6
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input class=\"btn btn-primary\" type=\"submit\" value=\"Créer\" />
    <a class=\"btn btn-default\" href=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("utilisation_index");
        echo "\">Retour</a>
    ";
        // line 10
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "


";
        
        $__internal_fe52a47ab04386cc58b0d7383d1e16fc1556208690a90ecff3bd0b88ca90546d->leave($__internal_fe52a47ab04386cc58b0d7383d1e16fc1556208690a90ecff3bd0b88ca90546d_prof);

    }

    public function getTemplateName()
    {
        return ":utilisation:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 10,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block content %}
    <h1>Nouveau type d'utilisation</h1>

    {{ form_start(form) }}
        {{ form_widget(form) }}
        <input class=\"btn btn-primary\" type=\"submit\" value=\"Créer\" />
    <a class=\"btn btn-default\" href=\"{{ path('utilisation_index') }}\">Retour</a>
    {{ form_end(form) }}


{% endblock %}
", ":utilisation:new.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/utilisation/new.html.twig");
    }
}
