<?php

/* :utilisation:new.html.twig */
class __TwigTemplate_af59c5308bff525aa5dfce7cd89492ebb6126d5ec779dd26c28a96cee1d59bd4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":utilisation:new.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_93e316538eb6304bded43efbed63f4cda68861bb052987a2e64e76ba6dca8969 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_93e316538eb6304bded43efbed63f4cda68861bb052987a2e64e76ba6dca8969->enter($__internal_93e316538eb6304bded43efbed63f4cda68861bb052987a2e64e76ba6dca8969_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":utilisation:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_93e316538eb6304bded43efbed63f4cda68861bb052987a2e64e76ba6dca8969->leave($__internal_93e316538eb6304bded43efbed63f4cda68861bb052987a2e64e76ba6dca8969_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_798ce4bf43e2de9e80a7b03379f45bf7abf6e39c14aa5b30138587bcab0d3c15 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_798ce4bf43e2de9e80a7b03379f45bf7abf6e39c14aa5b30138587bcab0d3c15->enter($__internal_798ce4bf43e2de9e80a7b03379f45bf7abf6e39c14aa5b30138587bcab0d3c15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <h1>Nouveau type d'utilisation</h1>

    ";
        // line 6
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input class=\"btn btn-primary\" type=\"submit\" value=\"Créer\" />
    <a class=\"btn btn-default\" href=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("utilisation_index");
        echo "\">Retour</a>
    ";
        // line 10
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "


";
        
        $__internal_798ce4bf43e2de9e80a7b03379f45bf7abf6e39c14aa5b30138587bcab0d3c15->leave($__internal_798ce4bf43e2de9e80a7b03379f45bf7abf6e39c14aa5b30138587bcab0d3c15_prof);

    }

    public function getTemplateName()
    {
        return ":utilisation:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 10,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block content %}
    <h1>Nouveau type d'utilisation</h1>

    {{ form_start(form) }}
        {{ form_widget(form) }}
        <input class=\"btn btn-primary\" type=\"submit\" value=\"Créer\" />
    <a class=\"btn btn-default\" href=\"{{ path('utilisation_index') }}\">Retour</a>
    {{ form_end(form) }}


{% endblock %}
", ":utilisation:new.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/utilisation/new.html.twig");
    }
}
