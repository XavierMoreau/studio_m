<?php

/* AppliBundle:Default:expert.html.twig */
class __TwigTemplate_cd9b17ab565158cfe3bbbbb81b96279e7a0102c6f6cafa06e7dbbe618ec212fc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "AppliBundle:Default:expert.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fdd93176cf0fa192a63f52f112269f270ee100eda78e8771c65e5a19b10e2848 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fdd93176cf0fa192a63f52f112269f270ee100eda78e8771c65e5a19b10e2848->enter($__internal_fdd93176cf0fa192a63f52f112269f270ee100eda78e8771c65e5a19b10e2848_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppliBundle:Default:expert.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fdd93176cf0fa192a63f52f112269f270ee100eda78e8771c65e5a19b10e2848->leave($__internal_fdd93176cf0fa192a63f52f112269f270ee100eda78e8771c65e5a19b10e2848_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_f0f50a5f73063c1e4659d603fd6375dc63b063a8f205d36bf522e58b8dbfd7fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f0f50a5f73063c1e4659d603fd6375dc63b063a8f205d36bf522e58b8dbfd7fe->enter($__internal_f0f50a5f73063c1e4659d603fd6375dc63b063a8f205d36bf522e58b8dbfd7fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_f0f50a5f73063c1e4659d603fd6375dc63b063a8f205d36bf522e58b8dbfd7fe->leave($__internal_f0f50a5f73063c1e4659d603fd6375dc63b063a8f205d36bf522e58b8dbfd7fe_prof);

    }

    // line 9
    public function block_content($context, array $blocks = array())
    {
        $__internal_0f26b5180264a208e3ff2599f0fdf8574350552ebfcf43f4c15fdb4b146ffda1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0f26b5180264a208e3ff2599f0fdf8574350552ebfcf43f4c15fdb4b146ffda1->enter($__internal_0f26b5180264a208e3ff2599f0fdf8574350552ebfcf43f4c15fdb4b146ffda1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 10
        echo "    ";
        // line 11
        echo "    Expert Page

";
        
        $__internal_0f26b5180264a208e3ff2599f0fdf8574350552ebfcf43f4c15fdb4b146ffda1->leave($__internal_0f26b5180264a208e3ff2599f0fdf8574350552ebfcf43f4c15fdb4b146ffda1_prof);

    }

    public function getTemplateName()
    {
        return "AppliBundle:Default:expert.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  54 => 11,  52 => 10,  46 => 9,  35 => 7,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layout.html.twig\" %}





{% block title %}{% endblock %}

{% block content %}
    {#{% block fos_user_content %}{% endblock %}#}
    Expert Page

{% endblock %}", "AppliBundle:Default:expert.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/src/AppliBundle/Resources/views/Default/expert.html.twig");
    }
}
