<?php

/* AppliBundle:Default:expert.html.twig */
class __TwigTemplate_cd9b17ab565158cfe3bbbbb81b96279e7a0102c6f6cafa06e7dbbe618ec212fc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "AppliBundle:Default:expert.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4c68f702494324023810fc1807975eb6aee222cb3650df7bb93a5ab5dc989b66 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4c68f702494324023810fc1807975eb6aee222cb3650df7bb93a5ab5dc989b66->enter($__internal_4c68f702494324023810fc1807975eb6aee222cb3650df7bb93a5ab5dc989b66_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppliBundle:Default:expert.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4c68f702494324023810fc1807975eb6aee222cb3650df7bb93a5ab5dc989b66->leave($__internal_4c68f702494324023810fc1807975eb6aee222cb3650df7bb93a5ab5dc989b66_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_31ecff0673c74e8a295fd32fbb79c6b3b108e6d39e22f250d4c8d0f30e22e3a0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_31ecff0673c74e8a295fd32fbb79c6b3b108e6d39e22f250d4c8d0f30e22e3a0->enter($__internal_31ecff0673c74e8a295fd32fbb79c6b3b108e6d39e22f250d4c8d0f30e22e3a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_31ecff0673c74e8a295fd32fbb79c6b3b108e6d39e22f250d4c8d0f30e22e3a0->leave($__internal_31ecff0673c74e8a295fd32fbb79c6b3b108e6d39e22f250d4c8d0f30e22e3a0_prof);

    }

    // line 9
    public function block_content($context, array $blocks = array())
    {
        $__internal_a35a9a09518d98a7fa32d3c16017092d9cd7162933c9c191a39fd16ac2ad6180 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a35a9a09518d98a7fa32d3c16017092d9cd7162933c9c191a39fd16ac2ad6180->enter($__internal_a35a9a09518d98a7fa32d3c16017092d9cd7162933c9c191a39fd16ac2ad6180_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 10
        echo "    ";
        // line 11
        echo "    Expert Page

";
        
        $__internal_a35a9a09518d98a7fa32d3c16017092d9cd7162933c9c191a39fd16ac2ad6180->leave($__internal_a35a9a09518d98a7fa32d3c16017092d9cd7162933c9c191a39fd16ac2ad6180_prof);

    }

    public function getTemplateName()
    {
        return "AppliBundle:Default:expert.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  54 => 11,  52 => 10,  46 => 9,  35 => 7,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layout.html.twig\" %}





{% block title %}{% endblock %}

{% block content %}
    {#{% block fos_user_content %}{% endblock %}#}
    Expert Page

{% endblock %}", "AppliBundle:Default:expert.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/src/AppliBundle/Resources/views/Default/expert.html.twig");
    }
}
