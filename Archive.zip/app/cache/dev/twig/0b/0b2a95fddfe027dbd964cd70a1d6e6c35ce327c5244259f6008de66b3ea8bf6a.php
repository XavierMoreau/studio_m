<?php

/* :conseil:index.html.twig */
class __TwigTemplate_e8e15109bb357acb36e0ecabf1aa0cc322296c645bb7c0473adb21cb0f547154 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":conseil:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_43560fb005fd928dd4a91a8c880c14388926676390c3305304d51ab99a0eb429 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_43560fb005fd928dd4a91a8c880c14388926676390c3305304d51ab99a0eb429->enter($__internal_43560fb005fd928dd4a91a8c880c14388926676390c3305304d51ab99a0eb429_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":conseil:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_43560fb005fd928dd4a91a8c880c14388926676390c3305304d51ab99a0eb429->leave($__internal_43560fb005fd928dd4a91a8c880c14388926676390c3305304d51ab99a0eb429_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_9a4d9cbe857e6ac76d41fda264217b2caa46d8324984efb062d6d3ea9cebffba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9a4d9cbe857e6ac76d41fda264217b2caa46d8324984efb062d6d3ea9cebffba->enter($__internal_9a4d9cbe857e6ac76d41fda264217b2caa46d8324984efb062d6d3ea9cebffba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Conseils list</h1>

    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Temps</th>
                <th>Daterequise</th>
                <th>Datedemande</th>
                <th>Quantite</th>
                <th>Storyboard</th>
                <th>Commande</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["conseils"]) ? $context["conseils"] : $this->getContext($context, "conseils")));
        foreach ($context['_seq'] as $context["_key"] => $context["conseil"]) {
            // line 21
            echo "            <tr>
                <td><a href=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("conseil_show", array("id" => $this->getAttribute($context["conseil"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["conseil"], "id", array()), "html", null, true);
            echo "</a></td>
                <td>";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["conseil"], "temps", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 24
            if ($this->getAttribute($context["conseil"], "dateRequise", array())) {
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["conseil"], "dateRequise", array()), "Y-m-d"), "html", null, true);
            }
            echo "</td>
                <td>";
            // line 25
            if ($this->getAttribute($context["conseil"], "dateDemande", array())) {
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["conseil"], "dateDemande", array()), "Y-m-d H:i:s"), "html", null, true);
            }
            echo "</td>
                <td>";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["conseil"], "quantite", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["conseil"], "storyboard", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["conseil"], "commande", array()), "html", null, true);
            echo "</td>
                <td>
                    <ul>
                        <li>
                            <a href=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("conseil_show", array("id" => $this->getAttribute($context["conseil"], "id", array()))), "html", null, true);
            echo "\">show</a>
                        </li>
                        <li>
                            <a href=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("conseil_edit", array("id" => $this->getAttribute($context["conseil"], "id", array()))), "html", null, true);
            echo "\">edit</a>
                        </li>
                    </ul>
                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['conseil'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 41
        echo "        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 46
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("conseil_new");
        echo "\">Create a new conseil</a>
        </li>
    </ul>
";
        
        $__internal_9a4d9cbe857e6ac76d41fda264217b2caa46d8324984efb062d6d3ea9cebffba->leave($__internal_9a4d9cbe857e6ac76d41fda264217b2caa46d8324984efb062d6d3ea9cebffba_prof);

    }

    public function getTemplateName()
    {
        return ":conseil:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  127 => 46,  120 => 41,  108 => 35,  102 => 32,  95 => 28,  91 => 27,  87 => 26,  81 => 25,  75 => 24,  71 => 23,  65 => 22,  62 => 21,  58 => 20,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Conseils list</h1>

    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Temps</th>
                <th>Daterequise</th>
                <th>Datedemande</th>
                <th>Quantite</th>
                <th>Storyboard</th>
                <th>Commande</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        {% for conseil in conseils %}
            <tr>
                <td><a href=\"{{ path('conseil_show', { 'id': conseil.id }) }}\">{{ conseil.id }}</a></td>
                <td>{{ conseil.temps }}</td>
                <td>{% if conseil.dateRequise %}{{ conseil.dateRequise|date('Y-m-d') }}{% endif %}</td>
                <td>{% if conseil.dateDemande %}{{ conseil.dateDemande|date('Y-m-d H:i:s') }}{% endif %}</td>
                <td>{{ conseil.quantite }}</td>
                <td>{{ conseil.storyboard }}</td>
                <td>{{ conseil.commande }}</td>
                <td>
                    <ul>
                        <li>
                            <a href=\"{{ path('conseil_show', { 'id': conseil.id }) }}\">show</a>
                        </li>
                        <li>
                            <a href=\"{{ path('conseil_edit', { 'id': conseil.id }) }}\">edit</a>
                        </li>
                    </ul>
                </td>
            </tr>
        {% endfor %}
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"{{ path('conseil_new') }}\">Create a new conseil</a>
        </li>
    </ul>
{% endblock %}
", ":conseil:index.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/conseil/index.html.twig");
    }
}
