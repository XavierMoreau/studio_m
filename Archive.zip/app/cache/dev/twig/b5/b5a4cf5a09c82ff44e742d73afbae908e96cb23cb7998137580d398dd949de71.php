<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_1b2ff2b106b593e5c93650e7fc09d48799b9351304d4e7889d2ffcdbfaa95cea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_06831ceb39c1e2dcb8b1c6c4a39562c7c74d687f140fb67b758e5bcbc1a0fa96 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_06831ceb39c1e2dcb8b1c6c4a39562c7c74d687f140fb67b758e5bcbc1a0fa96->enter($__internal_06831ceb39c1e2dcb8b1c6c4a39562c7c74d687f140fb67b758e5bcbc1a0fa96_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_06831ceb39c1e2dcb8b1c6c4a39562c7c74d687f140fb67b758e5bcbc1a0fa96->leave($__internal_06831ceb39c1e2dcb8b1c6c4a39562c7c74d687f140fb67b758e5bcbc1a0fa96_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
", "@Framework/Form/container_attributes.html.php", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/container_attributes.html.php");
    }
}
