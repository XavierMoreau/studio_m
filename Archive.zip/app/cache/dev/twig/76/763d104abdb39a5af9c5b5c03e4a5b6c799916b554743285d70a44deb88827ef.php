<?php

/* :experttype:index.html.twig */
class __TwigTemplate_60ea043041386b4f06ff3cd879308e72ef1d2af7aef39d4c7e36e43c5fa8eaf3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":experttype:index.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fe0c817f439869b579209ea2e6507d715747378334a7d808bdf83962045cecc5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fe0c817f439869b579209ea2e6507d715747378334a7d808bdf83962045cecc5->enter($__internal_fe0c817f439869b579209ea2e6507d715747378334a7d808bdf83962045cecc5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":experttype:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fe0c817f439869b579209ea2e6507d715747378334a7d808bdf83962045cecc5->leave($__internal_fe0c817f439869b579209ea2e6507d715747378334a7d808bdf83962045cecc5_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_3ea684ef6dc85a7cb10185baba4b6bdf2de55df7eef2762e63bdd895ccff91d3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3ea684ef6dc85a7cb10185baba4b6bdf2de55df7eef2762e63bdd895ccff91d3->enter($__internal_3ea684ef6dc85a7cb10185baba4b6bdf2de55df7eef2762e63bdd895ccff91d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <h1>Types de métiers</h1>

    <table class=\"table table-striped\">
        <thead>
            <tr>
                <th>Métiers :</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["expertTypes"]) ? $context["expertTypes"] : $this->getContext($context, "expertTypes")));
        foreach ($context['_seq'] as $context["_key"] => $context["expertType"]) {
            // line 15
            echo "

            <tr>
                <td>";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["expertType"], "type", array()), "html", null, true);
            echo "</td>
                <td><a class=\"btn-modifier\" href=\"";
            // line 19
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("experttype_edit", array("id" => $this->getAttribute($context["expertType"], "id", array()))), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-edit\" aria-hidden=\"true\"></span></a></td>
                <td><a class=\"btn-delete\" href=\"";
            // line 20
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("experttype_delete", array("id" => $this->getAttribute($context["expertType"], "id", array()))), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-trash\" aria-hidden=\"true\"></span></a></td>

            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['expertType'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "        </tbody>
    </table>

    <a class=\"btn btn-primary\" href=\"";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("experttype_new");
        echo "\">Nouveau</a>

    <a class=\"btn btn-success\" href=\"";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("conseiltype_index");
        echo "\">Types de conseils</a>
    <a class=\"btn btn-default\" href=\"";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_index");
        echo "\">Retour</a>
";
        
        $__internal_3ea684ef6dc85a7cb10185baba4b6bdf2de55df7eef2762e63bdd895ccff91d3->leave($__internal_3ea684ef6dc85a7cb10185baba4b6bdf2de55df7eef2762e63bdd895ccff91d3_prof);

    }

    public function getTemplateName()
    {
        return ":experttype:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 30,  89 => 29,  84 => 27,  79 => 24,  69 => 20,  65 => 19,  61 => 18,  56 => 15,  52 => 14,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block content %}
    <h1>Types de métiers</h1>

    <table class=\"table table-striped\">
        <thead>
            <tr>
                <th>Métiers :</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        {% for expertType in expertTypes %}


            <tr>
                <td>{{ expertType.type }}</td>
                <td><a class=\"btn-modifier\" href=\"{{ path('experttype_edit', { 'id': expertType.id }) }}\"><span class=\"glyphicon glyphicon-edit\" aria-hidden=\"true\"></span></a></td>
                <td><a class=\"btn-delete\" href=\"{{ path('experttype_delete', { 'id': expertType.id }) }}\"><span class=\"glyphicon glyphicon-trash\" aria-hidden=\"true\"></span></a></td>

            </tr>
        {% endfor %}
        </tbody>
    </table>

    <a class=\"btn btn-primary\" href=\"{{ path('experttype_new') }}\">Nouveau</a>

    <a class=\"btn btn-success\" href=\"{{ path('conseiltype_index') }}\">Types de conseils</a>
    <a class=\"btn btn-default\" href=\"{{ path('admin_index') }}\">Retour</a>
{% endblock %}
", ":experttype:index.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/experttype/index.html.twig");
    }
}
