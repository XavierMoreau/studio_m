<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_929fb8345f4dc9661e6b0127553cd45b94d3022be201803be6e827b1352569b6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c5df4b2eaf6add568e572f74f611f649c1b80a35a7adc635cf88232ead400841 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c5df4b2eaf6add568e572f74f611f649c1b80a35a7adc635cf88232ead400841->enter($__internal_c5df4b2eaf6add568e572f74f611f649c1b80a35a7adc635cf88232ead400841_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_c5df4b2eaf6add568e572f74f611f649c1b80a35a7adc635cf88232ead400841->leave($__internal_c5df4b2eaf6add568e572f74f611f649c1b80a35a7adc635cf88232ead400841_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_label.html.php");
    }
}
