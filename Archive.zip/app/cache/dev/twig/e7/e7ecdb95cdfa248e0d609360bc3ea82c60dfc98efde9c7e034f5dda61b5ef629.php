<?php

/* FOSUserBundle:Resetting:reset.html.twig */
class __TwigTemplate_5ef2f808004a0741c6a2eb08e4c082cf5fcf46e18eecb549f65f1b2b9cb425e1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Resetting:reset.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c5eba3b09c709dd6b74fff9a76c1d40ea7929bc0d9b4fe0768740355b69beef8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c5eba3b09c709dd6b74fff9a76c1d40ea7929bc0d9b4fe0768740355b69beef8->enter($__internal_c5eba3b09c709dd6b74fff9a76c1d40ea7929bc0d9b4fe0768740355b69beef8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:reset.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c5eba3b09c709dd6b74fff9a76c1d40ea7929bc0d9b4fe0768740355b69beef8->leave($__internal_c5eba3b09c709dd6b74fff9a76c1d40ea7929bc0d9b4fe0768740355b69beef8_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_d8c6d638c46aae09914513578e1cf68be1f34159ae99cb36597927fa5582643b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d8c6d638c46aae09914513578e1cf68be1f34159ae99cb36597927fa5582643b->enter($__internal_d8c6d638c46aae09914513578e1cf68be1f34159ae99cb36597927fa5582643b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Resetting/reset_content.html.twig", "FOSUserBundle:Resetting:reset.html.twig", 4)->display($context);
        
        $__internal_d8c6d638c46aae09914513578e1cf68be1f34159ae99cb36597927fa5582643b->leave($__internal_d8c6d638c46aae09914513578e1cf68be1f34159ae99cb36597927fa5582643b_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:reset.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Resetting/reset_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Resetting:reset.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/friendsofsymfony/user-bundle/Resources/views/Resetting/reset.html.twig");
    }
}
