<?php

/* FOSUserBundle:Resetting:reset.html.twig */
class __TwigTemplate_5ef2f808004a0741c6a2eb08e4c082cf5fcf46e18eecb549f65f1b2b9cb425e1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Resetting:reset.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a93fc95170555801a38be5aec0dfce8ed655183b5c1447785c468a4f41c4b724 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a93fc95170555801a38be5aec0dfce8ed655183b5c1447785c468a4f41c4b724->enter($__internal_a93fc95170555801a38be5aec0dfce8ed655183b5c1447785c468a4f41c4b724_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:reset.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a93fc95170555801a38be5aec0dfce8ed655183b5c1447785c468a4f41c4b724->leave($__internal_a93fc95170555801a38be5aec0dfce8ed655183b5c1447785c468a4f41c4b724_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_1277bbb3d895b09b9494150c0f01ebeba9ccc6b71aeaa65b72bca3f0e8e51f93 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1277bbb3d895b09b9494150c0f01ebeba9ccc6b71aeaa65b72bca3f0e8e51f93->enter($__internal_1277bbb3d895b09b9494150c0f01ebeba9ccc6b71aeaa65b72bca3f0e8e51f93_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Resetting/reset_content.html.twig", "FOSUserBundle:Resetting:reset.html.twig", 4)->display($context);
        
        $__internal_1277bbb3d895b09b9494150c0f01ebeba9ccc6b71aeaa65b72bca3f0e8e51f93->leave($__internal_1277bbb3d895b09b9494150c0f01ebeba9ccc6b71aeaa65b72bca3f0e8e51f93_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:reset.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Resetting/reset_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Resetting:reset.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/friendsofsymfony/user-bundle/Resources/views/Resetting/reset.html.twig");
    }
}
