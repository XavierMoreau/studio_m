<?php

/* AppliBundle:Default:index.html.twig */
class __TwigTemplate_82f0952fca44330644a4f19ce1fa899393eaffec41b0cf294f72a46415d443d2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "AppliBundle:Default:index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'contentlarge' => array($this, 'block_contentlarge'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e60acd0649437ee53366cb4f931f4e4cfc0d6344341d5581244943ed97694f72 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e60acd0649437ee53366cb4f931f4e4cfc0d6344341d5581244943ed97694f72->enter($__internal_e60acd0649437ee53366cb4f931f4e4cfc0d6344341d5581244943ed97694f72_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppliBundle:Default:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e60acd0649437ee53366cb4f931f4e4cfc0d6344341d5581244943ed97694f72->leave($__internal_e60acd0649437ee53366cb4f931f4e4cfc0d6344341d5581244943ed97694f72_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_b8e6051df6b22ad85192628dc9df556c557b19c56680df99855858e624c7f906 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b8e6051df6b22ad85192628dc9df556c557b19c56680df99855858e624c7f906->enter($__internal_b8e6051df6b22ad85192628dc9df556c557b19c56680df99855858e624c7f906_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_b8e6051df6b22ad85192628dc9df556c557b19c56680df99855858e624c7f906->leave($__internal_b8e6051df6b22ad85192628dc9df556c557b19c56680df99855858e624c7f906_prof);

    }

    // line 9
    public function block_contentlarge($context, array $blocks = array())
    {
        $__internal_5b03cae45c79e184a52d5f6761e590ffe8603b7759c0f2d8fa587eb1d8b52164 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5b03cae45c79e184a52d5f6761e590ffe8603b7759c0f2d8fa587eb1d8b52164->enter($__internal_5b03cae45c79e184a52d5f6761e590ffe8603b7759c0f2d8fa587eb1d8b52164_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contentlarge"));

        // line 10
        echo "    ";
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_USER")) {
            // line 11
            echo "



    <table style=\"text-align: center; width: 100%\">
        <tr>
            <td width=\"167\"><a href=\"";
            // line 17
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_new", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()))), "html", null, true);
            echo "\"><img class=\"imgflat\" src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/file.png"), "html", null, true);
            echo "\" alt=\"Nouveau projets\" height=\"150\"><h3 style=\"color: #ff5419\">Nouveau Projet</h3></a></td>
            <td width=\"167\"><a href=\"";
            // line 18
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_profile_show");
            echo "\"><img class=\"imgflat\" src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/astronaut.png"), "html", null, true);
            echo "\" alt=\"Projets\" height=\"150\"><h3 style=\"color: #386895\">Profil</h3></a></td>

        </tr>
        <tr>
            <td width=\"167\"><a href=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()))), "html", null, true);
            echo "\"><img class=\"imgflat\" src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/projection.png"), "html", null, true);
            echo "\" alt=\"Projets\" height=\"150\"><h3 style=\"color: #4AB8A1\">Projets</h3></a></td>

                  <td width=\"167\"><a href=\"";
            // line 24
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_logout");
            echo "\"><img class=\"imgflat\" src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/logout.png"), "html", null, true);
            echo "\" alt=\"Projets\" height=\"150\"><h3 style=\"color: #FABC3D\">Déconnection</h3></a></td>
        </tr>

    </table>
";
        }
        // line 29
        echo "



";
        
        $__internal_5b03cae45c79e184a52d5f6761e590ffe8603b7759c0f2d8fa587eb1d8b52164->leave($__internal_5b03cae45c79e184a52d5f6761e590ffe8603b7759c0f2d8fa587eb1d8b52164_prof);

    }

    public function getTemplateName()
    {
        return "AppliBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  95 => 29,  85 => 24,  78 => 22,  69 => 18,  63 => 17,  55 => 11,  52 => 10,  46 => 9,  35 => 7,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layout.html.twig\" %}





{% block title %}{% endblock %}

{% block contentlarge %}
    {% if is_granted(\"ROLE_USER\") %}




    <table style=\"text-align: center; width: 100%\">
        <tr>
            <td width=\"167\"><a href=\"{{ path('projet_new', { 'id': app.user.id }) }}\"><img class=\"imgflat\" src=\"{{ asset('images/file.png')}}\" alt=\"Nouveau projets\" height=\"150\"><h3 style=\"color: #ff5419\">Nouveau Projet</h3></a></td>
            <td width=\"167\"><a href=\"{{ path('fos_user_profile_show')}}\"><img class=\"imgflat\" src=\"{{ asset('images/astronaut.png')}}\" alt=\"Projets\" height=\"150\"><h3 style=\"color: #386895\">Profil</h3></a></td>

        </tr>
        <tr>
            <td width=\"167\"><a href=\"{{ path('projet_index', { 'id': app.user.id }) }}\"><img class=\"imgflat\" src=\"{{ asset('images/projection.png')}}\" alt=\"Projets\" height=\"150\"><h3 style=\"color: #4AB8A1\">Projets</h3></a></td>

                  <td width=\"167\"><a href=\"{{ path('fos_user_security_logout')}}\"><img class=\"imgflat\" src=\"{{ asset('images/logout.png')}}\" alt=\"Projets\" height=\"150\"><h3 style=\"color: #FABC3D\">Déconnection</h3></a></td>
        </tr>

    </table>
{% endif %}




{% endblock %}



", "AppliBundle:Default:index.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/src/AppliBundle/Resources/views/Default/index.html.twig");
    }
}
