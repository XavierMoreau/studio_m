<?php

/* AppliBundle:Default:index.html.twig */
class __TwigTemplate_82f0952fca44330644a4f19ce1fa899393eaffec41b0cf294f72a46415d443d2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "AppliBundle:Default:index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'contentlarge' => array($this, 'block_contentlarge'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dc6694ba15946efd19df3dc5db41ceae76bb84bf14b39454eff6c72ec950869b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dc6694ba15946efd19df3dc5db41ceae76bb84bf14b39454eff6c72ec950869b->enter($__internal_dc6694ba15946efd19df3dc5db41ceae76bb84bf14b39454eff6c72ec950869b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppliBundle:Default:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_dc6694ba15946efd19df3dc5db41ceae76bb84bf14b39454eff6c72ec950869b->leave($__internal_dc6694ba15946efd19df3dc5db41ceae76bb84bf14b39454eff6c72ec950869b_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_47fe3727e8fdd74fd37d39a6cde92011a21db09cbb9afd5a7cfd95c1cf7f6474 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_47fe3727e8fdd74fd37d39a6cde92011a21db09cbb9afd5a7cfd95c1cf7f6474->enter($__internal_47fe3727e8fdd74fd37d39a6cde92011a21db09cbb9afd5a7cfd95c1cf7f6474_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_47fe3727e8fdd74fd37d39a6cde92011a21db09cbb9afd5a7cfd95c1cf7f6474->leave($__internal_47fe3727e8fdd74fd37d39a6cde92011a21db09cbb9afd5a7cfd95c1cf7f6474_prof);

    }

    // line 9
    public function block_contentlarge($context, array $blocks = array())
    {
        $__internal_414dc4d590b5898b0d23d713c6f81955007c9adbd1e94303fa1fb2c1085758f1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_414dc4d590b5898b0d23d713c6f81955007c9adbd1e94303fa1fb2c1085758f1->enter($__internal_414dc4d590b5898b0d23d713c6f81955007c9adbd1e94303fa1fb2c1085758f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contentlarge"));

        // line 10
        echo "    ";
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_USER")) {
            // line 11
            echo "



    <table style=\"text-align: center; width: 100%\">
        <tr>
            <td width=\"167\"><a href=\"";
            // line 17
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_new", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()))), "html", null, true);
            echo "\"><img class=\"imgflat\" src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/file.png"), "html", null, true);
            echo "\" alt=\"Nouveau projets\" height=\"150\"><h3 style=\"color: #ff5419\">Nouveau Projet</h3></a></td>
            <td width=\"167\"><a href=\"";
            // line 18
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_profile_show");
            echo "\"><img class=\"imgflat\" src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/astronaut.png"), "html", null, true);
            echo "\" alt=\"Projets\" height=\"150\"><h3 style=\"color: #386895\">Profil</h3></a></td>

        </tr>
        <tr>
            <td width=\"167\"><a href=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()))), "html", null, true);
            echo "\"><img class=\"imgflat\" src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/projection.png"), "html", null, true);
            echo "\" alt=\"Projets\" height=\"150\"><h3 style=\"color: #4AB8A1\">Projets</h3></a></td>

                  <td width=\"167\"><a href=\"";
            // line 24
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_logout");
            echo "\"><img class=\"imgflat\" src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/logout.png"), "html", null, true);
            echo "\" alt=\"Projets\" height=\"150\"><h3 style=\"color: #FABC3D\">Déconnection</h3></a></td>
        </tr>

    </table>
";
        }
        // line 29
        echo "



";
        
        $__internal_414dc4d590b5898b0d23d713c6f81955007c9adbd1e94303fa1fb2c1085758f1->leave($__internal_414dc4d590b5898b0d23d713c6f81955007c9adbd1e94303fa1fb2c1085758f1_prof);

    }

    public function getTemplateName()
    {
        return "AppliBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  95 => 29,  85 => 24,  78 => 22,  69 => 18,  63 => 17,  55 => 11,  52 => 10,  46 => 9,  35 => 7,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layout.html.twig\" %}





{% block title %}{% endblock %}

{% block contentlarge %}
    {% if is_granted(\"ROLE_USER\") %}




    <table style=\"text-align: center; width: 100%\">
        <tr>
            <td width=\"167\"><a href=\"{{ path('projet_new', { 'id': app.user.id }) }}\"><img class=\"imgflat\" src=\"{{ asset('images/file.png')}}\" alt=\"Nouveau projets\" height=\"150\"><h3 style=\"color: #ff5419\">Nouveau Projet</h3></a></td>
            <td width=\"167\"><a href=\"{{ path('fos_user_profile_show')}}\"><img class=\"imgflat\" src=\"{{ asset('images/astronaut.png')}}\" alt=\"Projets\" height=\"150\"><h3 style=\"color: #386895\">Profil</h3></a></td>

        </tr>
        <tr>
            <td width=\"167\"><a href=\"{{ path('projet_index', { 'id': app.user.id }) }}\"><img class=\"imgflat\" src=\"{{ asset('images/projection.png')}}\" alt=\"Projets\" height=\"150\"><h3 style=\"color: #4AB8A1\">Projets</h3></a></td>

                  <td width=\"167\"><a href=\"{{ path('fos_user_security_logout')}}\"><img class=\"imgflat\" src=\"{{ asset('images/logout.png')}}\" alt=\"Projets\" height=\"150\"><h3 style=\"color: #FABC3D\">Déconnection</h3></a></td>
        </tr>

    </table>
{% endif %}




{% endblock %}



", "AppliBundle:Default:index.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/src/AppliBundle/Resources/views/Default/index.html.twig");
    }
}
