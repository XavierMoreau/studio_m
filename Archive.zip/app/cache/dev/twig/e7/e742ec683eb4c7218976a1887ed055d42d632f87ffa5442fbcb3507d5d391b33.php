<?php

/* :conseiltype:index.html.twig */
class __TwigTemplate_e0ae920c1fb2ef8a9c3ba07fab832e617be025c1dd4b287ece32f7b805b82d36 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":conseiltype:index.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_555ded56dd73278c9225c55ae731d9364e0890b5e8f63137b1d83b39de0949e5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_555ded56dd73278c9225c55ae731d9364e0890b5e8f63137b1d83b39de0949e5->enter($__internal_555ded56dd73278c9225c55ae731d9364e0890b5e8f63137b1d83b39de0949e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":conseiltype:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_555ded56dd73278c9225c55ae731d9364e0890b5e8f63137b1d83b39de0949e5->leave($__internal_555ded56dd73278c9225c55ae731d9364e0890b5e8f63137b1d83b39de0949e5_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_74741a197c56febece298acfad6cefdd759d6358a471f5a1261f5b9fc300d253 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_74741a197c56febece298acfad6cefdd759d6358a471f5a1261f5b9fc300d253->enter($__internal_74741a197c56febece298acfad6cefdd759d6358a471f5a1261f5b9fc300d253_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <h1>Types de conseil</h1>

    <table class=\"table table-striped\">
        <thead>
            <tr>
                <th>Types proposés :</th>
                <th><a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("experttype_index");
        echo "\">Métiers : </a></th>
                <th></th>
            </tr>
        </thead>
        <tbody>

        ";
        // line 16
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["conseilTypes"]) ? $context["conseilTypes"] : $this->getContext($context, "conseilTypes")));
        foreach ($context['_seq'] as $context["_key"] => $context["conseilType"]) {
            // line 17
            echo "
              <tr>

                <td>";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["conseilType"], "type", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["conseilType"], "expertType", array()), "type", array()), "html", null, true);
            echo "</td>
                <td><a class=\"btn-modifier\" href=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("conseiltype_edit", array("id" => $this->getAttribute($context["conseilType"], "id", array()))), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-edit\" aria-hidden=\"true\"></span></a></td>
                <td><a class=\"btn-delete\" href=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("conseiltype_delete", array("id" => $this->getAttribute($context["conseilType"], "id", array()))), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-trash\" aria-hidden=\"true\"></span></a></td>


            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['conseilType'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 28
        echo "        </tbody>
    </table>

    <a class=\"btn btn-primary\" href=\"";
        // line 31
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("conseiltype_new");
        echo "\">Nouveau</a>

    <a class=\"btn btn-default\" href=\"";
        // line 33
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_index");
        echo "\">Retour</a>




";
        
        $__internal_74741a197c56febece298acfad6cefdd759d6358a471f5a1261f5b9fc300d253->leave($__internal_74741a197c56febece298acfad6cefdd759d6358a471f5a1261f5b9fc300d253_prof);

    }

    public function getTemplateName()
    {
        return ":conseiltype:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  99 => 33,  94 => 31,  89 => 28,  78 => 23,  74 => 22,  70 => 21,  66 => 20,  61 => 17,  57 => 16,  48 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block content %}
    <h1>Types de conseil</h1>

    <table class=\"table table-striped\">
        <thead>
            <tr>
                <th>Types proposés :</th>
                <th><a href=\"{{ path('experttype_index') }}\">Métiers : </a></th>
                <th></th>
            </tr>
        </thead>
        <tbody>

        {% for conseilType in conseilTypes %}

              <tr>

                <td>{{ conseilType.type }}</td>
                <td>{{ conseilType.expertType.type }}</td>
                <td><a class=\"btn-modifier\" href=\"{{ path('conseiltype_edit', { 'id': conseilType.id }) }}\"><span class=\"glyphicon glyphicon-edit\" aria-hidden=\"true\"></span></a></td>
                <td><a class=\"btn-delete\" href=\"{{ path('conseiltype_delete', { 'id': conseilType.id }) }}\"><span class=\"glyphicon glyphicon-trash\" aria-hidden=\"true\"></span></a></td>


            </tr>
        {% endfor %}
        </tbody>
    </table>

    <a class=\"btn btn-primary\" href=\"{{ path('conseiltype_new') }}\">Nouveau</a>

    <a class=\"btn btn-default\" href=\"{{ path('admin_index') }}\">Retour</a>




{% endblock %}
", ":conseiltype:index.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/conseiltype/index.html.twig");
    }
}
