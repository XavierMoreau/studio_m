<?php

/* AppliBundle:Default:unauthorized.html.twig */
class __TwigTemplate_18c3b3914299dee7dde79ce3f158e99ec02f2959dc850376179ab507cad17e3c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "AppliBundle:Default:unauthorized.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b1b87e951e1ed4159ab1956798ec1ff8088f241eb50485e945fd896da32f75a2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b1b87e951e1ed4159ab1956798ec1ff8088f241eb50485e945fd896da32f75a2->enter($__internal_b1b87e951e1ed4159ab1956798ec1ff8088f241eb50485e945fd896da32f75a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppliBundle:Default:unauthorized.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b1b87e951e1ed4159ab1956798ec1ff8088f241eb50485e945fd896da32f75a2->leave($__internal_b1b87e951e1ed4159ab1956798ec1ff8088f241eb50485e945fd896da32f75a2_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_38460650a06fa86a628ff38b16dae7f39da6e30fd7b440c3154219afd8fd1fb7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_38460650a06fa86a628ff38b16dae7f39da6e30fd7b440c3154219afd8fd1fb7->enter($__internal_38460650a06fa86a628ff38b16dae7f39da6e30fd7b440c3154219afd8fd1fb7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "

    <table style=\"text-align: center; width: 100%\">
        <tr>
            <td width=\"167\"><img class=\"imgflat\" src=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/vince.gif"), "html", null, true);
        echo "\" alt=\"Heu...\" height=\"150\"><h3 style=\"color: #000000\">Oups... vous n'êtes pas au bon endroit !</h3></td>

        </tr>



    </table>



";
        
        $__internal_38460650a06fa86a628ff38b16dae7f39da6e30fd7b440c3154219afd8fd1fb7->leave($__internal_38460650a06fa86a628ff38b16dae7f39da6e30fd7b440c3154219afd8fd1fb7_prof);

    }

    public function getTemplateName()
    {
        return "AppliBundle:Default:unauthorized.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  46 => 8,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block body %}


    <table style=\"text-align: center; width: 100%\">
        <tr>
            <td width=\"167\"><img class=\"imgflat\" src=\"{{ asset('images/vince.gif')}}\" alt=\"Heu...\" height=\"150\"><h3 style=\"color: #000000\">Oups... vous n'êtes pas au bon endroit !</h3></td>

        </tr>



    </table>



{% endblock %}", "AppliBundle:Default:unauthorized.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/src/AppliBundle/Resources/views/Default/unauthorized.html.twig");
    }
}
