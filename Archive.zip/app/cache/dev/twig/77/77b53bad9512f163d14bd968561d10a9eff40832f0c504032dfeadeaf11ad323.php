<?php

/* :diffusion:index.html.twig */
class __TwigTemplate_4338c49648f57a10544a6e54863b7062beb30fc9c5454511f009a638601bfa2b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":diffusion:index.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_590be4b7df8bf91f49d8d2759a9b291043208ff3c68b63166f58e731ff8d3e4a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_590be4b7df8bf91f49d8d2759a9b291043208ff3c68b63166f58e731ff8d3e4a->enter($__internal_590be4b7df8bf91f49d8d2759a9b291043208ff3c68b63166f58e731ff8d3e4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":diffusion:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_590be4b7df8bf91f49d8d2759a9b291043208ff3c68b63166f58e731ff8d3e4a->leave($__internal_590be4b7df8bf91f49d8d2759a9b291043208ff3c68b63166f58e731ff8d3e4a_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_c195f6b202895ef8e32abdafcc84d77dca26e55440103daf4903adc15c19b1f0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c195f6b202895ef8e32abdafcc84d77dca26e55440103daf4903adc15c19b1f0->enter($__internal_c195f6b202895ef8e32abdafcc84d77dca26e55440103daf4903adc15c19b1f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <h1>Types de diffusion</h1>

    <table  class=\"table table-striped\">
        <thead>
            <tr>
                <th>Types proposés :</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["diffusions"]) ? $context["diffusions"] : $this->getContext($context, "diffusions")));
        foreach ($context['_seq'] as $context["_key"] => $context["diffusion"]) {
            // line 15
            echo "            <tr>
                <td>";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute($context["diffusion"], "diffusionType", array()), "html", null, true);
            echo "</td>
                <td><a class=\"btn-modifier\" href=\"";
            // line 17
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("diffusion_edit", array("id" => $this->getAttribute($context["diffusion"], "id", array()))), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-edit\" aria-hidden=\"true\"></span></a></td>
                <td><a class=\"btn-delete\"  href=\"";
            // line 18
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("diffusion_delete", array("id" => $this->getAttribute($context["diffusion"], "id", array()))), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-trash\" aria-hidden=\"true\"></span></a></td>

            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['diffusion'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 22
        echo "        </tbody>
    </table>


            <a class=\"btn btn-primary\" href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("diffusion_new");
        echo "\">Nouveau</a>


    <a class=\"btn btn-default\" href=\"";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_index");
        echo "\">Retour</a>

";
        
        $__internal_c195f6b202895ef8e32abdafcc84d77dca26e55440103daf4903adc15c19b1f0->leave($__internal_c195f6b202895ef8e32abdafcc84d77dca26e55440103daf4903adc15c19b1f0_prof);

    }

    public function getTemplateName()
    {
        return ":diffusion:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  89 => 29,  83 => 26,  77 => 22,  67 => 18,  63 => 17,  59 => 16,  56 => 15,  52 => 14,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block content %}
    <h1>Types de diffusion</h1>

    <table  class=\"table table-striped\">
        <thead>
            <tr>
                <th>Types proposés :</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        {% for diffusion in diffusions %}
            <tr>
                <td>{{ diffusion.diffusionType }}</td>
                <td><a class=\"btn-modifier\" href=\"{{ path('diffusion_edit', { 'id': diffusion.id }) }}\"><span class=\"glyphicon glyphicon-edit\" aria-hidden=\"true\"></span></a></td>
                <td><a class=\"btn-delete\"  href=\"{{ path('diffusion_delete', { 'id': diffusion.id }) }}\"><span class=\"glyphicon glyphicon-trash\" aria-hidden=\"true\"></span></a></td>

            </tr>
        {% endfor %}
        </tbody>
    </table>


            <a class=\"btn btn-primary\" href=\"{{ path('diffusion_new') }}\">Nouveau</a>


    <a class=\"btn btn-default\" href=\"{{ path('admin_index') }}\">Retour</a>

{% endblock %}
", ":diffusion:index.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/diffusion/index.html.twig");
    }
}
