<?php

/* :diffusion:edit.html.twig */
class __TwigTemplate_d870e07b6a3b0bfb2ba5a995dcff7124c1126e836ced60a059f79591d3bfccb5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":diffusion:edit.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_16f4b9fd069179105dd9543d3897be7ee5d9498c6c119a82ce2b1c273ec87be8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_16f4b9fd069179105dd9543d3897be7ee5d9498c6c119a82ce2b1c273ec87be8->enter($__internal_16f4b9fd069179105dd9543d3897be7ee5d9498c6c119a82ce2b1c273ec87be8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":diffusion:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_16f4b9fd069179105dd9543d3897be7ee5d9498c6c119a82ce2b1c273ec87be8->leave($__internal_16f4b9fd069179105dd9543d3897be7ee5d9498c6c119a82ce2b1c273ec87be8_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_7da78308b5589c9f054be0aa54e5ae3f3265801eb0642d67dda769d3cd9b0b6c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7da78308b5589c9f054be0aa54e5ae3f3265801eb0642d67dda769d3cd9b0b6c->enter($__internal_7da78308b5589c9f054be0aa54e5ae3f3265801eb0642d67dda769d3cd9b0b6c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <h1>Type de diffusion</h1>

    ";
        // line 6
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "
        <input class=\"btn btn-primary\" type=\"submit\" value=\"Enregistrer\" />
    <a class=\"btn btn-default\" href=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("diffusion_index");
        echo "\">Retour</a>
    ";
        // line 10
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "



";
        
        $__internal_7da78308b5589c9f054be0aa54e5ae3f3265801eb0642d67dda769d3cd9b0b6c->leave($__internal_7da78308b5589c9f054be0aa54e5ae3f3265801eb0642d67dda769d3cd9b0b6c_prof);

    }

    public function getTemplateName()
    {
        return ":diffusion:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 10,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block content %}
    <h1>Type de diffusion</h1>

    {{ form_start(edit_form) }}
        {{ form_widget(edit_form) }}
        <input class=\"btn btn-primary\" type=\"submit\" value=\"Enregistrer\" />
    <a class=\"btn btn-default\" href=\"{{ path('diffusion_index') }}\">Retour</a>
    {{ form_end(edit_form) }}



{% endblock %}
", ":diffusion:edit.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/diffusion/edit.html.twig");
    }
}
