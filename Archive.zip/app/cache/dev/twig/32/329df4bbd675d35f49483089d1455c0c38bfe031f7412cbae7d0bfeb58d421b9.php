<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_f54d7e9f52811aa40af068145b24f1a98f588a73ba70fc97dfb41fac2847913f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4aef5b107fd634fa5fca6010516c266caa367335c9ae5edf9bfbb2e9b57b3995 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4aef5b107fd634fa5fca6010516c266caa367335c9ae5edf9bfbb2e9b57b3995->enter($__internal_4aef5b107fd634fa5fca6010516c266caa367335c9ae5edf9bfbb2e9b57b3995_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_4aef5b107fd634fa5fca6010516c266caa367335c9ae5edf9bfbb2e9b57b3995->leave($__internal_4aef5b107fd634fa5fca6010516c266caa367335c9ae5edf9bfbb2e9b57b3995_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_enctype.html.php");
    }
}
