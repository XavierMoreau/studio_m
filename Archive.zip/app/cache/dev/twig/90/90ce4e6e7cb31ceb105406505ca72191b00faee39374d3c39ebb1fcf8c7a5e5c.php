<?php

/* :experttype:new.html.twig */
class __TwigTemplate_69fff7bec42e273ef3ace033630e8bbabaa07cb8ec6ac735683c8a2202cf3f14 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":experttype:new.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bce1383c7e22b1956d8d887e8e83aa7d6f95e2f8381808796bc65b26bdbbb115 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bce1383c7e22b1956d8d887e8e83aa7d6f95e2f8381808796bc65b26bdbbb115->enter($__internal_bce1383c7e22b1956d8d887e8e83aa7d6f95e2f8381808796bc65b26bdbbb115_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":experttype:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bce1383c7e22b1956d8d887e8e83aa7d6f95e2f8381808796bc65b26bdbbb115->leave($__internal_bce1383c7e22b1956d8d887e8e83aa7d6f95e2f8381808796bc65b26bdbbb115_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_e254c0872696c35ebb90346d8d22e8a3cc3e2ca1c371e55d6b7d26c91655c604 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e254c0872696c35ebb90346d8d22e8a3cc3e2ca1c371e55d6b7d26c91655c604->enter($__internal_e254c0872696c35ebb90346d8d22e8a3cc3e2ca1c371e55d6b7d26c91655c604_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <h1>Nouveau type de métier</h1>

    ";
        // line 6
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
    ";
        // line 7
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
    <input class=\"btn btn-primary\" type=\"submit\" value=\"Créer\" />
    <a class=\"btn btn-default\" href=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("experttype_index");
        echo "\">Retour</a>
    ";
        // line 10
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "


";
        
        $__internal_e254c0872696c35ebb90346d8d22e8a3cc3e2ca1c371e55d6b7d26c91655c604->leave($__internal_e254c0872696c35ebb90346d8d22e8a3cc3e2ca1c371e55d6b7d26c91655c604_prof);

    }

    public function getTemplateName()
    {
        return ":experttype:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 10,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block content %}
    <h1>Nouveau type de métier</h1>

    {{ form_start(form) }}
    {{ form_widget(form) }}
    <input class=\"btn btn-primary\" type=\"submit\" value=\"Créer\" />
    <a class=\"btn btn-default\" href=\"{{ path('experttype_index') }}\">Retour</a>
    {{ form_end(form) }}


{% endblock %}
", ":experttype:new.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/experttype/new.html.twig");
    }
}
