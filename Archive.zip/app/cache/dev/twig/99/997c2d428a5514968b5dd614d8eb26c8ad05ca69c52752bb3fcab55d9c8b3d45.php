<?php

/* :script:voixoff.html.twig */
class __TwigTemplate_61f304732ba85f8058a8eda2af3373d22e7302c202cc22288ea0259833b96f33 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":script:voixoff.html.twig", 1);
        $this->blocks = array(
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6c6dad3a91d308d868b8ee4f7105d395771359e7a8320623eeef76265313681c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c6dad3a91d308d868b8ee4f7105d395771359e7a8320623eeef76265313681c->enter($__internal_6c6dad3a91d308d868b8ee4f7105d395771359e7a8320623eeef76265313681c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":script:voixoff.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6c6dad3a91d308d868b8ee4f7105d395771359e7a8320623eeef76265313681c->leave($__internal_6c6dad3a91d308d868b8ee4f7105d395771359e7a8320623eeef76265313681c_prof);

    }

    // line 4
    public function block_ariane($context, array $blocks = array())
    {
        $__internal_90c635604cc9389eafb7381012e1664027e494d72bacdd56f56ed4630cd6a22d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_90c635604cc9389eafb7381012e1664027e494d72bacdd56f56ed4630cd6a22d->enter($__internal_90c635604cc9389eafb7381012e1664027e494d72bacdd56f56ed4630cd6a22d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ariane"));

        // line 5
        echo "
     <div class=\"ariane grey\">
         <div class=\"ib sub-txt-small fine grey\">Projet en cours : </div><div class=\"ib fine lightgrey bord-droit\"> ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "nomProjet", array()), "html", null, true);
        echo "</div>

         <a href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine\">PROJETS</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Paramètres</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <a href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_orientation", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine\">SCRIPT</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Guide</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_voixoff", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Voix-Off</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Ecriture</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <div class=\"ib fine\">STORYBOARD</div>
         <div class=\"ib fine\">></div>
         <div class=\"ib fine petite\">Ecriture</div>

     </div>

 ";
        
        $__internal_90c635604cc9389eafb7381012e1664027e494d72bacdd56f56ed4630cd6a22d->leave($__internal_90c635604cc9389eafb7381012e1664027e494d72bacdd56f56ed4630cd6a22d_prof);

    }

    // line 42
    public function block_left($context, array $blocks = array())
    {
        $__internal_5cd5f189198c4bd3c7a6b213e053585e7c3fc05b00e7aad36c943a22f6f1dab3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5cd5f189198c4bd3c7a6b213e053585e7c3fc05b00e7aad36c943a22f6f1dab3->enter($__internal_5cd5f189198c4bd3c7a6b213e053585e7c3fc05b00e7aad36c943a22f6f1dab3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "left"));

        // line 43
        echo "

<table>

    <td style=\"width:70%; vertical-align: top;\">
        <div class=\"largeur-voixoff\">

            <form>

                <table class=\"title-tab\">
                    <td class=\"padding-ten\"><h3 class=\"script-voixoff hand\">Rédigez le texte de la voix-off</h3></td>
                </table>


                <div class=\"largeur-totale\">
                    <label for=\"voixoffglobal\"></label>
                    <textarea style=\"width: 98%;\" placeholder=\"Rédigez votre voix-off...\" rows=\"30\" class=\"questionnaire\" name=\"voixoff\">";
        // line 59
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "voixoffGlobal", array()), "html", null, true);
        echo "</textarea>
                </div>



                <div class=\"grey\">

                    ";
        // line 66
        $context["timing"] = ($this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "count", array()) / 2.5);
        // line 67
        echo "                    ";
        $context["minround"] = ((isset($context["timing"]) ? $context["timing"] : $this->getContext($context, "timing")) / 60);
        // line 68
        echo "                    ";
        $context["min"] = twig_round((isset($context["minround"]) ? $context["minround"] : $this->getContext($context, "minround")), 0, "floor");
        // line 69
        echo "                    ";
        $context["sec"] = ((isset($context["timing"]) ? $context["timing"] : $this->getContext($context, "timing")) % 60);
        // line 70
        echo "
                    <div class=\"ib\">
                        <div class=\"ib sub-txt-big\">";
        // line 72
        if ($this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "count", array())) {
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "count", array()), "html", null, true);
        } else {
            echo "0";
        }
        echo "</div>
                        <div class=\"ib sub-txt-small bord-droit\">mots</div>
                    </div>
                    <div class=\"ib\">
                        <div class=\"ib sub-txt-small\">Durée estimée :</div>
                        <div class=\"ib sub-txt-big\">";
        // line 77
        echo twig_escape_filter($this->env, (isset($context["min"]) ? $context["min"] : $this->getContext($context, "min")), "html", null, true);
        echo "</div>
                        <div class=\"ib sub-txt-small\">min</div>
                        <div class=\"ib sub-txt-big\">";
        // line 79
        echo twig_escape_filter($this->env, (isset($context["sec"]) ? $context["sec"] : $this->getContext($context, "sec")), "html", null, true);
        echo "</div>
                        <div class=\"ib sub-txt-small bord-droit\">sec</div>
                    </div>





                    <div class=\"ib\">
                        <button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\" formmethod=\"post\" formaction=\"";
        // line 88
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_voixoff_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\">
                            <div class=\"ib\">
                            <table class=\"ib tab-buttons-petit shadow back-voixoff\">
                                <td>
                                    <div class=\"lightgrey fine\">Mettre à jour</div>
                                </td>
                                <td>
                                    <img src=\"";
        // line 95
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/refresh-button.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"19\">
                                </td>
                            </table>
                            </div>
                            <div class=\"ib\">
                            <table class=\"ib tab-buttons-petit shadow back-voixoff\">
                                <td>
                                    <div class=\"lightgrey fine\">Enregistrer</div>
                                </td>
                                <td>
                                    <img src=\"";
        // line 105
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/save-file-option.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"19\">
                                </td>
                            </table>
                    </div>
                        </button>



                    </div>

                </div>




            </form>

        </div>



            <table class=\"largeur-totale voixoff-boxes\">

                <td style=\"width:33%\" class=\"txt-center\">
                    <div class=\"script-voixoff-box1 back-questions\">
                    <a href=\"";
        // line 130
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
                        <div class=\"ib\">

                            <img src=\"";
        // line 133
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/list.png"), "html", null, true);
        echo "\" alt=\"Script\" height=\"30\">
                        </div>
                        <div>
                            <h3 class=\"ib hand petite\"><- Répondre aux questions</h3>
                        </div>
                        <div class=\"ib txtround2 fine\">
                            <h4 class=\"script-questions\">1</h4>
                        </div>
                   </a>
                    </div>
                </td>
                <td style=\"width:20%\"></td>

                <td style=\"width:33%\" class=\"txt-center\">
                    <div class=\"script-voixoff-box3 back-script\">
                        <a href=\"";
        // line 148
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">

                        <div class=\"ib\">
                            <img src=\"";
        // line 151
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pencil.png"), "html", null, true);
        echo "\" alt=\"Retour\" height=\"30\">
                        </div>
                        <div>
                            <h3 class=\"ib hand petite\">Ecrire le script -></h3>
                        </div>
                            <div class=\"ib txtround2 fine\">
                                <h4 class=\"script\">3</h4>
                            </div>
                    </a>
                    </div>
                </td>

            </table>


        </div>




    </td>
    <td style=\"vertical-align: top; padding-right: 3%; padding-top: 1.5%;\">


        <div class=\"largeur-voixoff-right back-voixoff padding-ten\">
            <a href=\"";
        // line 176
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">

            <h3 class=\"ib bord-droit lightgrey\">Vos réponses :</h3>
            </a>
            ";
        // line 180
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["reponses"]) ? $context["reponses"] : $this->getContext($context, "reponses")));
        foreach ($context['_seq'] as $context["key"] => $context["reponse"]) {
            // line 181
            echo "                <div class=\"id sub-txt-small grey\">
                      ";
            // line 182
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["reponse"], "question", array()), "question", array()), "html", null, true);
            echo "
                </div>

                <div class=\"id sub-txt-small lightgrey\">
                    ";
            // line 186
            if ($this->getAttribute($context["reponse"], "reponse", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "reponse", array()), "html", null, true);
                echo "
                    ";
            } else {
                // line 187
                echo " Vous n'avez pas répondu
                    ";
            }
            // line 189
            echo "                </div>

            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['reponse'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 192
        echo "        </div>

    </td>

</table>
";
        
        $__internal_5cd5f189198c4bd3c7a6b213e053585e7c3fc05b00e7aad36c943a22f6f1dab3->leave($__internal_5cd5f189198c4bd3c7a6b213e053585e7c3fc05b00e7aad36c943a22f6f1dab3_prof);

    }

    public function getTemplateName()
    {
        return ":script:voixoff.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  329 => 192,  321 => 189,  317 => 187,  311 => 186,  304 => 182,  301 => 181,  297 => 180,  290 => 176,  262 => 151,  256 => 148,  238 => 133,  232 => 130,  204 => 105,  191 => 95,  181 => 88,  169 => 79,  164 => 77,  152 => 72,  148 => 70,  145 => 69,  142 => 68,  139 => 67,  137 => 66,  127 => 59,  109 => 43,  103 => 42,  85 => 29,  78 => 25,  71 => 21,  64 => 17,  57 => 13,  50 => 9,  45 => 7,  41 => 5,  35 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


 {% block ariane %}

     <div class=\"ariane grey\">
         <div class=\"ib sub-txt-small fine grey\">Projet en cours : </div><div class=\"ib fine lightgrey bord-droit\"> {{ projet.nomProjet }}</div>

         <a href=\"{{ path('projet_index', {'id':app.user.id}) }}\">
             <div class=\"ib fine\">PROJETS</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('projet_edit', {'id':app.user.id, 'projet': projet.id, 'script' : script.id }) }}\">
             <div class=\"ib fine petite\">Paramètres</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <a href=\"{{ path('script_orientation', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine\">SCRIPT</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('script_questions', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine petite\">Guide</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('script_voixoff', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine petite\">Voix-Off</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('scriptecriture_index', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine petite\">Ecriture</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <div class=\"ib fine\">STORYBOARD</div>
         <div class=\"ib fine\">></div>
         <div class=\"ib fine petite\">Ecriture</div>

     </div>

 {% endblock %}


{% block left %}


<table>

    <td style=\"width:70%; vertical-align: top;\">
        <div class=\"largeur-voixoff\">

            <form>

                <table class=\"title-tab\">
                    <td class=\"padding-ten\"><h3 class=\"script-voixoff hand\">Rédigez le texte de la voix-off</h3></td>
                </table>


                <div class=\"largeur-totale\">
                    <label for=\"voixoffglobal\"></label>
                    <textarea style=\"width: 98%;\" placeholder=\"Rédigez votre voix-off...\" rows=\"30\" class=\"questionnaire\" name=\"voixoff\">{{ script.voixoffGlobal }}</textarea>
                </div>



                <div class=\"grey\">

                    {% set timing = script.count/2.5 %}
                    {%  set minround = timing/60 %}
                    {%  set min = minround|round(0, 'floor') %}
                    {%  set sec = timing%60 %}

                    <div class=\"ib\">
                        <div class=\"ib sub-txt-big\">{%  if script.count %}{{ script.count }}{% else %}0{% endif %}</div>
                        <div class=\"ib sub-txt-small bord-droit\">mots</div>
                    </div>
                    <div class=\"ib\">
                        <div class=\"ib sub-txt-small\">Durée estimée :</div>
                        <div class=\"ib sub-txt-big\">{{ min }}</div>
                        <div class=\"ib sub-txt-small\">min</div>
                        <div class=\"ib sub-txt-big\">{{ sec }}</div>
                        <div class=\"ib sub-txt-small bord-droit\">sec</div>
                    </div>





                    <div class=\"ib\">
                        <button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\" formmethod=\"post\" formaction=\"{{ path('script_voixoff_edit',{'id':app.user.id, 'projet': projet.id,'script': script.id})}}\">
                            <div class=\"ib\">
                            <table class=\"ib tab-buttons-petit shadow back-voixoff\">
                                <td>
                                    <div class=\"lightgrey fine\">Mettre à jour</div>
                                </td>
                                <td>
                                    <img src=\"{{ asset('images/refresh-button.png')}}\" alt=\"Enregistrer\" height=\"19\">
                                </td>
                            </table>
                            </div>
                            <div class=\"ib\">
                            <table class=\"ib tab-buttons-petit shadow back-voixoff\">
                                <td>
                                    <div class=\"lightgrey fine\">Enregistrer</div>
                                </td>
                                <td>
                                    <img src=\"{{ asset('images/save-file-option.png')}}\" alt=\"Enregistrer\" height=\"19\">
                                </td>
                            </table>
                    </div>
                        </button>



                    </div>

                </div>




            </form>

        </div>



            <table class=\"largeur-totale voixoff-boxes\">

                <td style=\"width:33%\" class=\"txt-center\">
                    <div class=\"script-voixoff-box1 back-questions\">
                    <a href=\"{{ path('script_questions', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
                        <div class=\"ib\">

                            <img src=\"{{ asset('images/list.png')}}\" alt=\"Script\" height=\"30\">
                        </div>
                        <div>
                            <h3 class=\"ib hand petite\"><- Répondre aux questions</h3>
                        </div>
                        <div class=\"ib txtround2 fine\">
                            <h4 class=\"script-questions\">1</h4>
                        </div>
                   </a>
                    </div>
                </td>
                <td style=\"width:20%\"></td>

                <td style=\"width:33%\" class=\"txt-center\">
                    <div class=\"script-voixoff-box3 back-script\">
                        <a href=\"{{ path('scriptecriture_index', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">

                        <div class=\"ib\">
                            <img src=\"{{ asset('images/pencil.png')}}\" alt=\"Retour\" height=\"30\">
                        </div>
                        <div>
                            <h3 class=\"ib hand petite\">Ecrire le script -></h3>
                        </div>
                            <div class=\"ib txtround2 fine\">
                                <h4 class=\"script\">3</h4>
                            </div>
                    </a>
                    </div>
                </td>

            </table>


        </div>




    </td>
    <td style=\"vertical-align: top; padding-right: 3%; padding-top: 1.5%;\">


        <div class=\"largeur-voixoff-right back-voixoff padding-ten\">
            <a href=\"{{ path('script_questions', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">

            <h3 class=\"ib bord-droit lightgrey\">Vos réponses :</h3>
            </a>
            {% for key,reponse in reponses %}
                <div class=\"id sub-txt-small grey\">
                      {{ reponse.question.question }}
                </div>

                <div class=\"id sub-txt-small lightgrey\">
                    {% if reponse.reponse %}{{ reponse.reponse }}
                    {% else %} Vous n'avez pas répondu
                    {% endif %}
                </div>

            {% endfor %}
        </div>

    </td>

</table>
{% endblock %}


", ":script:voixoff.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/script/voixoff.html.twig");
    }
}
