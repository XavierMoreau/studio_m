<?php

/* :script:voixoff.html.twig */
class __TwigTemplate_61f304732ba85f8058a8eda2af3373d22e7302c202cc22288ea0259833b96f33 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("layout.html.twig", ":script:voixoff.html.twig", 3);
        $this->blocks = array(
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8af603ab7e27f6516e979358d0282613de7ba76ba1a950100cc0e0326560104e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8af603ab7e27f6516e979358d0282613de7ba76ba1a950100cc0e0326560104e->enter($__internal_8af603ab7e27f6516e979358d0282613de7ba76ba1a950100cc0e0326560104e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":script:voixoff.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8af603ab7e27f6516e979358d0282613de7ba76ba1a950100cc0e0326560104e->leave($__internal_8af603ab7e27f6516e979358d0282613de7ba76ba1a950100cc0e0326560104e_prof);

    }

    // line 6
    public function block_ariane($context, array $blocks = array())
    {
        $__internal_8909979b25eb46fd29d351509acfcd4bc79dc6d7a9cada8292cbabb2c543eb73 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8909979b25eb46fd29d351509acfcd4bc79dc6d7a9cada8292cbabb2c543eb73->enter($__internal_8909979b25eb46fd29d351509acfcd4bc79dc6d7a9cada8292cbabb2c543eb73_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ariane"));

        // line 7
        echo "
     <div class=\"ariane grey\">
         <div class=\"ib sub-txt-small fine grey\">Projet en cours : </div><div class=\"ib fine lightgrey bord-droit\"> ";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "nomProjet", array()), "html", null, true);
        echo "</div>

         <a href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine\">PROJETS</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Paramètres</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <a href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_orientation", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine\">SCRIPT</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Guide</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_voixoff", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Voix-Off</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Ecriture</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <div class=\"ib fine\">STORYBOARD</div>
         <div class=\"ib fine\">></div>
         <div class=\"ib fine petite\">Ecriture</div>

     </div>

 ";
        
        $__internal_8909979b25eb46fd29d351509acfcd4bc79dc6d7a9cada8292cbabb2c543eb73->leave($__internal_8909979b25eb46fd29d351509acfcd4bc79dc6d7a9cada8292cbabb2c543eb73_prof);

    }

    // line 44
    public function block_left($context, array $blocks = array())
    {
        $__internal_36e01ff451dc249936b40d5d9cd0c9617664c8fa0aba35a815e8c22ae1201545 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_36e01ff451dc249936b40d5d9cd0c9617664c8fa0aba35a815e8c22ae1201545->enter($__internal_36e01ff451dc249936b40d5d9cd0c9617664c8fa0aba35a815e8c22ae1201545_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "left"));

        // line 45
        echo "

<table>

    <td style=\"width:65%; vertical-align: top; background-color: #e4e8e9;\">
        <div class=\"padding-ten\">

            <form>

                <table class=\"title-tab\">
                    <td class=\"padding-ten\"><h3 class=\"script-voixoff\">Rédigez le texte de la voix-off</h3></td>
                </table>


                <div class=\"largeur-totale\">
                    <label for=\"voixoffglobal\"></label>
                    <textarea style=\"width: 98%;\" placeholder=\"Rédigez votre voix-off...\" rows=\"24\" class=\"questionnaire\" name=\"voixoff\">";
        // line 61
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "voixoffGlobal", array()), "html", null, true);
        echo "</textarea>
                </div>



                <div class=\"grey\">

                    ";
        // line 68
        $context["timing"] = ($this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "count", array()) / 2.5);
        // line 69
        echo "                    ";
        $context["minround"] = ((isset($context["timing"]) ? $context["timing"] : $this->getContext($context, "timing")) / 60);
        // line 70
        echo "                    ";
        $context["min"] = twig_round((isset($context["minround"]) ? $context["minround"] : $this->getContext($context, "minround")), 0, "floor");
        // line 71
        echo "                    ";
        $context["sec"] = ((isset($context["timing"]) ? $context["timing"] : $this->getContext($context, "timing")) % 60);
        // line 72
        echo "
                    <div class=\"ib\">
                        <div class=\"ib sub-txt-big\">";
        // line 74
        if ($this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "count", array())) {
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "count", array()), "html", null, true);
        } else {
            echo "0";
        }
        echo "</div>
                        <div class=\"ib sub-txt-small bord-droit\">mots</div>
                    </div>
                    <div class=\"ib\">
                        <div class=\"ib sub-txt-small\">Durée estimée :</div>
                        <div class=\"ib sub-txt-big\">";
        // line 79
        echo twig_escape_filter($this->env, (isset($context["min"]) ? $context["min"] : $this->getContext($context, "min")), "html", null, true);
        echo "</div>
                        <div class=\"ib sub-txt-small\">min</div>
                        <div class=\"ib sub-txt-big\">";
        // line 81
        echo twig_escape_filter($this->env, (isset($context["sec"]) ? $context["sec"] : $this->getContext($context, "sec")), "html", null, true);
        echo "</div>
                        <div class=\"ib sub-txt-small bord-droit\">sec</div>
                    </div>

                    <div class=\"ib\">
                        <button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\" formmethod=\"post\" formaction=\"";
        // line 86
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_voixoff_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\">
                            <div class=\"ib\">
                            <table class=\"ib tab-buttons-petit shadow back-voixoff\">
                                <td>
                                    <div class=\"lightgrey\">Mettre à jour</div>
                                </td>
                                <td>
                                    <img src=\"";
        // line 93
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/refresh-button.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"19\">
                                </td>
                            </table>
                            </div>
                            <div class=\"ib\">
                            <table class=\"ib tab-buttons-petit shadow back-voixoff\">
                                <td>
                                    <div class=\"lightgrey\">Enregistrer</div>
                                </td>
                                <td>
                                    <img src=\"";
        // line 103
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/save-file-option.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"19\">
                                </td>
                            </table>
                    </div>
                        </button>



                    </div>

                </div>




            </form>





            <table class=\"largeur-totale padding-ten\">

                <td style=\"width:33%\" class=\"txt-center\">
                    <div class=\"script-voixoff-box1 shadow\">
                    <a href=\"";
        // line 128
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
                        <div class=\"ib\">

                            <img src=\"";
        // line 131
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/list.png"), "html", null, true);
        echo "\" alt=\"Script\" height=\"30\">
                        </div>
                        <div>
                            <h3 class=\"ib hand petite\"><- Répondre aux questions</h3>
                        </div>
                   </a>
                    </div>
                </td>
                <td style=\"width:30%\"></td>

                <td style=\"width:33%\" class=\"txt-center\">
                    <div class=\"script-voixoff-box3 shadow\">
                        <a href=\"";
        // line 143
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">

                        <div class=\"ib\">
                            <img src=\"";
        // line 146
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pencil.png"), "html", null, true);
        echo "\" alt=\"Retour\" height=\"30\">
                        </div>
                        <div>
                            <h3 class=\"ib hand petite\">Ecrire le script -></h3>
                        </div>
                    </a>
                    </div>
                </td>

            </table>


        </div>




    </td>
    <td style=\"vertical-align: top; padding-right: 3%\">


        <div class=\"largeur-totale padding-ten\">

            <h3 class=\"ib bord-droit script-voixoff\">Vos réponses :</h3>

            ";
        // line 171
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["reponses"]) ? $context["reponses"] : $this->getContext($context, "reponses")));
        foreach ($context['_seq'] as $context["key"] => $context["reponse"]) {
            // line 172
            echo "                <div class=\"id sub-txt-small grey\">
                      ";
            // line 173
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["reponse"], "question", array()), "question", array()), "html", null, true);
            echo "
                </div>

                <div class=\"id sub-txt-small script-voixoff\">
                    ";
            // line 177
            if ($this->getAttribute($context["reponse"], "reponse", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "reponse", array()), "html", null, true);
                echo "
                    ";
            } else {
                // line 178
                echo " Vous n'avez pas répondu
                    ";
            }
            // line 180
            echo "                </div>

            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['reponse'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 183
        echo "        </div>

    </td>

</table>
";
        
        $__internal_36e01ff451dc249936b40d5d9cd0c9617664c8fa0aba35a815e8c22ae1201545->leave($__internal_36e01ff451dc249936b40d5d9cd0c9617664c8fa0aba35a815e8c22ae1201545_prof);

    }

    public function getTemplateName()
    {
        return ":script:voixoff.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  315 => 183,  307 => 180,  303 => 178,  297 => 177,  290 => 173,  287 => 172,  283 => 171,  255 => 146,  249 => 143,  234 => 131,  228 => 128,  200 => 103,  187 => 93,  177 => 86,  169 => 81,  164 => 79,  152 => 74,  148 => 72,  145 => 71,  142 => 70,  139 => 69,  137 => 68,  127 => 61,  109 => 45,  103 => 44,  85 => 31,  78 => 27,  71 => 23,  64 => 19,  57 => 15,  50 => 11,  45 => 9,  41 => 7,  35 => 6,  11 => 3,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("

{% extends 'layout.html.twig' %}


 {% block ariane %}

     <div class=\"ariane grey\">
         <div class=\"ib sub-txt-small fine grey\">Projet en cours : </div><div class=\"ib fine lightgrey bord-droit\"> {{ projet.nomProjet }}</div>

         <a href=\"{{ path('projet_index', {'id':app.user.id}) }}\">
             <div class=\"ib fine\">PROJETS</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('projet_edit', {'id':app.user.id, 'projet': projet.id, 'script' : script.id }) }}\">
             <div class=\"ib fine petite\">Paramètres</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <a href=\"{{ path('script_orientation', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine\">SCRIPT</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('script_questions', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine petite\">Guide</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('script_voixoff', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine petite\">Voix-Off</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('scriptecriture_index', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine petite\">Ecriture</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <div class=\"ib fine\">STORYBOARD</div>
         <div class=\"ib fine\">></div>
         <div class=\"ib fine petite\">Ecriture</div>

     </div>

 {% endblock %}


{% block left %}


<table>

    <td style=\"width:65%; vertical-align: top; background-color: #e4e8e9;\">
        <div class=\"padding-ten\">

            <form>

                <table class=\"title-tab\">
                    <td class=\"padding-ten\"><h3 class=\"script-voixoff\">Rédigez le texte de la voix-off</h3></td>
                </table>


                <div class=\"largeur-totale\">
                    <label for=\"voixoffglobal\"></label>
                    <textarea style=\"width: 98%;\" placeholder=\"Rédigez votre voix-off...\" rows=\"24\" class=\"questionnaire\" name=\"voixoff\">{{ script.voixoffGlobal }}</textarea>
                </div>



                <div class=\"grey\">

                    {% set timing = script.count/2.5 %}
                    {%  set minround = timing/60 %}
                    {%  set min = minround|round(0, 'floor') %}
                    {%  set sec = timing%60 %}

                    <div class=\"ib\">
                        <div class=\"ib sub-txt-big\">{%  if script.count %}{{ script.count }}{% else %}0{% endif %}</div>
                        <div class=\"ib sub-txt-small bord-droit\">mots</div>
                    </div>
                    <div class=\"ib\">
                        <div class=\"ib sub-txt-small\">Durée estimée :</div>
                        <div class=\"ib sub-txt-big\">{{ min }}</div>
                        <div class=\"ib sub-txt-small\">min</div>
                        <div class=\"ib sub-txt-big\">{{ sec }}</div>
                        <div class=\"ib sub-txt-small bord-droit\">sec</div>
                    </div>

                    <div class=\"ib\">
                        <button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\" formmethod=\"post\" formaction=\"{{ path('script_voixoff_edit',{'id':app.user.id, 'projet': projet.id,'script': script.id})}}\">
                            <div class=\"ib\">
                            <table class=\"ib tab-buttons-petit shadow back-voixoff\">
                                <td>
                                    <div class=\"lightgrey\">Mettre à jour</div>
                                </td>
                                <td>
                                    <img src=\"{{ asset('images/refresh-button.png')}}\" alt=\"Enregistrer\" height=\"19\">
                                </td>
                            </table>
                            </div>
                            <div class=\"ib\">
                            <table class=\"ib tab-buttons-petit shadow back-voixoff\">
                                <td>
                                    <div class=\"lightgrey\">Enregistrer</div>
                                </td>
                                <td>
                                    <img src=\"{{ asset('images/save-file-option.png')}}\" alt=\"Enregistrer\" height=\"19\">
                                </td>
                            </table>
                    </div>
                        </button>



                    </div>

                </div>




            </form>





            <table class=\"largeur-totale padding-ten\">

                <td style=\"width:33%\" class=\"txt-center\">
                    <div class=\"script-voixoff-box1 shadow\">
                    <a href=\"{{ path('script_questions', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
                        <div class=\"ib\">

                            <img src=\"{{ asset('images/list.png')}}\" alt=\"Script\" height=\"30\">
                        </div>
                        <div>
                            <h3 class=\"ib hand petite\"><- Répondre aux questions</h3>
                        </div>
                   </a>
                    </div>
                </td>
                <td style=\"width:30%\"></td>

                <td style=\"width:33%\" class=\"txt-center\">
                    <div class=\"script-voixoff-box3 shadow\">
                        <a href=\"{{ path('scriptecriture_index', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">

                        <div class=\"ib\">
                            <img src=\"{{ asset('images/pencil.png')}}\" alt=\"Retour\" height=\"30\">
                        </div>
                        <div>
                            <h3 class=\"ib hand petite\">Ecrire le script -></h3>
                        </div>
                    </a>
                    </div>
                </td>

            </table>


        </div>




    </td>
    <td style=\"vertical-align: top; padding-right: 3%\">


        <div class=\"largeur-totale padding-ten\">

            <h3 class=\"ib bord-droit script-voixoff\">Vos réponses :</h3>

            {% for key,reponse in reponses %}
                <div class=\"id sub-txt-small grey\">
                      {{ reponse.question.question }}
                </div>

                <div class=\"id sub-txt-small script-voixoff\">
                    {% if reponse.reponse %}{{ reponse.reponse }}
                    {% else %} Vous n'avez pas répondu
                    {% endif %}
                </div>

            {% endfor %}
        </div>

    </td>

</table>
{% endblock %}


", ":script:voixoff.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/script/voixoff.html.twig");
    }
}
