<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_6603234c5e483320f93b459fbc32f341bc7303938724e33cc2bbad3a2aaf9d16 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3744f54c9b585471a8ef1957e5172fab76b29035670718b85b6cbafb8d865b51 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3744f54c9b585471a8ef1957e5172fab76b29035670718b85b6cbafb8d865b51->enter($__internal_3744f54c9b585471a8ef1957e5172fab76b29035670718b85b6cbafb8d865b51_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_3744f54c9b585471a8ef1957e5172fab76b29035670718b85b6cbafb8d865b51->leave($__internal_3744f54c9b585471a8ef1957e5172fab76b29035670718b85b6cbafb8d865b51_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/textarea_widget.html.php");
    }
}
