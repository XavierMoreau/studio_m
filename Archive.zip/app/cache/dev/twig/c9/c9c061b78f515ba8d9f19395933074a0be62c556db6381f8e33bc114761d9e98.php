<?php

/* FOSUserBundle:Group:list.html.twig */
class __TwigTemplate_5f5ebe5d615d598a4310459314743679ff56614d8779f3e19912ed291f073782 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Group:list.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_207133c1106ba3e9fe7a394c6ca03eb8d72b3cf22f3db0bc07c6d48385d082aa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_207133c1106ba3e9fe7a394c6ca03eb8d72b3cf22f3db0bc07c6d48385d082aa->enter($__internal_207133c1106ba3e9fe7a394c6ca03eb8d72b3cf22f3db0bc07c6d48385d082aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_207133c1106ba3e9fe7a394c6ca03eb8d72b3cf22f3db0bc07c6d48385d082aa->leave($__internal_207133c1106ba3e9fe7a394c6ca03eb8d72b3cf22f3db0bc07c6d48385d082aa_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_a7c134e456498105e05a5bd839dd4f199fc0232a60c7dc0b172fd5d6ccae5ffb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a7c134e456498105e05a5bd839dd4f199fc0232a60c7dc0b172fd5d6ccae5ffb->enter($__internal_a7c134e456498105e05a5bd839dd4f199fc0232a60c7dc0b172fd5d6ccae5ffb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Group/list_content.html.twig", "FOSUserBundle:Group:list.html.twig", 4)->display($context);
        
        $__internal_a7c134e456498105e05a5bd839dd4f199fc0232a60c7dc0b172fd5d6ccae5ffb->leave($__internal_a7c134e456498105e05a5bd839dd4f199fc0232a60c7dc0b172fd5d6ccae5ffb_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Group/list_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:list.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/friendsofsymfony/user-bundle/Resources/views/Group/list.html.twig");
    }
}
