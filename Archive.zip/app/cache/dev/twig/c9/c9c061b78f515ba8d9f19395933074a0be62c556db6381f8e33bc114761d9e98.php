<?php

/* FOSUserBundle:Group:list.html.twig */
class __TwigTemplate_5f5ebe5d615d598a4310459314743679ff56614d8779f3e19912ed291f073782 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:Group:list.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_476a7a161324730e7b137f20845025d025d9afc3350b36cbe7488e911dcab712 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_476a7a161324730e7b137f20845025d025d9afc3350b36cbe7488e911dcab712->enter($__internal_476a7a161324730e7b137f20845025d025d9afc3350b36cbe7488e911dcab712_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_476a7a161324730e7b137f20845025d025d9afc3350b36cbe7488e911dcab712->leave($__internal_476a7a161324730e7b137f20845025d025d9afc3350b36cbe7488e911dcab712_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_218a251057849be416652cb6eecf4845189980ac753b2d925832f64bb84a9146 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_218a251057849be416652cb6eecf4845189980ac753b2d925832f64bb84a9146->enter($__internal_218a251057849be416652cb6eecf4845189980ac753b2d925832f64bb84a9146_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Group/list_content.html.twig", "FOSUserBundle:Group:list.html.twig", 4)->display($context);
        
        $__internal_218a251057849be416652cb6eecf4845189980ac753b2d925832f64bb84a9146->leave($__internal_218a251057849be416652cb6eecf4845189980ac753b2d925832f64bb84a9146_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Group/list_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:list.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/friendsofsymfony/user-bundle/Resources/views/Group/list.html.twig");
    }
}
