<?php

/* :scriptecriture:new.html.twig */
class __TwigTemplate_aeb548bd1cbb5694b812ebaf31cf1ad7dac296a00983169e4045e9245c979da2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":scriptecriture:new.html.twig", 1);
        $this->blocks = array(
            'contentlarge' => array($this, 'block_contentlarge'),
            'aside' => array($this, 'block_aside'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c56adb32e27fa97246adc8e30fe0d00c9846f0cb0d282ac39444ffd2ae37070c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c56adb32e27fa97246adc8e30fe0d00c9846f0cb0d282ac39444ffd2ae37070c->enter($__internal_c56adb32e27fa97246adc8e30fe0d00c9846f0cb0d282ac39444ffd2ae37070c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":scriptecriture:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c56adb32e27fa97246adc8e30fe0d00c9846f0cb0d282ac39444ffd2ae37070c->leave($__internal_c56adb32e27fa97246adc8e30fe0d00c9846f0cb0d282ac39444ffd2ae37070c_prof);

    }

    // line 3
    public function block_contentlarge($context, array $blocks = array())
    {
        $__internal_b74f1ac323a9896e10ece71800015c1c0f21169d6f9f2a82d3e187494dd709db = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b74f1ac323a9896e10ece71800015c1c0f21169d6f9f2a82d3e187494dd709db->enter($__internal_b74f1ac323a9896e10ece71800015c1c0f21169d6f9f2a82d3e187494dd709db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contentlarge"));

        // line 4
        echo "
";
        // line 8
        echo "
    ";
        // line 10
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["reponses"]) ? $context["reponses"] : $this->getContext($context, "reponses")));
        foreach ($context['_seq'] as $context["key"] => $context["reponse"]) {
            // line 11
            echo "
    ";
            // line 13
            echo "    <form  method=\"post\" action=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()), "ecriture" => $this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "id", array()))), "html", null, true);
            echo "\">

        ";
            // line 16
            echo "        <input type=\"hidden\" name=\"0\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "id", array()), "html", null, true);
            echo "\">

<div style=\"width: 100%; border: solid 3px #34495e; border-radius: 10px\">


    <table style=\"width: 100%; background-color: #34495e;  font-weight: bold; text-align: center; color: white\">
    <td>Ligne de script n° ";
            // line 22
            echo twig_escape_filter($this->env, ($context["key"] + 1), "html", null, true);
            echo "</td>
    </table>
    <table class=\"table table-striped\">

        <thead class=\"tabhead scriptcolor\">
            <th>A la question :</th>
            <th>Vous avez répondu :</th>
            <th></th>
            <th></th>
        </thead>
        <tbody class=\"tabcells scriptcolor\">
            <td>";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["reponse"], "question", array()), "question", array()), "html", null, true);
            echo "</td>
            <td>";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "reponse", array()), "html", null, true);
            echo "</td>
            <td width=\"80\"><a href=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()))), "html", null, true);
            echo "\"><img class=\"imgflat\" src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/back.png"), "html", null, true);
            echo "\" alt=\"Retour\" height=\"40\"></a></td>
            <td width=\"100\"><a href=\"";
            // line 36
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()))), "html", null, true);
            echo "\"><h5 style=\"color: #d97077\">Retour aux questions</h5></a></td>
        </tbody>
    </table>
    <table class=\"table table-striped\">
        <thead>
            <th style=\"color: palevioletred; font-size: 20px\">Saisissez la voix-off ici : <img src=\"";
            // line 41
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/arrowpink.png"), "html", null, true);
            echo "\" width=\"60\"></th>
            <th style=\"color: #5BDB7F; font-size: 20px; text-align: right\"><img src=\"";
            // line 42
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/arrowgreen.png"), "html", null, true);
            echo "\" width=\"60\">Saisissez la description ici :</th>
            <th style=\"color: #4c8ab0; font-size: 20px; text-align: right\" colspan=\"2\">Et la durée ici : <img src=\"";
            // line 43
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/arrowblue.png"), "html", null, true);
            echo "\" width=\"40\"></th>
        </thead>

        <tbody>
        <tr>
            ";
            // line 49
            echo "            <td rowspan=\"2\"><label for=\"voixoff";
            echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "id", array()), "html", null, true);
            echo "\"></label>
                <textarea  rows=\"8\" class=\"form-control\" name=\"1\" >";
            // line 50
            if ($this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "voixoff", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "voixoff", array()), "html", null, true);
            }
            echo "</textarea></td>
            <td rowspan=\"2\"><label for=\"description";
            // line 51
            echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "id", array()), "html", null, true);
            echo "\"></label>
                <textarea  rows=\"8\" class=\"form-control\" name=\"2\" >";
            // line 52
            if ($this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "description", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "description", array()), "html", null, true);
            }
            echo "</textarea></td>
            <td width=\"100\"><label for=\"timeMin";
            // line 53
            echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "id", array()), "html", null, true);
            echo "\">Min : </label><br>
                <input type=\"number\" min=\"0\" max=\"59\" step=\"1\" class=\"form-control\" name=\"3\" value=\"";
            // line 54
            if ($this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "tempsForceMin", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "tempsForceMin", array()), "html", null, true);
            }
            echo "\"></td>
            <td width=\"100\"><label for=\"timeSec";
            // line 55
            echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "id", array()), "html", null, true);
            echo "\">Sec :</label><br>
                <input type=\"number\" min=\"0\" max=\"59\" step=\"1\" class=\"form-control\" name=\"4\" value=\"";
            // line 56
            if ($this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "tempsForceSec", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "tempsForceSec", array()), "html", null, true);
            }
            echo "\"></td>


        <tr>
             <td colspan=\"2\" style=\"text-align: center\">
                 <button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\">
                     <img class=\"imgflat\" src=\"";
            // line 62
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/save.png"), "html", null, true);
            echo "\" alt=\"Enregistrer\" height=\"40\"><h4 style=\"color: #ff8e31\">Enregistrer</h4></button>
             </td>

        </tr>

        </tbody>


    </table>


        </div>
        </form>



        <br>
        <br>

        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['reponse'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 82
        echo "<hr>


    <table style=\"width: 100%;\">
        <td style=\"width: 49%; text-align: center;\">

                <a href=\"";
        // line 88
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()))), "html", null, true);
        echo "\">
                    <img class=\"imgflat\" src=\"";
        // line 89
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/back.png"), "html", null, true);
        echo "\" alt=\"Retour\" height=\"70\"><h4 style=\"color: #d97077\">Retour</h4></a>


        </td>
        <td style=\"width: 49%; text-align: center;\">
            ";
        // line 95
        echo "
            ";
        // line 97
        echo "            ";
        $context["valid"] = 1;
        // line 98
        echo "
            ";
        // line 100
        echo "            ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["reponses"]) ? $context["reponses"] : $this->getContext($context, "reponses")));
        foreach ($context['_seq'] as $context["key"] => $context["reponse"]) {
            // line 101
            echo "                ";
            if (((isset($context["valid"]) ? $context["valid"] : $this->getContext($context, "valid")) == 0)) {
                // line 102
                echo "                    ";
                $context["valid"] = 0;
                // line 103
                echo "                ";
            } else {
                // line 104
                echo "                    ";
                if (($this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "voixoff", array()) && $this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "description", array()))) {
                    // line 105
                    echo "                        ";
                    $context["valid"] = 1;
                    // line 106
                    echo "                    ";
                } else {
                    // line 107
                    echo "                        ";
                    $context["valid"] = 0;
                    // line 108
                    echo "                    ";
                }
                // line 109
                echo "                ";
            }
            // line 110
            echo "            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['reponse'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 111
        echo "
            ";
        // line 113
        echo "            ";
        if (((isset($context["valid"]) ? $context["valid"] : $this->getContext($context, "valid")) == 0)) {
            // line 114
            echo "
               <div style=\"position: relative;\">
                <img style=\"opacity: 0.5\" class=\"imgflat\" src=\"";
            // line 116
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pen.png"), "html", null, true);
            echo "\" alt=\"Enregistrer\" height=\"70\"><h4 style=\"color: #34495e;opacity: 0.5;\">Continuer</h4>
               <h4 style=\"position: absolute;top : 30px; width: 100%; color: #34495e\">Remplissez tous les champs</h4>
               </div>
                ";
            // line 120
            echo "            ";
        } else {
            // line 121
            echo "
                <a href=\"";
            // line 122
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_valid", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
            echo "\">
                    <img class=\"imgflat\" src=\"";
            // line 123
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pen.png"), "html", null, true);
            echo "\" alt=\"Enregistrer\" height=\"70\"><h4 style=\"color: #34495e\">Continuer</h4></a>

            ";
        }
        // line 126
        echo "        </td>

    </table>




";
        
        $__internal_b74f1ac323a9896e10ece71800015c1c0f21169d6f9f2a82d3e187494dd709db->leave($__internal_b74f1ac323a9896e10ece71800015c1c0f21169d6f9f2a82d3e187494dd709db_prof);

    }

    // line 138
    public function block_aside($context, array $blocks = array())
    {
        $__internal_aa5b477f06395ffced83cc31c4996bca752546bb3651fe7a9bec997b561aad17 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aa5b477f06395ffced83cc31c4996bca752546bb3651fe7a9bec997b561aad17->enter($__internal_aa5b477f06395ffced83cc31c4996bca752546bb3651fe7a9bec997b561aad17_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "aside"));

        // line 139
        echo "




    ";
        // line 144
        $context["min"] = 0;
        // line 145
        echo "    ";
        $context["sec"] = 0;
        // line 146
        echo "
    ";
        // line 148
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["reponses"]) ? $context["reponses"] : $this->getContext($context, "reponses")));
        foreach ($context['_seq'] as $context["key"] => $context["reponse"]) {
            // line 149
            echo "
        ";
            // line 150
            $context["sec"] = ((isset($context["sec"]) ? $context["sec"] : $this->getContext($context, "sec")) + $this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "tempsForceSec", array()));
            // line 151
            echo "        ";
            if (((isset($context["sec"]) ? $context["sec"] : $this->getContext($context, "sec")) > 59)) {
                // line 152
                echo "            ";
                $context["min"] = ((isset($context["min"]) ? $context["min"] : $this->getContext($context, "min")) + 1);
                // line 153
                echo "            ";
                $context["sec"] = 0;
                // line 154
                echo "        ";
            }
            // line 155
            echo "        ";
            $context["min"] = ((isset($context["min"]) ? $context["min"] : $this->getContext($context, "min")) + $this->getAttribute($this->getAttribute($context["reponse"], "scriptEcriture", array()), "tempsForceMin", array()));
            // line 156
            echo "
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['reponse'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 158
        echo "

    <div style=\"width: 100%; margin-left: 15px; text-align: center\">


        <div style=\"width: 100%; text-align: center\">
            <img class=\"imgflat\" src=\"";
        // line 164
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pen.png"), "html", null, true);
        echo "\" alt=\"Script\" height=\"100\"><h3 style=\"color: #34495e\">Script</h3>
        </div>
<br>
<br>
<br>

        <table style=\"width: 85%; background-color: #d3d3d3\">
            <thead>
            <tr>
                <th style=\"width: 20%;\"></th>
                <th style=\"text-align: center\" colspan=\"4\">Durée totale :</th>
                <th style=\"width: 20%;\"></th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td></td>
                <td><h1>";
        // line 181
        echo twig_escape_filter($this->env, (isset($context["min"]) ? $context["min"] : $this->getContext($context, "min")), "html", null, true);
        echo "</h1></td>
                <td><h5> min</h5></td>
                <td><h1>";
        // line 183
        echo twig_escape_filter($this->env, (isset($context["sec"]) ? $context["sec"] : $this->getContext($context, "sec")), "html", null, true);
        echo "</h1></td>
                <td><h5> sec</h5></td>
                <td></td>
            </tr>
            </tbody>
        </table>
        
    </div>


";
        
        $__internal_aa5b477f06395ffced83cc31c4996bca752546bb3651fe7a9bec997b561aad17->leave($__internal_aa5b477f06395ffced83cc31c4996bca752546bb3651fe7a9bec997b561aad17_prof);

    }

    public function getTemplateName()
    {
        return ":scriptecriture:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  394 => 183,  389 => 181,  369 => 164,  361 => 158,  354 => 156,  351 => 155,  348 => 154,  345 => 153,  342 => 152,  339 => 151,  337 => 150,  334 => 149,  329 => 148,  326 => 146,  323 => 145,  321 => 144,  314 => 139,  308 => 138,  294 => 126,  288 => 123,  284 => 122,  281 => 121,  278 => 120,  272 => 116,  268 => 114,  265 => 113,  262 => 111,  256 => 110,  253 => 109,  250 => 108,  247 => 107,  244 => 106,  241 => 105,  238 => 104,  235 => 103,  232 => 102,  229 => 101,  224 => 100,  221 => 98,  218 => 97,  215 => 95,  207 => 89,  203 => 88,  195 => 82,  169 => 62,  158 => 56,  154 => 55,  148 => 54,  144 => 53,  138 => 52,  134 => 51,  128 => 50,  123 => 49,  115 => 43,  111 => 42,  107 => 41,  99 => 36,  93 => 35,  89 => 34,  85 => 33,  71 => 22,  61 => 16,  55 => 13,  52 => 11,  47 => 10,  44 => 8,  41 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block contentlarge %}

{#{{ dump(script) }}#}
{#{{ dump(reponses) }}#}
{#{{ dump(ecritures) }}#}

    {#Pour chaque réponse au questionnaire du script #}
    {% for key,reponse in reponses %}

    {#On affiche le formulaire d'édition#}
    <form  method=\"post\" action=\"{{ path('scriptecriture_edit',{'id':app.user.id, 'projet': projet.id, 'script': script.id, 'ecriture': reponse.scriptEcriture.id })}}\">

        {#On renvoie l'id de la réponse en caché#}
        <input type=\"hidden\" name=\"0\" value=\"{{ reponse.id }}\">

<div style=\"width: 100%; border: solid 3px #34495e; border-radius: 10px\">


    <table style=\"width: 100%; background-color: #34495e;  font-weight: bold; text-align: center; color: white\">
    <td>Ligne de script n° {{ key + 1 }}</td>
    </table>
    <table class=\"table table-striped\">

        <thead class=\"tabhead scriptcolor\">
            <th>A la question :</th>
            <th>Vous avez répondu :</th>
            <th></th>
            <th></th>
        </thead>
        <tbody class=\"tabcells scriptcolor\">
            <td>{{ reponse.question.question }}</td>
            <td>{{ reponse.reponse }}</td>
            <td width=\"80\"><a href=\"{{ path('script_questions', {'id':app.user.id, 'projet': projet.id}) }}\"><img class=\"imgflat\" src=\"{{ asset('images/back.png')}}\" alt=\"Retour\" height=\"40\"></a></td>
            <td width=\"100\"><a href=\"{{ path('script_questions', {'id':app.user.id, 'projet': projet.id}) }}\"><h5 style=\"color: #d97077\">Retour aux questions</h5></a></td>
        </tbody>
    </table>
    <table class=\"table table-striped\">
        <thead>
            <th style=\"color: palevioletred; font-size: 20px\">Saisissez la voix-off ici : <img src=\"{{ asset('images/arrowpink.png')}}\" width=\"60\"></th>
            <th style=\"color: #5BDB7F; font-size: 20px; text-align: right\"><img src=\"{{ asset('images/arrowgreen.png')}}\" width=\"60\">Saisissez la description ici :</th>
            <th style=\"color: #4c8ab0; font-size: 20px; text-align: right\" colspan=\"2\">Et la durée ici : <img src=\"{{ asset('images/arrowblue.png')}}\" width=\"40\"></th>
        </thead>

        <tbody>
        <tr>
            {#Si une saisie est existante on affiche les infos#}
            <td rowspan=\"2\"><label for=\"voixoff{{ reponse.id }}\"></label>
                <textarea  rows=\"8\" class=\"form-control\" name=\"1\" >{% if reponse.scriptEcriture.voixoff %}{{ reponse.scriptEcriture.voixoff }}{% endif %}</textarea></td>
            <td rowspan=\"2\"><label for=\"description{{ reponse.id }}\"></label>
                <textarea  rows=\"8\" class=\"form-control\" name=\"2\" >{% if reponse.scriptEcriture.description %}{{ reponse.scriptEcriture.description }}{% endif %}</textarea></td>
            <td width=\"100\"><label for=\"timeMin{{ reponse.id }}\">Min : </label><br>
                <input type=\"number\" min=\"0\" max=\"59\" step=\"1\" class=\"form-control\" name=\"3\" value=\"{% if reponse.scriptEcriture.tempsForceMin %}{{ reponse.scriptEcriture.tempsForceMin }}{% endif %}\"></td>
            <td width=\"100\"><label for=\"timeSec{{ reponse.id }}\">Sec :</label><br>
                <input type=\"number\" min=\"0\" max=\"59\" step=\"1\" class=\"form-control\" name=\"4\" value=\"{% if reponse.scriptEcriture.tempsForceSec %}{{ reponse.scriptEcriture.tempsForceSec }}{% endif %}\"></td>


        <tr>
             <td colspan=\"2\" style=\"text-align: center\">
                 <button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\">
                     <img class=\"imgflat\" src=\"{{ asset('images/save.png')}}\" alt=\"Enregistrer\" height=\"40\"><h4 style=\"color: #ff8e31\">Enregistrer</h4></button>
             </td>

        </tr>

        </tbody>


    </table>


        </div>
        </form>



        <br>
        <br>

        {% endfor %}
<hr>


    <table style=\"width: 100%;\">
        <td style=\"width: 49%; text-align: center;\">

                <a href=\"{{ path('script_questions', {'id':app.user.id, 'projet': projet.id})  }}\">
                    <img class=\"imgflat\" src=\"{{ asset('images/back.png')}}\" alt=\"Retour\" height=\"70\"><h4 style=\"color: #d97077\">Retour</h4></a>


        </td>
        <td style=\"width: 49%; text-align: center;\">
            {#controle si toutes les réponses sont bien saisies avant d'autoriser la validation#}

            {#initialisation de la valeur validation à 1 par défault#}
            {% set valid = 1 %}

            {#Vérification si les résponses sont saisies, si oui la validation passe à 1 sinon elle reste à 0#}
            {% for key,reponse in reponses %}
                {% if valid == 0 %}
                    {% set valid = 0 %}
                {% else %}
                    {% if reponse.scriptEcriture.voixoff and reponse.scriptEcriture.description %}
                        {% set valid = 1 %}
                    {% else %}
                        {% set valid = 0 %}
                    {% endif %}
                {% endif %}
            {% endfor %}

            {#tant que la validation est à 0 on n'affiche le lien qu'en grisé#}
            {% if valid == 0 %}

               <div style=\"position: relative;\">
                <img style=\"opacity: 0.5\" class=\"imgflat\" src=\"{{ asset('images/pen.png')}}\" alt=\"Enregistrer\" height=\"70\"><h4 style=\"color: #34495e;opacity: 0.5;\">Continuer</h4>
               <h4 style=\"position: absolute;top : 30px; width: 100%; color: #34495e\">Remplissez tous les champs</h4>
               </div>
                {#sinon on l'active#}
            {% else %}

                <a href=\"{{ path('script_valid', {'id':app.user.id, 'projet': projet.id, 'script': script.id}) }}\">
                    <img class=\"imgflat\" src=\"{{ asset('images/pen.png')}}\" alt=\"Enregistrer\" height=\"70\"><h4 style=\"color: #34495e\">Continuer</h4></a>

            {% endif %}
        </td>

    </table>




{% endblock %}




{% block aside %}





    {% set min = 0 %}
    {% set sec = 0 %}

    {#Vérification si les résponses sont saisies, si oui la validation passe à 1 sinon elle reste à 0#}
    {% for key,reponse in reponses %}

        {% set sec = sec + reponse.scriptEcriture.tempsForceSec %}
        {% if sec > 59 %}
            {% set min = min +1 %}
            {% set sec = 0 %}
        {% endif %}
        {% set min = min + reponse.scriptEcriture.tempsForceMin %}

    {% endfor %}


    <div style=\"width: 100%; margin-left: 15px; text-align: center\">


        <div style=\"width: 100%; text-align: center\">
            <img class=\"imgflat\" src=\"{{ asset('images/pen.png')}}\" alt=\"Script\" height=\"100\"><h3 style=\"color: #34495e\">Script</h3>
        </div>
<br>
<br>
<br>

        <table style=\"width: 85%; background-color: #d3d3d3\">
            <thead>
            <tr>
                <th style=\"width: 20%;\"></th>
                <th style=\"text-align: center\" colspan=\"4\">Durée totale :</th>
                <th style=\"width: 20%;\"></th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td></td>
                <td><h1>{{ min }}</h1></td>
                <td><h5> min</h5></td>
                <td><h1>{{ sec }}</h1></td>
                <td><h5> sec</h5></td>
                <td></td>
            </tr>
            </tbody>
        </table>
        
    </div>


{% endblock %}", ":scriptecriture:new.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/scriptecriture/new.html.twig");
    }
}
