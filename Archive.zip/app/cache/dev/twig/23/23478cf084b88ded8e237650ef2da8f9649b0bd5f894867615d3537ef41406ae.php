<?php

/* FOSUserBundle:ChangePassword:change_password.html.twig */
class __TwigTemplate_d5f2140e021e59c6158609d815d5da212e77e74df88e993e0eee48342c084bbd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "FOSUserBundle:ChangePassword:change_password.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2fbd00c1444a26fa8aaadc436a9e9ee24fafd32d85498bd740d12ea425574bd7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2fbd00c1444a26fa8aaadc436a9e9ee24fafd32d85498bd740d12ea425574bd7->enter($__internal_2fbd00c1444a26fa8aaadc436a9e9ee24fafd32d85498bd740d12ea425574bd7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:ChangePassword:change_password.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2fbd00c1444a26fa8aaadc436a9e9ee24fafd32d85498bd740d12ea425574bd7->leave($__internal_2fbd00c1444a26fa8aaadc436a9e9ee24fafd32d85498bd740d12ea425574bd7_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_6760627c499d2678f23b12e7a9c6de2865090ccf0ea33d9c08daed48fd2f6105 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6760627c499d2678f23b12e7a9c6de2865090ccf0ea33d9c08daed48fd2f6105->enter($__internal_6760627c499d2678f23b12e7a9c6de2865090ccf0ea33d9c08daed48fd2f6105_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/ChangePassword/change_password_content.html.twig", "FOSUserBundle:ChangePassword:change_password.html.twig", 4)->display($context);
        
        $__internal_6760627c499d2678f23b12e7a9c6de2865090ccf0ea33d9c08daed48fd2f6105->leave($__internal_6760627c499d2678f23b12e7a9c6de2865090ccf0ea33d9c08daed48fd2f6105_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:ChangePassword:change_password.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/ChangePassword/change_password_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:ChangePassword:change_password.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/friendsofsymfony/user-bundle/Resources/views/ChangePassword/change_password.html.twig");
    }
}
