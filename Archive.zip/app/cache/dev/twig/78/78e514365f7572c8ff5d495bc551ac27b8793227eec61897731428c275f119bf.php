<?php

/* :script:print.html.twig */
class __TwigTemplate_bbbac43434ff96f2ba957611ba88fc76d2045287cc0e8b970a5b475e2583c008 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6221c83e6c97389208b30e9b415b9672b571764f35aee679c103a716a7b80215 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6221c83e6c97389208b30e9b415b9672b571764f35aee679c103a716a7b80215->enter($__internal_6221c83e6c97389208b30e9b415b9672b571764f35aee679c103a716a7b80215_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":script:print.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"fr\">
<head>
    <meta charset=\"UTF-8\">
    <title>
        Bump";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        // line 7
        echo "    </title>
    <link href=\"https://fonts.googleapis.com/css?family=News+Cycle\" rel=\"stylesheet\">
    <link rel=\"stylesheet\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/appli/css/main.css"), "html", null, true);
        echo "\" type=\"text/css\" media=\"all\" />
    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\" crossorigin=\"anonymous\">
    <link rel=\"icon\" type=\"image/png\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/favicon.png"), "html", null, true);
        echo "\">
</head>
<body class=\"print\">

<div class=\"print-fond\">

<h4 class=\"ib title-tab projet\">Votre projet : ";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "nomProjet", array()), "html", null, true);
        echo "</h4>


<div class=\"ib\">
    <div class=\"ib sub-txt-small grey\">
        Projet créé par
    </div>
    <div class=\"ib enregistrer\">
        ";
        // line 25
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "utilisateur", array()), "prenom", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "utilisateur", array()), "nom", array()), "html", null, true);
        echo "
    </div>
</div>

<div class=\"ib\">
    <div class=\"ib sub-txt-small grey\">
        le
    </div>
    <div class=\"ib enregistrer\">
        ";
        // line 34
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "dateCreation", array()), "date", array()), "d/m/Y"), "html", null, true);
        echo "
    </div>
</div>

<div>
    <div class=\"ib sub-txt-small grey\">
        Supports :
    </div>
        ";
        // line 42
        $context["arraySupport"] = $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "support", array()), "getValues", array());
        // line 43
        echo "        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["arraySupport"]) ? $context["arraySupport"] : $this->getContext($context, "arraySupport")));
        foreach ($context['_seq'] as $context["_key"] => $context["support"]) {
            // line 44
            echo "            <div class=\"ib enregistrer bord-droit\">
                ";
            // line 45
            echo twig_escape_filter($this->env, $this->getAttribute($context["support"], "supportType", array()), "html", null, true);
            echo "
            </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['support'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 48
        echo "</div>
<div>
    <div class=\"ib sub-txt-small grey\">
        Diffusion :
    </div>
        ";
        // line 53
        $context["arrayDiffusion"] = $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "diffusion", array()), "getValues", array());
        // line 54
        echo "        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["arrayDiffusion"]) ? $context["arrayDiffusion"] : $this->getContext($context, "arrayDiffusion")));
        foreach ($context['_seq'] as $context["_key"] => $context["diffusion"]) {
            // line 55
            echo "    <div class=\"ib enregistrer bord-droit\">
                ";
            // line 56
            echo twig_escape_filter($this->env, $this->getAttribute($context["diffusion"], "diffusionType", array()), "html", null, true);
            echo "
    </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['diffusion'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 59
        echo "</div>
<div>
    <div class=\"ib sub-txt-small grey\">
        Utilisation :
    </div>
    ";
        // line 64
        $context["arrayUtilisation"] = $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "utilisation", array()), "getValues", array());
        // line 65
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["arrayUtilisation"]) ? $context["arrayUtilisation"] : $this->getContext($context, "arrayUtilisation")));
        foreach ($context['_seq'] as $context["_key"] => $context["utilisation"]) {
            // line 66
            echo "    <div class=\"ib enregistrer bord-droit\">
            ";
            // line 67
            echo twig_escape_filter($this->env, $this->getAttribute($context["utilisation"], "utilisationType", array()), "html", null, true);
            echo "
    </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['utilisation'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 70
        echo "</div>

<div class=\"ib\">
    <div class=\"ib sub-txt-small grey\">
        Diffusion prévue à partir du
    </div>
    <div class=\"ib enregistrer\">
        ";
        // line 77
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "dateDiffusion", array()), "date", array()), "d/m/Y"), "html", null, true);
        echo "
    </div>
</div>
<div class=\"ib\">
    <div class=\"ib sub-txt-small grey\">
        pour
    </div>
    <div class=\"ib enregistrer\">
        ";
        // line 85
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "tempsDiffusion", array()), "html", null, true);
        echo " an(s).
    </div>
</div>



<div class=\"title-tab\"></div>

<h4 class=\"ib title-tab script-questions\">Vos réponses :</h4>
";
        // line 94
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["reponses"]) ? $context["reponses"] : $this->getContext($context, "reponses")));
        foreach ($context['_seq'] as $context["key"] => $context["reponse"]) {
            // line 95
            echo "


<div class=\"id sub-txt-small reponses grey\">
    ";
            // line 99
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["reponse"], "question", array()), "question", array()), "html", null, true);
            echo "
</div>



<div class=\"id enregistrer reponses\">
    ";
            // line 105
            echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "reponse", array()), "html", null, true);
            echo "
</div>

";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['reponse'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 109
        echo "
<div class=\"title-tab\"></div>



<h4 class=\"ib title-tab script-voixoff\">Votre voix-off :</h4>



";
        // line 118
        $context["text"] = twig_split_filter($this->env, $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "voixoffGlobal", array()), "
");
        // line 119
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["text"]) ? $context["text"] : $this->getContext($context, "text")));
        foreach ($context['_seq'] as $context["_key"] => $context["paragraph"]) {
            // line 120
            echo "        <p>";
            echo twig_escape_filter($this->env, $context["paragraph"], "html", null, true);
            echo "</p>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['paragraph'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 122
        echo "

";
        // line 124
        $context["timing"] = ($this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "count", array()) / 2.5);
        // line 125
        $context["minround"] = ((isset($context["timing"]) ? $context["timing"] : $this->getContext($context, "timing")) / 60);
        // line 126
        $context["minvo"] = twig_round((isset($context["minround"]) ? $context["minround"] : $this->getContext($context, "minround")), 0, "floor");
        // line 127
        $context["secvo"] = ((isset($context["timing"]) ? $context["timing"] : $this->getContext($context, "timing")) % 60);
        // line 128
        echo "
<div class=\"grey\">
    <div class=\"ib padding-ten sub-txt-big\">";
        // line 130
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "count", array()), "html", null, true);
        echo "</div>
    <div class=\"ib sub-txt-small bord-droit\">mots</div>

    <div class=\"ib sub-txt-small grey\">Durée estimée de la voix-off :</div>
    <div class=\"ib sub-txt-big grey\">";
        // line 134
        echo twig_escape_filter($this->env, (isset($context["minvo"]) ? $context["minvo"] : $this->getContext($context, "minvo")), "html", null, true);
        echo "</div>
    <div class=\"ib sub-txt-small grey\">min</div>
    <div class=\"ib sub-txt-big grey\">";
        // line 136
        echo twig_escape_filter($this->env, (isset($context["secvo"]) ? $context["secvo"] : $this->getContext($context, "secvo")), "html", null, true);
        echo "</div>
    <div class=\"ib sub-txt-small grey\">sec</div>
</div>

<div class=\"title-tab\"></div>

    ";
        // line 142
        $context["mintotal"] = 0;
        // line 143
        echo "    ";
        $context["sectotal"] = 0;
        // line 144
        echo "


    ";
        // line 148
        echo "
<h4 class=\"ib title-tab script\">Votre script :</h4>

        ";
        // line 151
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["ecritures"]) ? $context["ecritures"] : $this->getContext($context, "ecritures")));
        foreach ($context['_seq'] as $context["key"] => $context["ecriture"]) {
            // line 152
            echo "
            ";
            // line 154
            echo "

            <table class=\"title-txt-petit script\">
                <td><h5>Ligne de script n° ";
            // line 157
            echo twig_escape_filter($this->env, ($context["key"] + 1), "html", null, true);
            echo "</h5></td>
            </table>
            <div class=\"largeur-totale padding-ten\">
                <div class=\"sub-txt-small grey\">Description</div>
                <div>";
            // line 161
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "description", array()), "html", null, true);
            echo "</div>
            </div>
            <div class=\"largeur-totale padding-ten\">
                <div class=\"sub-txt-small grey\">Voix-off</div>
                <div>";
            // line 165
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "voixoff", array()), "html", null, true);
            echo " </div>
            </div>

            <div class=\"grey\">
                ";
            // line 169
            $context["timing"] = ($this->getAttribute($context["ecriture"], "count", array()) / 2.5);
            // line 170
            echo "                ";
            $context["minround"] = ((isset($context["timing"]) ? $context["timing"] : $this->getContext($context, "timing")) / 60);
            // line 171
            echo "                ";
            $context["min"] = twig_round((isset($context["minround"]) ? $context["minround"] : $this->getContext($context, "minround")), 0, "floor");
            // line 172
            echo "                ";
            $context["sec"] = ((isset($context["timing"]) ? $context["timing"] : $this->getContext($context, "timing")) % 60);
            // line 173
            echo "                <div class=\"ib\">
                    <div class=\"ib padding-ten sub-txt-big\">";
            // line 174
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "count", array()), "html", null, true);
            echo "</div>
                    <div class=\"ib sub-txt-small bord-droit\">mots</div>
                </div>
                <div class=\"ib\">
                    <div class=\"ib sub-txt-small\">Durée estimée :</div>
                    <div class=\"ib sub-txt-big\">";
            // line 179
            echo twig_escape_filter($this->env, (isset($context["min"]) ? $context["min"] : $this->getContext($context, "min")), "html", null, true);
            echo "</div>
                    <div class=\"ib sub-txt-small\">min</div>
                    <div class=\"ib sub-txt-big\">";
            // line 181
            echo twig_escape_filter($this->env, (isset($context["sec"]) ? $context["sec"] : $this->getContext($context, "sec")), "html", null, true);
            echo "</div>
                    <div class=\"ib sub-txt-small bord-droit\">sec</div>
                </div>



                ";
            // line 187
            if (($this->getAttribute($context["ecriture"], "tempsForceMin", array()) || $this->getAttribute($context["ecriture"], "tempsForceSec", array()))) {
                // line 188
                echo "                    <div class=\"ib\">
                        <div class=\"ib sub-txt-small\">Durée forcée :</div>
                        <div class=\"ib sub-txt-big\">";
                // line 190
                echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "tempsForceMin", array()), "html", null, true);
                echo "</div>
                        <div class=\"ib sub-txt-small\"> min</div>
                        <div class=\"ib sub-txt-big\">";
                // line 192
                echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "tempsForceSec", array()), "html", null, true);
                echo "</div>
                        <div class=\"ib sub-txt-small bord-droit\"> sec</div>
                    </div>

                    ";
                // line 196
                $context["mintotal"] = ((isset($context["mintotal"]) ? $context["mintotal"] : $this->getContext($context, "mintotal")) + $this->getAttribute($context["ecriture"], "tempsForceMin", array()));
                // line 197
                echo "                    ";
                $context["sectotal"] = ((isset($context["sectotal"]) ? $context["sectotal"] : $this->getContext($context, "sectotal")) + $this->getAttribute($context["ecriture"], "tempsForceSec", array()));
                // line 198
                echo "                    ";
                if (((isset($context["sectotal"]) ? $context["sectotal"] : $this->getContext($context, "sectotal")) > 59)) {
                    // line 199
                    echo "                        ";
                    $context["mintotal"] = ((isset($context["mintotal"]) ? $context["mintotal"] : $this->getContext($context, "mintotal")) + 1);
                    // line 200
                    echo "                        ";
                    $context["sectotal"] = ((isset($context["sectotal"]) ? $context["sectotal"] : $this->getContext($context, "sectotal")) - 60);
                    // line 201
                    echo "                    ";
                }
                // line 202
                echo "                ";
            } else {
                // line 203
                echo "                    ";
                $context["mintotal"] = ((isset($context["mintotal"]) ? $context["mintotal"] : $this->getContext($context, "mintotal")) + (isset($context["min"]) ? $context["min"] : $this->getContext($context, "min")));
                // line 204
                echo "                    ";
                $context["sectotal"] = ((isset($context["sectotal"]) ? $context["sectotal"] : $this->getContext($context, "sectotal")) + (isset($context["sec"]) ? $context["sec"] : $this->getContext($context, "sec")));
                // line 205
                echo "                    ";
                if (((isset($context["sectotal"]) ? $context["sectotal"] : $this->getContext($context, "sectotal")) > 59)) {
                    // line 206
                    echo "                        ";
                    $context["mintotal"] = ((isset($context["mintotal"]) ? $context["mintotal"] : $this->getContext($context, "mintotal")) + 1);
                    // line 207
                    echo "                        ";
                    $context["sectotal"] = ((isset($context["sectotal"]) ? $context["sectotal"] : $this->getContext($context, "sectotal")) - 60);
                    // line 208
                    echo "                    ";
                }
                // line 209
                echo "                ";
            }
            // line 210
            echo "

                <div class=\"ib\">
                    <div class=\"ib sub-txt-small\">Durée depuis le début :</div>
                    <div class=\"ib sub-txt-big\">";
            // line 214
            echo twig_escape_filter($this->env, (isset($context["mintotal"]) ? $context["mintotal"] : $this->getContext($context, "mintotal")), "html", null, true);
            echo "</div>
                    <div class=\"ib sub-txt-small\">min</div>
                    <div class=\"ib sub-txt-big\">";
            // line 216
            echo twig_escape_filter($this->env, (isset($context["sectotal"]) ? $context["sectotal"] : $this->getContext($context, "sectotal")), "html", null, true);
            echo "</div>
                    <div class=\"ib sub-txt-small bord-droit\">sec</div>
                </div>


            </div>

            <div class=\"title-tab\"></div>
            <br>




        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['ecriture'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 230
        echo "
</div>
</body>



</html>";
        
        $__internal_6221c83e6c97389208b30e9b415b9672b571764f35aee679c103a716a7b80215->leave($__internal_6221c83e6c97389208b30e9b415b9672b571764f35aee679c103a716a7b80215_prof);

    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        $__internal_9ae988c03fd6617d57f2e5a510a9f2b7840ec2265af9e240f8da9bf1b1ac8c2a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9ae988c03fd6617d57f2e5a510a9f2b7840ec2265af9e240f8da9bf1b1ac8c2a->enter($__internal_9ae988c03fd6617d57f2e5a510a9f2b7840ec2265af9e240f8da9bf1b1ac8c2a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_9ae988c03fd6617d57f2e5a510a9f2b7840ec2265af9e240f8da9bf1b1ac8c2a->leave($__internal_9ae988c03fd6617d57f2e5a510a9f2b7840ec2265af9e240f8da9bf1b1ac8c2a_prof);

    }

    public function getTemplateName()
    {
        return ":script:print.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  470 => 6,  457 => 230,  437 => 216,  432 => 214,  426 => 210,  423 => 209,  420 => 208,  417 => 207,  414 => 206,  411 => 205,  408 => 204,  405 => 203,  402 => 202,  399 => 201,  396 => 200,  393 => 199,  390 => 198,  387 => 197,  385 => 196,  378 => 192,  373 => 190,  369 => 188,  367 => 187,  358 => 181,  353 => 179,  345 => 174,  342 => 173,  339 => 172,  336 => 171,  333 => 170,  331 => 169,  324 => 165,  317 => 161,  310 => 157,  305 => 154,  302 => 152,  298 => 151,  293 => 148,  288 => 144,  285 => 143,  283 => 142,  274 => 136,  269 => 134,  262 => 130,  258 => 128,  256 => 127,  254 => 126,  252 => 125,  250 => 124,  246 => 122,  237 => 120,  232 => 119,  229 => 118,  218 => 109,  208 => 105,  199 => 99,  193 => 95,  189 => 94,  177 => 85,  166 => 77,  157 => 70,  148 => 67,  145 => 66,  140 => 65,  138 => 64,  131 => 59,  122 => 56,  119 => 55,  114 => 54,  112 => 53,  105 => 48,  96 => 45,  93 => 44,  88 => 43,  86 => 42,  75 => 34,  61 => 25,  50 => 17,  41 => 11,  36 => 9,  32 => 7,  30 => 6,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"fr\">
<head>
    <meta charset=\"UTF-8\">
    <title>
        Bump{% block title %}{% endblock %}
    </title>
    <link href=\"https://fonts.googleapis.com/css?family=News+Cycle\" rel=\"stylesheet\">
    <link rel=\"stylesheet\" href=\"{{ asset('bundles/appli/css/main.css') }}\" type=\"text/css\" media=\"all\" />
    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\" crossorigin=\"anonymous\">
    <link rel=\"icon\" type=\"image/png\" href=\"{{ asset('images/favicon.png')}}\">
</head>
<body class=\"print\">

<div class=\"print-fond\">

<h4 class=\"ib title-tab projet\">Votre projet : {{ projet.nomProjet }}</h4>


<div class=\"ib\">
    <div class=\"ib sub-txt-small grey\">
        Projet créé par
    </div>
    <div class=\"ib enregistrer\">
        {{ projet.utilisateur.prenom }} {{ projet.utilisateur.nom}}
    </div>
</div>

<div class=\"ib\">
    <div class=\"ib sub-txt-small grey\">
        le
    </div>
    <div class=\"ib enregistrer\">
        {{ projet.dateCreation.date|date('d/m/Y') }}
    </div>
</div>

<div>
    <div class=\"ib sub-txt-small grey\">
        Supports :
    </div>
        {% set arraySupport = projet.support.getValues %}
        {% for support in arraySupport %}
            <div class=\"ib enregistrer bord-droit\">
                {{ support.supportType }}
            </div>
        {% endfor %}
</div>
<div>
    <div class=\"ib sub-txt-small grey\">
        Diffusion :
    </div>
        {% set arrayDiffusion = projet.diffusion.getValues %}
        {% for diffusion in arrayDiffusion %}
    <div class=\"ib enregistrer bord-droit\">
                {{ diffusion.diffusionType }}
    </div>
        {% endfor %}
</div>
<div>
    <div class=\"ib sub-txt-small grey\">
        Utilisation :
    </div>
    {% set arrayUtilisation = projet.utilisation.getValues %}
    {% for utilisation in arrayUtilisation %}
    <div class=\"ib enregistrer bord-droit\">
            {{ utilisation.utilisationType }}
    </div>
    {% endfor %}
</div>

<div class=\"ib\">
    <div class=\"ib sub-txt-small grey\">
        Diffusion prévue à partir du
    </div>
    <div class=\"ib enregistrer\">
        {{ projet.dateDiffusion.date|date('d/m/Y') }}
    </div>
</div>
<div class=\"ib\">
    <div class=\"ib sub-txt-small grey\">
        pour
    </div>
    <div class=\"ib enregistrer\">
        {{ projet.tempsDiffusion }} an(s).
    </div>
</div>



<div class=\"title-tab\"></div>

<h4 class=\"ib title-tab script-questions\">Vos réponses :</h4>
{% for key,reponse in reponses %}



<div class=\"id sub-txt-small reponses grey\">
    {{ reponse.question.question }}
</div>



<div class=\"id enregistrer reponses\">
    {{ reponse.reponse }}
</div>

{% endfor %}

<div class=\"title-tab\"></div>



<h4 class=\"ib title-tab script-voixoff\">Votre voix-off :</h4>



{% set text = script.voixoffGlobal|split('\\n') %}
    {% for paragraph in text %}
        <p>{{ paragraph }}</p>
    {% endfor %}


{% set timing = script.count/2.5 %}
{%  set minround = timing/60 %}
{%  set minvo = minround|round(0, 'floor') %}
{%  set secvo = timing%60 %}

<div class=\"grey\">
    <div class=\"ib padding-ten sub-txt-big\">{{ script.count }}</div>
    <div class=\"ib sub-txt-small bord-droit\">mots</div>

    <div class=\"ib sub-txt-small grey\">Durée estimée de la voix-off :</div>
    <div class=\"ib sub-txt-big grey\">{{ minvo }}</div>
    <div class=\"ib sub-txt-small grey\">min</div>
    <div class=\"ib sub-txt-big grey\">{{ secvo }}</div>
    <div class=\"ib sub-txt-small grey\">sec</div>
</div>

<div class=\"title-tab\"></div>

    {% set mintotal = 0 %}
    {% set sectotal = 0 %}



    {#Pour chaque réponse au questionnaire du script#}

<h4 class=\"ib title-tab script\">Votre script :</h4>

        {% for key,ecriture in ecritures %}

            {#<div style=\"width: 100%;\">#}


            <table class=\"title-txt-petit script\">
                <td><h5>Ligne de script n° {{ key + 1 }}</h5></td>
            </table>
            <div class=\"largeur-totale padding-ten\">
                <div class=\"sub-txt-small grey\">Description</div>
                <div>{{ ecriture.description }}</div>
            </div>
            <div class=\"largeur-totale padding-ten\">
                <div class=\"sub-txt-small grey\">Voix-off</div>
                <div>{{ ecriture.voixoff }} </div>
            </div>

            <div class=\"grey\">
                {% set timing = ecriture.count/2.5 %}
                {%  set minround = timing/60 %}
                {%  set min = minround|round(0, 'floor') %}
                {%  set sec = timing%60 %}
                <div class=\"ib\">
                    <div class=\"ib padding-ten sub-txt-big\">{{ ecriture.count }}</div>
                    <div class=\"ib sub-txt-small bord-droit\">mots</div>
                </div>
                <div class=\"ib\">
                    <div class=\"ib sub-txt-small\">Durée estimée :</div>
                    <div class=\"ib sub-txt-big\">{{ min }}</div>
                    <div class=\"ib sub-txt-small\">min</div>
                    <div class=\"ib sub-txt-big\">{{ sec }}</div>
                    <div class=\"ib sub-txt-small bord-droit\">sec</div>
                </div>



                {% if ecriture.tempsForceMin or ecriture.tempsForceSec %}
                    <div class=\"ib\">
                        <div class=\"ib sub-txt-small\">Durée forcée :</div>
                        <div class=\"ib sub-txt-big\">{{ ecriture.tempsForceMin }}</div>
                        <div class=\"ib sub-txt-small\"> min</div>
                        <div class=\"ib sub-txt-big\">{{  ecriture.tempsForceSec }}</div>
                        <div class=\"ib sub-txt-small bord-droit\"> sec</div>
                    </div>

                    {% set mintotal = mintotal + ecriture.tempsForceMin %}
                    {% set sectotal = sectotal + ecriture.tempsForceSec %}
                    {% if sectotal > 59 %}
                        {% set mintotal = mintotal +1 %}
                        {% set sectotal = sectotal - 60 %}
                    {% endif %}
                {% else %}
                    {% set mintotal = mintotal + min %}
                    {% set sectotal = sectotal + sec %}
                    {% if sectotal > 59 %}
                        {% set mintotal = mintotal +1 %}
                        {% set sectotal = sectotal - 60 %}
                    {% endif %}
                {% endif %}


                <div class=\"ib\">
                    <div class=\"ib sub-txt-small\">Durée depuis le début :</div>
                    <div class=\"ib sub-txt-big\">{{ mintotal }}</div>
                    <div class=\"ib sub-txt-small\">min</div>
                    <div class=\"ib sub-txt-big\">{{ sectotal }}</div>
                    <div class=\"ib sub-txt-small bord-droit\">sec</div>
                </div>


            </div>

            <div class=\"title-tab\"></div>
            <br>




        {% endfor %}

</div>
</body>



</html>", ":script:print.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/script/print.html.twig");
    }
}
