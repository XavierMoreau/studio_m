<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_ee8d74f3477cc6f5a46bef9a948ac6034ffc29767b8f2752e1ae3a2d4bf30f62 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_47202842c28547fe326a0d2d95a5bb0e0c2cc46acb654b28f2a6ddd172c21bcc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_47202842c28547fe326a0d2d95a5bb0e0c2cc46acb654b28f2a6ddd172c21bcc->enter($__internal_47202842c28547fe326a0d2d95a5bb0e0c2cc46acb654b28f2a6ddd172c21bcc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_47202842c28547fe326a0d2d95a5bb0e0c2cc46acb654b28f2a6ddd172c21bcc->leave($__internal_47202842c28547fe326a0d2d95a5bb0e0c2cc46acb654b28f2a6ddd172c21bcc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
", "@Framework/Form/password_widget.html.php", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/password_widget.html.php");
    }
}
