<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_f40eb8d56dba910b672bf9b06765ad3814b0a97640a91655ac73ffbe1e654530 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_76eda4036d157ec89e7d1e1a4c63fa367face3d1b0b99a92d1bde76a4058cd6f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_76eda4036d157ec89e7d1e1a4c63fa367face3d1b0b99a92d1bde76a4058cd6f->enter($__internal_76eda4036d157ec89e7d1e1a4c63fa367face3d1b0b99a92d1bde76a4058cd6f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_76eda4036d157ec89e7d1e1a4c63fa367face3d1b0b99a92d1bde76a4058cd6f->leave($__internal_76eda4036d157ec89e7d1e1a4c63fa367face3d1b0b99a92d1bde76a4058cd6f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/radio_widget.html.php", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/radio_widget.html.php");
    }
}
