<?php

/* :conseiltype:edit.html.twig */
class __TwigTemplate_d674f7f7bc6e71ba35839a90cc75e489ed58697037a19ae2f2bb520b61f93e2e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("layout.html.twig", ":conseiltype:edit.html.twig", 2);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1850fde82da19ffa1a1336eba8227b91bdb20fe8469f3ade43bd63944a998c6e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1850fde82da19ffa1a1336eba8227b91bdb20fe8469f3ade43bd63944a998c6e->enter($__internal_1850fde82da19ffa1a1336eba8227b91bdb20fe8469f3ade43bd63944a998c6e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":conseiltype:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1850fde82da19ffa1a1336eba8227b91bdb20fe8469f3ade43bd63944a998c6e->leave($__internal_1850fde82da19ffa1a1336eba8227b91bdb20fe8469f3ade43bd63944a998c6e_prof);

    }

    // line 4
    public function block_content($context, array $blocks = array())
    {
        $__internal_b64507066a5aa34315e26214a052547a0d0342adb9637fc0b23882a63e856189 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b64507066a5aa34315e26214a052547a0d0342adb9637fc0b23882a63e856189->enter($__internal_b64507066a5aa34315e26214a052547a0d0342adb9637fc0b23882a63e856189_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 5
        echo "    <h1>Type de conseil</h1>

    ";
        // line 7
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
    ";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "
    <input class=\"btn btn-primary\" type=\"submit\" value=\"Enregistrer\" />
    <a class=\"btn btn-default\" href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("conseiltype_index");
        echo "\">Retour</a>
    ";
        // line 11
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "


";
        
        $__internal_b64507066a5aa34315e26214a052547a0d0342adb9637fc0b23882a63e856189->leave($__internal_b64507066a5aa34315e26214a052547a0d0342adb9637fc0b23882a63e856189_prof);

    }

    public function getTemplateName()
    {
        return ":conseiltype:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 11,  53 => 10,  48 => 8,  44 => 7,  40 => 5,  34 => 4,  11 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
{% extends 'layout.html.twig' %}

{% block content %}
    <h1>Type de conseil</h1>

    {{ form_start(edit_form) }}
    {{ form_widget(edit_form) }}
    <input class=\"btn btn-primary\" type=\"submit\" value=\"Enregistrer\" />
    <a class=\"btn btn-default\" href=\"{{ path('conseiltype_index') }}\">Retour</a>
    {{ form_end(edit_form) }}


{% endblock %}
", ":conseiltype:edit.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/conseiltype/edit.html.twig");
    }
}
