<?php

/* FOSUserBundle:Profile:show_content.html.twig */
class __TwigTemplate_7583d663678c63a2a608534466715a35f1d86baaca1beb5b7b393d1295f97445 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1ba8032f7c889f8e2795ed5f1468138612a3fb6b9d773283c6813b43c2509f47 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1ba8032f7c889f8e2795ed5f1468138612a3fb6b9d773283c6813b43c2509f47->enter($__internal_1ba8032f7c889f8e2795ed5f1468138612a3fb6b9d773283c6813b43c2509f47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show_content.html.twig"));

        // line 2
        echo "
<div>
    <dl class=\"dl-horizontal\">
        <dt>Nom d'utilisateur</dt>
        <dd>";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "html", null, true);
        echo "</dd>
    </dl>


    <dl class=\"dl-horizontal\">
        <dt>Nom</dt>
        <dd>";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "nom", array()), "html", null, true);
        echo "</dd>
        <dt>Prénom</dt>
        <dd>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "prenom", array()), "html", null, true);
        echo "</dd>
        <dt>Société</dt>
        <dd>";
        // line 16
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "societe", array()), "html", null, true);
        echo "</dd>
        <dt>Poste</dt>
        <dd>";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "poste", array()), "html", null, true);
        echo "</dd>
        <dt>Téléphone</dt>
        <dd>";
        // line 20
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "telephone", array()), "html", null, true);
        echo "</dd>
        <dt>E-mail</dt>
        <dd>";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array()), "html", null, true);
        echo "</dd>
    </dl>


    <dl class=\"dl-horizontal\">
        <dt>Expert métier</dt>
        <dd>";
        // line 28
        if (($this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "userExpert", array()) == 1)) {
            echo " Oui ";
        } else {
            echo " Non ";
        }
        echo "</dd>
        <dt>Comédien audio</dt>
        <dd>";
        // line 30
        if (($this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "userVoix", array()) == 1)) {
            echo " Oui ";
        } else {
            echo " Non ";
        }
        echo "</dd>
        <dt>Dessinateur</dt>
        <dd>";
        // line 32
        if (($this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "userContributeur", array()) == 1)) {
            echo " Oui ";
        } else {
            echo " Non ";
        }
        echo "</dd>
    </dl>

    <dl class=\"dl-horizontal\">
        <dt>Membre depuis le</dt>
        <dd>";
        // line 37
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "dateCreation", array()), "d-m-Y"), "html", null, true);
        echo "</dd>
    </dl>
</div>

<div style=\"text-align: right; width : 210px\">
    <a class=\"btn btn-default\" href=\"";
        // line 42
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_profile_edit");
        echo "\">Modifier</a>
</div>
";
        
        $__internal_1ba8032f7c889f8e2795ed5f1468138612a3fb6b9d773283c6813b43c2509f47->leave($__internal_1ba8032f7c889f8e2795ed5f1468138612a3fb6b9d773283c6813b43c2509f47_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:show_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  109 => 42,  101 => 37,  89 => 32,  80 => 30,  71 => 28,  62 => 22,  57 => 20,  52 => 18,  47 => 16,  42 => 14,  37 => 12,  28 => 6,  22 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}

<div>
    <dl class=\"dl-horizontal\">
        <dt>Nom d'utilisateur</dt>
        <dd>{{ user.username }}</dd>
    </dl>


    <dl class=\"dl-horizontal\">
        <dt>Nom</dt>
        <dd>{{ user.nom }}</dd>
        <dt>Prénom</dt>
        <dd>{{ user.prenom }}</dd>
        <dt>Société</dt>
        <dd>{{ user.societe }}</dd>
        <dt>Poste</dt>
        <dd>{{ user.poste }}</dd>
        <dt>Téléphone</dt>
        <dd>{{ user.telephone }}</dd>
        <dt>E-mail</dt>
        <dd>{{ user.email }}</dd>
    </dl>


    <dl class=\"dl-horizontal\">
        <dt>Expert métier</dt>
        <dd>{% if user.userExpert == 1 %} Oui {% else %} Non {% endif %}</dd>
        <dt>Comédien audio</dt>
        <dd>{% if user.userVoix == 1 %} Oui {% else %} Non {% endif %}</dd>
        <dt>Dessinateur</dt>
        <dd>{% if user.userContributeur == 1 %} Oui {% else %} Non {% endif %}</dd>
    </dl>

    <dl class=\"dl-horizontal\">
        <dt>Membre depuis le</dt>
        <dd>{{ user.dateCreation|date('d-m-Y') }}</dd>
    </dl>
</div>

<div style=\"text-align: right; width : 210px\">
    <a class=\"btn btn-default\" href=\"{{ path('fos_user_profile_edit') }}\">Modifier</a>
</div>
", "FOSUserBundle:Profile:show_content.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/src/UserBundle/Resources/views/Profile/show_content.html.twig");
    }
}
