<?php

/* :support:index.html.twig */
class __TwigTemplate_e8996b754b27fcbc2b35418ddc285312c323856ca33d4922a045b2b16e42ab38 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":support:index.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4fb70fcc92c21aafa8db7f1adcc0380248294079b75a42c5c19f1a1371b50b7f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4fb70fcc92c21aafa8db7f1adcc0380248294079b75a42c5c19f1a1371b50b7f->enter($__internal_4fb70fcc92c21aafa8db7f1adcc0380248294079b75a42c5c19f1a1371b50b7f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":support:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4fb70fcc92c21aafa8db7f1adcc0380248294079b75a42c5c19f1a1371b50b7f->leave($__internal_4fb70fcc92c21aafa8db7f1adcc0380248294079b75a42c5c19f1a1371b50b7f_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_2561c62d5fc77ae3db15553a723ddbadd72d50c9c63ade609f6b20a9933a7f67 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2561c62d5fc77ae3db15553a723ddbadd72d50c9c63ade609f6b20a9933a7f67->enter($__internal_2561c62d5fc77ae3db15553a723ddbadd72d50c9c63ade609f6b20a9933a7f67_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <h1>Types de support</h1>

    <table class=\"table table-striped\">
        <thead>
            <tr>
                <th>Types proposés :</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["supports"]) ? $context["supports"] : $this->getContext($context, "supports")));
        foreach ($context['_seq'] as $context["_key"] => $context["support"]) {
            // line 15
            echo "            <tr>
                <td>";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute($context["support"], "supportType", array()), "html", null, true);
            echo "</td>
                <td><td><a class=\"btn-modifier\" href=\"";
            // line 17
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("support_edit", array("id" => $this->getAttribute($context["support"], "id", array()))), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-edit\" aria-hidden=\"true\"></span></a></td>
                <td><td><a class=\"btn-delete\" href=\"";
            // line 18
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("support_delete", array("id" => $this->getAttribute($context["support"], "id", array()))), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-trash\" aria-hidden=\"true\"></span></a></td>

            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['support'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 22
        echo "        </tbody>
    </table>


            <a class=\"btn btn-primary\" href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("support_new");
        echo "\">Nouveau</a>

    <a class=\"btn btn-default\" href=\"";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_index");
        echo "\">Retour</a>

";
        
        $__internal_2561c62d5fc77ae3db15553a723ddbadd72d50c9c63ade609f6b20a9933a7f67->leave($__internal_2561c62d5fc77ae3db15553a723ddbadd72d50c9c63ade609f6b20a9933a7f67_prof);

    }

    public function getTemplateName()
    {
        return ":support:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 28,  83 => 26,  77 => 22,  67 => 18,  63 => 17,  59 => 16,  56 => 15,  52 => 14,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}

{% block content %}
    <h1>Types de support</h1>

    <table class=\"table table-striped\">
        <thead>
            <tr>
                <th>Types proposés :</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        {% for support in supports %}
            <tr>
                <td>{{ support.supportType }}</td>
                <td><td><a class=\"btn-modifier\" href=\"{{ path('support_edit', { 'id': support.id }) }}\"><span class=\"glyphicon glyphicon-edit\" aria-hidden=\"true\"></span></a></td>
                <td><td><a class=\"btn-delete\" href=\"{{ path('support_delete', { 'id': support.id }) }}\"><span class=\"glyphicon glyphicon-trash\" aria-hidden=\"true\"></span></a></td>

            </tr>
        {% endfor %}
        </tbody>
    </table>


            <a class=\"btn btn-primary\" href=\"{{ path('support_new') }}\">Nouveau</a>

    <a class=\"btn btn-default\" href=\"{{ path('admin_index') }}\">Retour</a>

{% endblock %}
", ":support:index.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/support/index.html.twig");
    }
}
