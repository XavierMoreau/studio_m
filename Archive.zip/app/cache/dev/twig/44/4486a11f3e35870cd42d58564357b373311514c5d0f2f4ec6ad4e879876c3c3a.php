<?php

/* :scriptecriture:edit.html.twig */
class __TwigTemplate_909fd337a5a8469e9ea670c89b0f2c06386bbd1beb911ce9b8ec5f84263ca075 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":scriptecriture:edit.html.twig", 1);
        $this->blocks = array(
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_173229659b0b95ae6a6213477bb62a0078f0f5d0e144871d8ba50621ef11e019 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_173229659b0b95ae6a6213477bb62a0078f0f5d0e144871d8ba50621ef11e019->enter($__internal_173229659b0b95ae6a6213477bb62a0078f0f5d0e144871d8ba50621ef11e019_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":scriptecriture:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_173229659b0b95ae6a6213477bb62a0078f0f5d0e144871d8ba50621ef11e019->leave($__internal_173229659b0b95ae6a6213477bb62a0078f0f5d0e144871d8ba50621ef11e019_prof);

    }

    // line 4
    public function block_ariane($context, array $blocks = array())
    {
        $__internal_7f5c6509a3a8586a36adb065867047536fea8fcffdab359d744192c99d965a7b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7f5c6509a3a8586a36adb065867047536fea8fcffdab359d744192c99d965a7b->enter($__internal_7f5c6509a3a8586a36adb065867047536fea8fcffdab359d744192c99d965a7b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ariane"));

        // line 5
        echo "
     <div class=\"ariane grey\">
         <div class=\"ib sub-txt-small fine grey\">Projet en cours : </div><div class=\"ib fine lightgrey bord-droit\"> ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "nomProjet", array()), "html", null, true);
        echo "</div>

         <a href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine\">PROJETS</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Paramètres</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <a href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_orientation", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine\">SCRIPT</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Guide</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_voixoff", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Voix-Off</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Ecriture</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <div class=\"ib fine\">STORYBOARD</div>
         <div class=\"ib fine\">></div>
         <div class=\"ib fine petite\">Ecriture</div>

     </div>

 ";
        
        $__internal_7f5c6509a3a8586a36adb065867047536fea8fcffdab359d744192c99d965a7b->leave($__internal_7f5c6509a3a8586a36adb065867047536fea8fcffdab359d744192c99d965a7b_prof);

    }

    // line 42
    public function block_left($context, array $blocks = array())
    {
        $__internal_07eea709c74825bbc8bf7c15897f1304bae1b0fd382713cad91972aaa09c983b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_07eea709c74825bbc8bf7c15897f1304bae1b0fd382713cad91972aaa09c983b->enter($__internal_07eea709c74825bbc8bf7c15897f1304bae1b0fd382713cad91972aaa09c983b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "left"));

        // line 43
        echo "


    ";
        // line 46
        $context["mintotal"] = 0;
        // line 47
        echo "    ";
        $context["sectotal"] = 0;
        // line 48
        echo "


<table>

    <td style=\"width:70%; vertical-align: top;\">

        <div class=\"largeur-voixoff\">

    <div class=\"largeur-totale script-footer\">
        <a target=\"_blank\" class=\"ib icontop\" href=\"";
        // line 58
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_print", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\">
            <img src=\"";
        // line 59
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/print.png"), "html", null, true);
        echo "\" alt=\"Imprimer\" height=\"25\">

        </a>
        <a class=\"ib icontop\" href=\"";
        // line 62
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_valid", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\">
            <img src=\"";
        // line 63
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/envelope.png"), "html", null, true);
        echo "\" alt=\"Mail\" height=\"25\">

        </a>
    </div>



    ";
        // line 71
        echo "    <form>


            ";
        // line 74
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["ecritures"]) ? $context["ecritures"] : $this->getContext($context, "ecritures")));
        foreach ($context['_seq'] as $context["key"] => $context["ecriture"]) {
            // line 75
            echo "
                ";
            // line 77
            echo "
                <div style=\"background-color: white; border-radius: 10px\">
                <table class=\"title-tab\">
                    <td class=\"padding-ten hand script\"><h3>Séquence n° ";
            // line 80
            echo twig_escape_filter($this->env, ($context["key"] + 1), "html", null, true);
            echo "</h3></td>
                </table>

        ";
            // line 84
            echo "
            ";
            // line 86
            echo "            <input type=\"hidden\" name=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\" value=\"idecriture";
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\">

                <div class=\"largeur-totale\">
                    <div class=\"largeur-half-form-script ib txt-center\">
                        <div class=\"largeur-totale title-txt-petit script petite\">Voix-off</div>
                        <div class=\"largeur-totale padding-ten\" >
                            <label for=\"voixoff";
            // line 92
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\"></label>
                            <textarea class=\"txtarea-form-script\" placeholder=\"Saisissez la voixoff ici...\" rows=\"10\" name=\"vo";
            // line 93
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\" >";
            if ($this->getAttribute($context["ecriture"], "voixoff", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "voixoff", array()), "html", null, true);
            }
            echo "</textarea>
                        </div>
                    </div>
                    <div class=\"largeur-half-form-script ib txt-center\">
                        <div class=\"largeur-totale title-txt-petit script\">Description</div>
                        <div class=\"largeur-totale padding-ten\" >
                            <label for=\"description";
            // line 99
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\"></label>
                            <textarea class=\"txtarea-form-script\" placeholder=\"Saisissez la description ici...\" rows=\"10\" name=\"desc";
            // line 100
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\" >";
            if ($this->getAttribute($context["ecriture"], "description", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "description", array()), "html", null, true);
            }
            echo "</textarea>
                        </div>
                    </div>

                </div>

                <div class=\"sub-form-script\">
                    ";
            // line 107
            $context["timing"] = ($this->getAttribute($context["ecriture"], "count", array()) / 2.5);
            // line 108
            echo "                    ";
            $context["minround"] = ((isset($context["timing"]) ? $context["timing"] : $this->getContext($context, "timing")) / 60);
            // line 109
            echo "                    ";
            $context["min"] = twig_round((isset($context["minround"]) ? $context["minround"] : $this->getContext($context, "minround")), 0, "floor");
            // line 110
            echo "                    ";
            $context["sec"] = ((isset($context["timing"]) ? $context["timing"] : $this->getContext($context, "timing")) % 60);
            // line 111
            echo "                    <div class=\"ib petite fine\">
                        <div class=\"ib padding-ten sub-txt-big\">";
            // line 112
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "count", array()), "html", null, true);
            echo "</div>
                        <div class=\"ib sub-txt-small bord-droit\">mots</div>
                    </div>
                    <div class=\"ib petite fine\">
                        <div class=\"ib sub-txt-small\">Durée estimée :</div>
                        <div class=\"ib sub-txt-big\">";
            // line 117
            echo twig_escape_filter($this->env, (isset($context["min"]) ? $context["min"] : $this->getContext($context, "min")), "html", null, true);
            echo "</div>
                        <div class=\"ib sub-txt-small\">min</div>
                        <div class=\"ib sub-txt-big\">";
            // line 119
            echo twig_escape_filter($this->env, (isset($context["sec"]) ? $context["sec"] : $this->getContext($context, "sec")), "html", null, true);
            echo "</div>
                        <div class=\"ib sub-txt-small bord-droit\">sec</div>
                    </div>
                        <div class=\"ib petite fine\">
                        <div class=\"ib sub-txt-small\">Forcer la durée :</div>
                            <input style=\"display: inline-block; width: 30px; padding-right: 5px;\" placeholder=\"00\" type=\"number\" min=\"0\" max=\"59\" step=\"1\" class=\"form-control\" name=\"min";
            // line 124
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\" value=\"";
            if ($this->getAttribute($context["ecriture"], "tempsForceMin", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "tempsForceMin", array()), "html", null, true);
            }
            echo "\">
                        <div class=\"ib sub-txt-small\"> min</div>
                            <input style=\"display: inline-block; width: 30px; padding-right: 5px;\" placeholder=\"00\" type=\"number\" min=\"0\" max=\"59\" step=\"1\" class=\"form-control\" name=\"sec";
            // line 126
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\" value=\"";
            if ($this->getAttribute($context["ecriture"], "tempsForceSec", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "tempsForceSec", array()), "html", null, true);
            }
            echo "\">
                        <div class=\"ib sub-txt-small bord-droit\"> sec</div>
                    </div>

                    ";
            // line 130
            if (($this->getAttribute($context["ecriture"], "tempsForceMin", array()) || $this->getAttribute($context["ecriture"], "tempsForceSec", array()))) {
                // line 131
                echo "                        ";
                $context["mintotal"] = ((isset($context["mintotal"]) ? $context["mintotal"] : $this->getContext($context, "mintotal")) + $this->getAttribute($context["ecriture"], "tempsForceMin", array()));
                // line 132
                echo "                        ";
                $context["sectotal"] = ((isset($context["sectotal"]) ? $context["sectotal"] : $this->getContext($context, "sectotal")) + $this->getAttribute($context["ecriture"], "tempsForceSec", array()));
                // line 133
                echo "                        ";
                if (((isset($context["sectotal"]) ? $context["sectotal"] : $this->getContext($context, "sectotal")) > 59)) {
                    // line 134
                    echo "                            ";
                    $context["mintotal"] = ((isset($context["mintotal"]) ? $context["mintotal"] : $this->getContext($context, "mintotal")) + 1);
                    // line 135
                    echo "                            ";
                    $context["sectotal"] = ((isset($context["sectotal"]) ? $context["sectotal"] : $this->getContext($context, "sectotal")) - 60);
                    // line 136
                    echo "                        ";
                }
                // line 137
                echo "                    ";
            } else {
                // line 138
                echo "                        ";
                $context["mintotal"] = ((isset($context["mintotal"]) ? $context["mintotal"] : $this->getContext($context, "mintotal")) + (isset($context["min"]) ? $context["min"] : $this->getContext($context, "min")));
                // line 139
                echo "                        ";
                $context["sectotal"] = ((isset($context["sectotal"]) ? $context["sectotal"] : $this->getContext($context, "sectotal")) + (isset($context["sec"]) ? $context["sec"] : $this->getContext($context, "sec")));
                // line 140
                echo "                        ";
                if (((isset($context["sectotal"]) ? $context["sectotal"] : $this->getContext($context, "sectotal")) > 59)) {
                    // line 141
                    echo "                            ";
                    $context["mintotal"] = ((isset($context["mintotal"]) ? $context["mintotal"] : $this->getContext($context, "mintotal")) + 1);
                    // line 142
                    echo "                            ";
                    $context["sectotal"] = ((isset($context["sectotal"]) ? $context["sectotal"] : $this->getContext($context, "sectotal")) - 60);
                    // line 143
                    echo "                        ";
                }
                // line 144
                echo "                    ";
            }
            // line 145
            echo "

                    <div class=\"ib petite fine\">
                        <div class=\"ib sub-txt-small\">Durée depuis le début :</div>
                        <div class=\"ib sub-txt-big\">";
            // line 149
            echo twig_escape_filter($this->env, (isset($context["mintotal"]) ? $context["mintotal"] : $this->getContext($context, "mintotal")), "html", null, true);
            echo "</div>
                        <div class=\"ib sub-txt-small\">min</div>
                        <div class=\"ib sub-txt-big\">";
            // line 151
            echo twig_escape_filter($this->env, (isset($context["sectotal"]) ? $context["sectotal"] : $this->getContext($context, "sectotal")), "html", null, true);
            echo "</div>
                        <div class=\"ib sub-txt-small bord-droit\">sec</div>
                    </div>

                    <div class=\"ib\">
                        <button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\" formmethod=\"post\" formaction=\"";
            // line 156
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
            echo "\">
                            <table class=\"ib tab-buttons-petit shadow back-script\">
                                <td>
                                    <div class=\"lightgrey fine\">Mettre à jour</div>
                                </td>
                                <td>
                                    <img src=\"";
            // line 162
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/refresh-button.png"), "html", null, true);
            echo "\" alt=\"Enregistrer\" height=\"19\">
                                </td>
                            </table>
                        </button>

                        <a href=\"";
            // line 167
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_delete", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()), "scriptEcriture" => $this->getAttribute($context["ecriture"], "id", array()))), "html", null, true);
            echo "\">


                                    <div class=\"script ib\" style=\"font-size: 0.8em\">Supprimer la séquence</div>



                        </a>
                    </div>
                </div>





</div>
                <br>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['ecriture'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 185
        echo "
        <div class=\"largeur-totale txt-center ib\">

            <div class=\"ib\">
                <button class=\"btn-iconflat\" type=\"submit\" formmethod=\"post\" formaction=\"";
        // line 189
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_new", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\" value=\"Enregistrer\">
                    <img class=\"imgflat\" src=\"";
        // line 190
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/add-plus-button.png"), "html", null, true);
        echo "\" alt=\"Ajouter une ligne de script\" height=\"14\">
                    <h2 class=\"ib script hand\">Ajouter une séquence</h2>
                    <img class=\"imgflat\" src=\"";
        // line 192
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pen-plume.png"), "html", null, true);
        echo "\" alt=\"Ajouter une ligne de script\" height=\"35\">
                </button>
            </div>

        </div>



    </form>
        <br>




<div class=\"largeur-totale script-footer\">
    <a target=\"_blank\" class=\"ib icontop\" href=\"";
        // line 207
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_print", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\">
                <img src=\"";
        // line 208
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/print.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"30\">

    </a>
    ";
        // line 212
        echo "        <img src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/envelope.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"30\">

    </a>
</div>
        </div>


        <table class=\"largeur-totale voixoff-boxes\">

            <td style=\"width:33%\" class=\"txt-center\">
                <div class=\"script-voixoff-box1 back-projet\">
                    <a href=\"";
        // line 223
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_orientation", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
                        <div class=\"ib\">
                            <img src=\"";
        // line 225
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/compass.png"), "html", null, true);
        echo "\" alt=\"Retour\" height=\"30\">
                        </div>
                        <div>
                            <h3 class=\"ib hand petite\"><- Retour</h3>
                        </div>
                        <div class=\"ib txtround2 fine\">
                            <h4 class=\"script-questions\">1</h4>
                        </div>
                        <div class=\"ib hand\">| </div>
                        <div class=\"ib txtround2 fine\">
                            <h4 class=\"script-questions\">2</h4>
                        </div>
                        <div class=\"ib hand\">| </div>
                        <div class=\"ib txtround2 fine\">
                            <h4 class=\"script-questions\">3</h4>
                        </div>
                    </a>
                </div>
            </td>
            <td style=\"width:20%\"></td>git

            <td style=\"width:33%\" class=\"txt-center\">
                <div class=\"script-voixoff-box3 back-storyboard\">
                    ";
        // line 249
        echo "
                        <div class=\"ib\">
                            <img src=\"";
        // line 251
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/storyboard.png"), "html", null, true);
        echo "\" alt=\"Retour\" height=\"30\">
                        </div>
                        <div>
                            <h3 class=\"ib hand lightgrey petite\">Ecrire le storyboard -></h3>
                        </div>
                        <div class=\"ib txtround2 fine\">
                            <h4 class=\"storyboard\">4</h4>
                        </div>
                    ";
        // line 260
        echo "                </div>
            </td>

        </table>


    </td>
<td style=\"vertical-align: top; padding-right: 3%; padding-top: 1.5%;\">


    <div class=\"largeur-voixoff-right back-script padding-ten\">
        <a href=\"";
        // line 271
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">

        <h3 class=\"ib bord-droit hand lightgrey\">Vos réponses :</h3>
        </a>
    ";
        // line 275
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["reponses"]) ? $context["reponses"] : $this->getContext($context, "reponses")));
        foreach ($context['_seq'] as $context["key"] => $context["reponse"]) {
            // line 276
            echo "


        <div class=\"id sub-txt-small fine grey\">
            ";
            // line 280
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["reponse"], "question", array()), "question", array()), "html", null, true);
            echo "
        </div>



        <div class=\"id sub-txt-small normale lightgrey\">
            ";
            // line 286
            echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "reponse", array()), "html", null, true);
            echo "
        </div>

        <br>

        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['reponse'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 292
        echo "
    <div class=\"title-tab\"></div>


        <a href=\"";
        // line 296
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_voixoff", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">

        <h3 class=\"ib hand lightgrey\">Votre voix-off :</h3>

        </a>
    ";
        // line 301
        $context["timing"] = ($this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "count", array()) / 2.5);
        // line 302
        echo "    ";
        $context["minround"] = ((isset($context["timing"]) ? $context["timing"] : $this->getContext($context, "timing")) / 60);
        // line 303
        echo "    ";
        $context["minvo"] = twig_round((isset($context["minround"]) ? $context["minround"] : $this->getContext($context, "minround")), 0, "floor");
        // line 304
        echo "    ";
        $context["secvo"] = ((isset($context["timing"]) ? $context["timing"] : $this->getContext($context, "timing")) % 60);
        // line 305
        echo "
    <div class=\"ib sub-txt-big fine petite grey\">";
        // line 306
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "count", array()), "html", null, true);
        echo "</div>
    <div class=\"ib sub-txt-small fine petite grey bord-droit\">mots</div>

    <div class=\"ib sub-txt-big fine petite grey\">";
        // line 309
        echo twig_escape_filter($this->env, (isset($context["minvo"]) ? $context["minvo"] : $this->getContext($context, "minvo")), "html", null, true);
        echo "</div>
    <div class=\"ib sub-txt-small fine petite grey\">min</div>
    <div class=\"ib sub-txt-big fine petite grey\">";
        // line 311
        echo twig_escape_filter($this->env, (isset($context["secvo"]) ? $context["secvo"] : $this->getContext($context, "secvo")), "html", null, true);
        echo "</div>
    <div class=\"ib sub-txt-small fine petite grey\">sec</div>


    ";
        // line 315
        $context["text"] = twig_split_filter($this->env, $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "voixoffGlobal", array()), "
");
        // line 316
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["text"]) ? $context["text"] : $this->getContext($context, "text")));
        foreach ($context['_seq'] as $context["_key"] => $context["paragraph"]) {
            // line 317
            echo "    <p class=\"sub-txt-small normale lightgrey\">";
            echo twig_escape_filter($this->env, $context["paragraph"], "html", null, true);
            echo "</p>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['paragraph'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 319
        echo "
</div>
</td>

</table>

";
        
        $__internal_07eea709c74825bbc8bf7c15897f1304bae1b0fd382713cad91972aaa09c983b->leave($__internal_07eea709c74825bbc8bf7c15897f1304bae1b0fd382713cad91972aaa09c983b_prof);

    }

    public function getTemplateName()
    {
        return ":scriptecriture:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  605 => 319,  596 => 317,  591 => 316,  588 => 315,  581 => 311,  576 => 309,  570 => 306,  567 => 305,  564 => 304,  561 => 303,  558 => 302,  556 => 301,  548 => 296,  542 => 292,  530 => 286,  521 => 280,  515 => 276,  511 => 275,  504 => 271,  491 => 260,  480 => 251,  476 => 249,  450 => 225,  445 => 223,  430 => 212,  424 => 208,  420 => 207,  402 => 192,  397 => 190,  393 => 189,  387 => 185,  363 => 167,  355 => 162,  346 => 156,  338 => 151,  333 => 149,  327 => 145,  324 => 144,  321 => 143,  318 => 142,  315 => 141,  312 => 140,  309 => 139,  306 => 138,  303 => 137,  300 => 136,  297 => 135,  294 => 134,  291 => 133,  288 => 132,  285 => 131,  283 => 130,  272 => 126,  263 => 124,  255 => 119,  250 => 117,  242 => 112,  239 => 111,  236 => 110,  233 => 109,  230 => 108,  228 => 107,  214 => 100,  210 => 99,  197 => 93,  193 => 92,  181 => 86,  178 => 84,  172 => 80,  167 => 77,  164 => 75,  160 => 74,  155 => 71,  145 => 63,  141 => 62,  135 => 59,  131 => 58,  119 => 48,  116 => 47,  114 => 46,  109 => 43,  103 => 42,  85 => 29,  78 => 25,  71 => 21,  64 => 17,  57 => 13,  50 => 9,  45 => 7,  41 => 5,  35 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


 {% block ariane %}

     <div class=\"ariane grey\">
         <div class=\"ib sub-txt-small fine grey\">Projet en cours : </div><div class=\"ib fine lightgrey bord-droit\"> {{ projet.nomProjet }}</div>

         <a href=\"{{ path('projet_index', {'id':app.user.id}) }}\">
             <div class=\"ib fine\">PROJETS</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('projet_edit', {'id':app.user.id, 'projet': projet.id, 'script' : script.id }) }}\">
             <div class=\"ib fine petite\">Paramètres</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <a href=\"{{ path('script_orientation', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine\">SCRIPT</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('script_questions', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine petite\">Guide</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('script_voixoff', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine petite\">Voix-Off</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('scriptecriture_index', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine petite\">Ecriture</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <div class=\"ib fine\">STORYBOARD</div>
         <div class=\"ib fine\">></div>
         <div class=\"ib fine petite\">Ecriture</div>

     </div>

 {% endblock %}


{% block left %}



    {% set mintotal = 0 %}
    {% set sectotal = 0 %}



<table>

    <td style=\"width:70%; vertical-align: top;\">

        <div class=\"largeur-voixoff\">

    <div class=\"largeur-totale script-footer\">
        <a target=\"_blank\" class=\"ib icontop\" href=\"{{ path('script_print', {'id':app.user.id, 'projet': projet.id, 'script': script.id}) }}\">
            <img src=\"{{ asset('images/print.png')}}\" alt=\"Imprimer\" height=\"25\">

        </a>
        <a class=\"ib icontop\" href=\"{{ path('script_valid', {'id':app.user.id, 'projet': projet.id, 'script': script.id}) }}\">
            <img src=\"{{ asset('images/envelope.png')}}\" alt=\"Mail\" height=\"25\">

        </a>
    </div>



    {#Pour chaque réponse au questionnaire du script#}
    <form>


            {% for key,ecriture in ecritures %}

                {#<div style=\"width: 100%;\">#}

                <div style=\"background-color: white; border-radius: 10px\">
                <table class=\"title-tab\">
                    <td class=\"padding-ten hand script\"><h3>Séquence n° {{ key + 1 }}</h3></td>
                </table>

        {#On affiche le formulaire d'édition#}

            {#On renvoie l'id de la réponse en caché#}
            <input type=\"hidden\" name=\"{{ ecriture.id }}\" value=\"idecriture{{ ecriture.id }}\">

                <div class=\"largeur-totale\">
                    <div class=\"largeur-half-form-script ib txt-center\">
                        <div class=\"largeur-totale title-txt-petit script petite\">Voix-off</div>
                        <div class=\"largeur-totale padding-ten\" >
                            <label for=\"voixoff{{ ecriture.id }}\"></label>
                            <textarea class=\"txtarea-form-script\" placeholder=\"Saisissez la voixoff ici...\" rows=\"10\" name=\"vo{{ ecriture.id }}\" >{% if ecriture.voixoff %}{{ ecriture.voixoff }}{% endif %}</textarea>
                        </div>
                    </div>
                    <div class=\"largeur-half-form-script ib txt-center\">
                        <div class=\"largeur-totale title-txt-petit script\">Description</div>
                        <div class=\"largeur-totale padding-ten\" >
                            <label for=\"description{{ ecriture.id }}\"></label>
                            <textarea class=\"txtarea-form-script\" placeholder=\"Saisissez la description ici...\" rows=\"10\" name=\"desc{{ ecriture.id }}\" >{% if ecriture.description %}{{ ecriture.description }}{% endif %}</textarea>
                        </div>
                    </div>

                </div>

                <div class=\"sub-form-script\">
                    {% set timing = ecriture.count/2.5 %}
                    {%  set minround = timing/60 %}
                    {%  set min = minround|round(0, 'floor') %}
                    {%  set sec = timing%60 %}
                    <div class=\"ib petite fine\">
                        <div class=\"ib padding-ten sub-txt-big\">{{ ecriture.count }}</div>
                        <div class=\"ib sub-txt-small bord-droit\">mots</div>
                    </div>
                    <div class=\"ib petite fine\">
                        <div class=\"ib sub-txt-small\">Durée estimée :</div>
                        <div class=\"ib sub-txt-big\">{{ min }}</div>
                        <div class=\"ib sub-txt-small\">min</div>
                        <div class=\"ib sub-txt-big\">{{ sec }}</div>
                        <div class=\"ib sub-txt-small bord-droit\">sec</div>
                    </div>
                        <div class=\"ib petite fine\">
                        <div class=\"ib sub-txt-small\">Forcer la durée :</div>
                            <input style=\"display: inline-block; width: 30px; padding-right: 5px;\" placeholder=\"00\" type=\"number\" min=\"0\" max=\"59\" step=\"1\" class=\"form-control\" name=\"min{{ ecriture.id }}\" value=\"{% if ecriture.tempsForceMin %}{{ ecriture.tempsForceMin }}{% endif %}\">
                        <div class=\"ib sub-txt-small\"> min</div>
                            <input style=\"display: inline-block; width: 30px; padding-right: 5px;\" placeholder=\"00\" type=\"number\" min=\"0\" max=\"59\" step=\"1\" class=\"form-control\" name=\"sec{{ ecriture.id }}\" value=\"{% if ecriture.tempsForceSec %}{{ ecriture.tempsForceSec }}{% endif %}\">
                        <div class=\"ib sub-txt-small bord-droit\"> sec</div>
                    </div>

                    {% if ecriture.tempsForceMin or ecriture.tempsForceSec %}
                        {% set mintotal = mintotal + ecriture.tempsForceMin %}
                        {% set sectotal = sectotal + ecriture.tempsForceSec %}
                        {% if sectotal > 59 %}
                            {% set mintotal = mintotal +1 %}
                            {% set sectotal = sectotal - 60 %}
                        {% endif %}
                    {% else %}
                        {% set mintotal = mintotal + min %}
                        {% set sectotal = sectotal + sec %}
                        {% if sectotal > 59 %}
                            {% set mintotal = mintotal +1 %}
                            {% set sectotal = sectotal - 60 %}
                        {% endif %}
                    {% endif %}


                    <div class=\"ib petite fine\">
                        <div class=\"ib sub-txt-small\">Durée depuis le début :</div>
                        <div class=\"ib sub-txt-big\">{{ mintotal }}</div>
                        <div class=\"ib sub-txt-small\">min</div>
                        <div class=\"ib sub-txt-big\">{{ sectotal }}</div>
                        <div class=\"ib sub-txt-small bord-droit\">sec</div>
                    </div>

                    <div class=\"ib\">
                        <button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\" formmethod=\"post\" formaction=\"{{ path('scriptecriture_edit',{'id':app.user.id, 'projet': projet.id, 'script': script.id})}}\">
                            <table class=\"ib tab-buttons-petit shadow back-script\">
                                <td>
                                    <div class=\"lightgrey fine\">Mettre à jour</div>
                                </td>
                                <td>
                                    <img src=\"{{ asset('images/refresh-button.png')}}\" alt=\"Enregistrer\" height=\"19\">
                                </td>
                            </table>
                        </button>

                        <a href=\"{{ path('scriptecriture_delete', {'id':app.user.id, 'projet': projet.id, 'script': script.id, 'scriptEcriture': ecriture.id}) }}\">


                                    <div class=\"script ib\" style=\"font-size: 0.8em\">Supprimer la séquence</div>



                        </a>
                    </div>
                </div>





</div>
                <br>
        {% endfor %}

        <div class=\"largeur-totale txt-center ib\">

            <div class=\"ib\">
                <button class=\"btn-iconflat\" type=\"submit\" formmethod=\"post\" formaction=\"{{ path('scriptecriture_new',{'id':app.user.id, 'projet': projet.id, 'script': script.id})}}\" value=\"Enregistrer\">
                    <img class=\"imgflat\" src=\"{{ asset('images/add-plus-button.png')}}\" alt=\"Ajouter une ligne de script\" height=\"14\">
                    <h2 class=\"ib script hand\">Ajouter une séquence</h2>
                    <img class=\"imgflat\" src=\"{{ asset('images/pen-plume.png')}}\" alt=\"Ajouter une ligne de script\" height=\"35\">
                </button>
            </div>

        </div>



    </form>
        <br>




<div class=\"largeur-totale script-footer\">
    <a target=\"_blank\" class=\"ib icontop\" href=\"{{ path('script_print', {'id':app.user.id, 'projet': projet.id, 'script': script.id}) }}\">
                <img src=\"{{ asset('images/print.png')}}\" alt=\"Enregistrer\" height=\"30\">

    </a>
    {#<a class=\"ib icontop\" href=\"{{ path('script_valid', {'id':app.user.id, 'projet': projet.id, 'script': script.id}) }}\">#}
        <img src=\"{{ asset('images/envelope.png')}}\" alt=\"Enregistrer\" height=\"30\">

    </a>
</div>
        </div>


        <table class=\"largeur-totale voixoff-boxes\">

            <td style=\"width:33%\" class=\"txt-center\">
                <div class=\"script-voixoff-box1 back-projet\">
                    <a href=\"{{ path('script_orientation', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
                        <div class=\"ib\">
                            <img src=\"{{ asset('images/compass.png')}}\" alt=\"Retour\" height=\"30\">
                        </div>
                        <div>
                            <h3 class=\"ib hand petite\"><- Retour</h3>
                        </div>
                        <div class=\"ib txtround2 fine\">
                            <h4 class=\"script-questions\">1</h4>
                        </div>
                        <div class=\"ib hand\">| </div>
                        <div class=\"ib txtround2 fine\">
                            <h4 class=\"script-questions\">2</h4>
                        </div>
                        <div class=\"ib hand\">| </div>
                        <div class=\"ib txtround2 fine\">
                            <h4 class=\"script-questions\">3</h4>
                        </div>
                    </a>
                </div>
            </td>
            <td style=\"width:20%\"></td>git

            <td style=\"width:33%\" class=\"txt-center\">
                <div class=\"script-voixoff-box3 back-storyboard\">
                    {#<a href=\"{{ path('scriptecriture_index', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">#}

                        <div class=\"ib\">
                            <img src=\"{{ asset('images/storyboard.png')}}\" alt=\"Retour\" height=\"30\">
                        </div>
                        <div>
                            <h3 class=\"ib hand lightgrey petite\">Ecrire le storyboard -></h3>
                        </div>
                        <div class=\"ib txtround2 fine\">
                            <h4 class=\"storyboard\">4</h4>
                        </div>
                    {#</a>#}
                </div>
            </td>

        </table>


    </td>
<td style=\"vertical-align: top; padding-right: 3%; padding-top: 1.5%;\">


    <div class=\"largeur-voixoff-right back-script padding-ten\">
        <a href=\"{{ path('script_questions', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">

        <h3 class=\"ib bord-droit hand lightgrey\">Vos réponses :</h3>
        </a>
    {% for key,reponse in reponses %}



        <div class=\"id sub-txt-small fine grey\">
            {{ reponse.question.question }}
        </div>



        <div class=\"id sub-txt-small normale lightgrey\">
            {{ reponse.reponse }}
        </div>

        <br>

        {% endfor %}

    <div class=\"title-tab\"></div>


        <a href=\"{{ path('script_voixoff', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">

        <h3 class=\"ib hand lightgrey\">Votre voix-off :</h3>

        </a>
    {% set timing = script.count/2.5 %}
    {%  set minround = timing/60 %}
    {%  set minvo = minround|round(0, 'floor') %}
    {%  set secvo = timing%60 %}

    <div class=\"ib sub-txt-big fine petite grey\">{{ script.count }}</div>
    <div class=\"ib sub-txt-small fine petite grey bord-droit\">mots</div>

    <div class=\"ib sub-txt-big fine petite grey\">{{ minvo }}</div>
    <div class=\"ib sub-txt-small fine petite grey\">min</div>
    <div class=\"ib sub-txt-big fine petite grey\">{{ secvo }}</div>
    <div class=\"ib sub-txt-small fine petite grey\">sec</div>


    {% set text = script.voixoffGlobal|split('\\n') %}
    {% for paragraph in text %}
    <p class=\"sub-txt-small normale lightgrey\">{{ paragraph }}</p>
    {% endfor %}

</div>
</td>

</table>

{% endblock %}", ":scriptecriture:edit.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/scriptecriture/edit.html.twig");
    }
}
