<?php

/* :scriptecriture:edit.html.twig */
class __TwigTemplate_909fd337a5a8469e9ea670c89b0f2c06386bbd1beb911ce9b8ec5f84263ca075 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", ":scriptecriture:edit.html.twig", 1);
        $this->blocks = array(
            'ariane' => array($this, 'block_ariane'),
            'left' => array($this, 'block_left'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_94d11625bba2c178521ce72bd0a3d6bc4a28359a64ce91df4b4c7990021400cf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_94d11625bba2c178521ce72bd0a3d6bc4a28359a64ce91df4b4c7990021400cf->enter($__internal_94d11625bba2c178521ce72bd0a3d6bc4a28359a64ce91df4b4c7990021400cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":scriptecriture:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_94d11625bba2c178521ce72bd0a3d6bc4a28359a64ce91df4b4c7990021400cf->leave($__internal_94d11625bba2c178521ce72bd0a3d6bc4a28359a64ce91df4b4c7990021400cf_prof);

    }

    // line 4
    public function block_ariane($context, array $blocks = array())
    {
        $__internal_6486f5fd62224ed54650a7484e766ab69885b60c848f8d888e18435d28de51e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6486f5fd62224ed54650a7484e766ab69885b60c848f8d888e18435d28de51e0->enter($__internal_6486f5fd62224ed54650a7484e766ab69885b60c848f8d888e18435d28de51e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ariane"));

        // line 5
        echo "
     <div class=\"ariane grey\">
         <div class=\"ib sub-txt-small fine grey\">Projet en cours : </div><div class=\"ib fine lightgrey bord-droit\"> ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "nomProjet", array()), "html", null, true);
        echo "</div>

         <a href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine\">PROJETS</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("projet_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Paramètres</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <a href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_orientation", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine\">SCRIPT</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_questions", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Guide</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_voixoff", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Voix-Off</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_index", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute($this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "script", array()), "id", array()))), "html", null, true);
        echo "\">
             <div class=\"ib fine petite\">Ecriture</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <div class=\"ib fine\">STORYBOARD</div>
         <div class=\"ib fine\">></div>
         <div class=\"ib fine petite\">Ecriture</div>

     </div>

 ";
        
        $__internal_6486f5fd62224ed54650a7484e766ab69885b60c848f8d888e18435d28de51e0->leave($__internal_6486f5fd62224ed54650a7484e766ab69885b60c848f8d888e18435d28de51e0_prof);

    }

    // line 42
    public function block_left($context, array $blocks = array())
    {
        $__internal_87eea24543b9b7bde985a5bf06d9038945c942a47629ad49de76028d65039f59 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_87eea24543b9b7bde985a5bf06d9038945c942a47629ad49de76028d65039f59->enter($__internal_87eea24543b9b7bde985a5bf06d9038945c942a47629ad49de76028d65039f59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "left"));

        // line 43
        echo "


    ";
        // line 46
        $context["mintotal"] = 0;
        // line 47
        echo "    ";
        $context["sectotal"] = 0;
        // line 48
        echo "


<table>

    <td style=\"width:65%; vertical-align: top; background-color: #e4e8e9;\">

        <div class=\"padding-ten\">

    <div class=\"largeur-totale script-footer\">
        <a target=\"_blank\" class=\"ib icontop\" href=\"";
        // line 58
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_print", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\">
            <img src=\"";
        // line 59
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/print.png"), "html", null, true);
        echo "\" alt=\"Imprimer\" height=\"25\">

        </a>
        <a class=\"ib icontop\" href=\"";
        // line 62
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_valid", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\">
            <img src=\"";
        // line 63
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/envelope.png"), "html", null, true);
        echo "\" alt=\"Mail\" height=\"25\">

        </a>
    </div>



    ";
        // line 71
        echo "    <form>


            ";
        // line 74
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["ecritures"]) ? $context["ecritures"] : $this->getContext($context, "ecritures")));
        foreach ($context['_seq'] as $context["key"] => $context["ecriture"]) {
            // line 75
            echo "
                ";
            // line 77
            echo "
                <div style=\"background-color: white\";>
                <table class=\"title-tab\">
                    <td class=\"padding-ten script\"><h3>Ligne de script n° ";
            // line 80
            echo twig_escape_filter($this->env, ($context["key"] + 1), "html", null, true);
            echo "</h3></td>
                </table>

        ";
            // line 84
            echo "
            ";
            // line 86
            echo "            <input type=\"hidden\" name=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\" value=\"idecriture";
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\">

                <div class=\"largeur-totale\">
                    <div class=\"largeur-half-form-script ib txt-center\">
                        <div class=\"largeur-totale title-txt-petit script\">Voix-off</div>
                        <div class=\"largeur-totale padding-ten\" >
                            <label for=\"voixoff";
            // line 92
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\"></label>
                            <textarea class=\"txtarea-form-script\" placeholder=\"Saisissez la voixoff ici...\" rows=\"10\" name=\"vo";
            // line 93
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\" >";
            if ($this->getAttribute($context["ecriture"], "voixoff", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "voixoff", array()), "html", null, true);
            }
            echo "</textarea>
                        </div>
                    </div>
                    <div class=\"largeur-half-form-script ib txt-center\">
                        <div class=\"largeur-totale title-txt-petit script\">Description</div>
                        <div class=\"largeur-totale padding-ten\" >
                            <label for=\"description";
            // line 99
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\"></label>
                            <textarea class=\"txtarea-form-script\" placeholder=\"Saisissez la description ici...\" rows=\"10\" name=\"desc";
            // line 100
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\" >";
            if ($this->getAttribute($context["ecriture"], "description", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "description", array()), "html", null, true);
            }
            echo "</textarea>
                        </div>
                    </div>

                </div>

                <div class=\"sub-form-script\">
                    ";
            // line 107
            $context["timing"] = ($this->getAttribute($context["ecriture"], "count", array()) / 2.5);
            // line 108
            echo "                    ";
            $context["minround"] = ((isset($context["timing"]) ? $context["timing"] : $this->getContext($context, "timing")) / 60);
            // line 109
            echo "                    ";
            $context["min"] = twig_round((isset($context["minround"]) ? $context["minround"] : $this->getContext($context, "minround")), 0, "floor");
            // line 110
            echo "                    ";
            $context["sec"] = ((isset($context["timing"]) ? $context["timing"] : $this->getContext($context, "timing")) % 60);
            // line 111
            echo "                    <div class=\"ib\">
                        <div class=\"ib padding-ten sub-txt-big\">";
            // line 112
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "count", array()), "html", null, true);
            echo "</div>
                        <div class=\"ib sub-txt-small bord-droit\">mots</div>
                    </div>
                    <div class=\"ib\">
                        <div class=\"ib sub-txt-small\">Durée estimée :</div>
                        <div class=\"ib sub-txt-big\">";
            // line 117
            echo twig_escape_filter($this->env, (isset($context["min"]) ? $context["min"] : $this->getContext($context, "min")), "html", null, true);
            echo "</div>
                        <div class=\"ib sub-txt-small\">min</div>
                        <div class=\"ib sub-txt-big\">";
            // line 119
            echo twig_escape_filter($this->env, (isset($context["sec"]) ? $context["sec"] : $this->getContext($context, "sec")), "html", null, true);
            echo "</div>
                        <div class=\"ib sub-txt-small bord-droit\">sec</div>
                    </div>
                        <div class=\"ib\">
                        <div class=\"ib sub-txt-small\">Forcer la durée :</div>
                            <input style=\"display: inline-block; width: 50px; padding-right: 5px;\" placeholder=\"00\" type=\"number\" min=\"0\" max=\"59\" step=\"1\" class=\"form-control\" name=\"min";
            // line 124
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\" value=\"";
            if ($this->getAttribute($context["ecriture"], "tempsForceMin", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "tempsForceMin", array()), "html", null, true);
            }
            echo "\">
                        <div class=\"ib sub-txt-small\"> min</div>
                            <input style=\"display: inline-block; width: 50px; padding-right: 5px;\" placeholder=\"00\" type=\"number\" min=\"0\" max=\"59\" step=\"1\" class=\"form-control\" name=\"sec";
            // line 126
            echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "id", array()), "html", null, true);
            echo "\" value=\"";
            if ($this->getAttribute($context["ecriture"], "tempsForceSec", array())) {
                echo twig_escape_filter($this->env, $this->getAttribute($context["ecriture"], "tempsForceSec", array()), "html", null, true);
            }
            echo "\">
                        <div class=\"ib sub-txt-small bord-droit\"> sec</div>
                    </div>

                    ";
            // line 130
            if (($this->getAttribute($context["ecriture"], "tempsForceMin", array()) || $this->getAttribute($context["ecriture"], "tempsForceSec", array()))) {
                // line 131
                echo "                        ";
                $context["mintotal"] = ((isset($context["mintotal"]) ? $context["mintotal"] : $this->getContext($context, "mintotal")) + $this->getAttribute($context["ecriture"], "tempsForceMin", array()));
                // line 132
                echo "                        ";
                $context["sectotal"] = ((isset($context["sectotal"]) ? $context["sectotal"] : $this->getContext($context, "sectotal")) + $this->getAttribute($context["ecriture"], "tempsForceSec", array()));
                // line 133
                echo "                        ";
                if (((isset($context["sectotal"]) ? $context["sectotal"] : $this->getContext($context, "sectotal")) > 59)) {
                    // line 134
                    echo "                            ";
                    $context["mintotal"] = ((isset($context["mintotal"]) ? $context["mintotal"] : $this->getContext($context, "mintotal")) + 1);
                    // line 135
                    echo "                            ";
                    $context["sectotal"] = ((isset($context["sectotal"]) ? $context["sectotal"] : $this->getContext($context, "sectotal")) - 60);
                    // line 136
                    echo "                        ";
                }
                // line 137
                echo "                    ";
            } else {
                // line 138
                echo "                        ";
                $context["mintotal"] = ((isset($context["mintotal"]) ? $context["mintotal"] : $this->getContext($context, "mintotal")) + (isset($context["min"]) ? $context["min"] : $this->getContext($context, "min")));
                // line 139
                echo "                        ";
                $context["sectotal"] = ((isset($context["sectotal"]) ? $context["sectotal"] : $this->getContext($context, "sectotal")) + (isset($context["sec"]) ? $context["sec"] : $this->getContext($context, "sec")));
                // line 140
                echo "                        ";
                if (((isset($context["sectotal"]) ? $context["sectotal"] : $this->getContext($context, "sectotal")) > 59)) {
                    // line 141
                    echo "                            ";
                    $context["mintotal"] = ((isset($context["mintotal"]) ? $context["mintotal"] : $this->getContext($context, "mintotal")) + 1);
                    // line 142
                    echo "                            ";
                    $context["sectotal"] = ((isset($context["sectotal"]) ? $context["sectotal"] : $this->getContext($context, "sectotal")) - 60);
                    // line 143
                    echo "                        ";
                }
                // line 144
                echo "                    ";
            }
            // line 145
            echo "

                    <div class=\"ib\">
                        <div class=\"ib sub-txt-small\">Durée depuis le début :</div>
                        <div class=\"ib sub-txt-big\">";
            // line 149
            echo twig_escape_filter($this->env, (isset($context["mintotal"]) ? $context["mintotal"] : $this->getContext($context, "mintotal")), "html", null, true);
            echo "</div>
                        <div class=\"ib sub-txt-small\">min</div>
                        <div class=\"ib sub-txt-big\">";
            // line 151
            echo twig_escape_filter($this->env, (isset($context["sectotal"]) ? $context["sectotal"] : $this->getContext($context, "sectotal")), "html", null, true);
            echo "</div>
                        <div class=\"ib sub-txt-small bord-droit\">sec</div>
                    </div>

                    <div class=\"ib\">
                        <button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\" formmethod=\"post\" formaction=\"";
            // line 156
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_edit", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
            echo "\">
                            <table class=\"ib tab-buttons-petit shadow back-script\">
                                <td>
                                    <div class=\"lightgrey\">Mettre à jour</div>
                                </td>
                                <td>
                                    <img src=\"";
            // line 162
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/refresh-button.png"), "html", null, true);
            echo "\" alt=\"Enregistrer\" height=\"19\">
                                </td>
                            </table>
                        </button>

                        <a href=\"";
            // line 167
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_delete", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()), "scriptEcriture" => $this->getAttribute($context["ecriture"], "id", array()))), "html", null, true);
            echo "\">


                                    <div class=\"script ib\" style=\"font-size: 0.8em\">Supprimer</div>

                                    <img src=\"";
            // line 172
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/delete.png"), "html", null, true);
            echo "\" alt=\"Enregistrer\" height=\"13\">


                        </a>
                    </div>
                </div>

            <div class=\"title-tab\"></div>



</div>
                <br>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['ecriture'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 186
        echo "
        <div class=\"largeur-totale txt-center ib\">

            <div class=\"ib\">
                <button class=\"btn-iconflat\" type=\"submit\" formmethod=\"post\" formaction=\"";
        // line 190
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("scriptecriture_new", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\" value=\"Enregistrer\">
                    <img class=\"imgflat\" src=\"";
        // line 191
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/add-plus-button.png"), "html", null, true);
        echo "\" alt=\"Ajouter une ligne de script\" height=\"14\">
                    <h2 class=\"ib script\">Ajouter une ligne de script</h2>
                    <img class=\"imgflat\" src=\"";
        // line 193
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/pen-plume.png"), "html", null, true);
        echo "\" alt=\"Ajouter une ligne de script\" height=\"35\">
                </button>
            </div>

        </div>



    </form>
        <br>




<div class=\"largeur-totale script-footer\">
    <a target=\"_blank\" class=\"ib icontop\" href=\"";
        // line 208
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_print", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\">
                <img src=\"";
        // line 209
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/print.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"30\">

    </a>
    <a class=\"ib icontop\" href=\"";
        // line 212
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("script_valid", array("id" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "projet" => $this->getAttribute((isset($context["projet"]) ? $context["projet"] : $this->getContext($context, "projet")), "id", array()), "script" => $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "id", array()))), "html", null, true);
        echo "\">
        <img src=\"";
        // line 213
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("images/envelope.png"), "html", null, true);
        echo "\" alt=\"Enregistrer\" height=\"30\">

    </a>
</div>
        </div>


    </td>
<td style=\"vertical-align: top; padding-right: 3%\">


<div class=\"largeur-totale padding-ten\">

    <h3 class=\"ib bord-droit script\">Vos réponses :</h3>
    ";
        // line 227
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["reponses"]) ? $context["reponses"] : $this->getContext($context, "reponses")));
        foreach ($context['_seq'] as $context["key"] => $context["reponse"]) {
            // line 228
            echo "


        <div class=\"id sub-txt-small grey\">
            ";
            // line 232
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["reponse"], "question", array()), "question", array()), "html", null, true);
            echo "
        </div>



        <div class=\"id sub-txt-small script\">
            ";
            // line 238
            echo twig_escape_filter($this->env, $this->getAttribute($context["reponse"], "reponse", array()), "html", null, true);
            echo "
        </div>

        <br>

        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['reponse'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 244
        echo "
    <div class=\"title-tab\"></div>



    <h3 class=\"ib bord-droit script\">Votre voix-off :</h3>


    ";
        // line 252
        $context["timing"] = ($this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "count", array()) / 2.5);
        // line 253
        echo "    ";
        $context["minround"] = ((isset($context["timing"]) ? $context["timing"] : $this->getContext($context, "timing")) / 60);
        // line 254
        echo "    ";
        $context["minvo"] = twig_round((isset($context["minround"]) ? $context["minround"] : $this->getContext($context, "minround")), 0, "floor");
        // line 255
        echo "    ";
        $context["secvo"] = ((isset($context["timing"]) ? $context["timing"] : $this->getContext($context, "timing")) % 60);
        // line 256
        echo "
    <div class=\"ib sub-txt-big grey\">";
        // line 257
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "count", array()), "html", null, true);
        echo "</div>
    <div class=\"ib sub-txt-small grey bord-droit\">mots</div>

    <div class=\"ib sub-txt-big grey\">";
        // line 260
        echo twig_escape_filter($this->env, (isset($context["minvo"]) ? $context["minvo"] : $this->getContext($context, "minvo")), "html", null, true);
        echo "</div>
    <div class=\"ib sub-txt-small grey\">min</div>
    <div class=\"ib sub-txt-big grey\">";
        // line 262
        echo twig_escape_filter($this->env, (isset($context["secvo"]) ? $context["secvo"] : $this->getContext($context, "secvo")), "html", null, true);
        echo "</div>
    <div class=\"ib sub-txt-small grey\">sec</div>


    ";
        // line 266
        $context["text"] = twig_split_filter($this->env, $this->getAttribute((isset($context["script"]) ? $context["script"] : $this->getContext($context, "script")), "voixoffGlobal", array()), "
");
        // line 267
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["text"]) ? $context["text"] : $this->getContext($context, "text")));
        foreach ($context['_seq'] as $context["_key"] => $context["paragraph"]) {
            // line 268
            echo "    <p class=\"sub-txt-small script\">";
            echo twig_escape_filter($this->env, $context["paragraph"], "html", null, true);
            echo "</p>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['paragraph'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 270
        echo "
</div>
</td>

</table>

";
        
        $__internal_87eea24543b9b7bde985a5bf06d9038945c942a47629ad49de76028d65039f59->leave($__internal_87eea24543b9b7bde985a5bf06d9038945c942a47629ad49de76028d65039f59_prof);

    }

    public function getTemplateName()
    {
        return ":scriptecriture:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  545 => 270,  536 => 268,  531 => 267,  528 => 266,  521 => 262,  516 => 260,  510 => 257,  507 => 256,  504 => 255,  501 => 254,  498 => 253,  496 => 252,  486 => 244,  474 => 238,  465 => 232,  459 => 228,  455 => 227,  438 => 213,  434 => 212,  428 => 209,  424 => 208,  406 => 193,  401 => 191,  397 => 190,  391 => 186,  371 => 172,  363 => 167,  355 => 162,  346 => 156,  338 => 151,  333 => 149,  327 => 145,  324 => 144,  321 => 143,  318 => 142,  315 => 141,  312 => 140,  309 => 139,  306 => 138,  303 => 137,  300 => 136,  297 => 135,  294 => 134,  291 => 133,  288 => 132,  285 => 131,  283 => 130,  272 => 126,  263 => 124,  255 => 119,  250 => 117,  242 => 112,  239 => 111,  236 => 110,  233 => 109,  230 => 108,  228 => 107,  214 => 100,  210 => 99,  197 => 93,  193 => 92,  181 => 86,  178 => 84,  172 => 80,  167 => 77,  164 => 75,  160 => 74,  155 => 71,  145 => 63,  141 => 62,  135 => 59,  131 => 58,  119 => 48,  116 => 47,  114 => 46,  109 => 43,  103 => 42,  85 => 29,  78 => 25,  71 => 21,  64 => 17,  57 => 13,  50 => 9,  45 => 7,  41 => 5,  35 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


 {% block ariane %}

     <div class=\"ariane grey\">
         <div class=\"ib sub-txt-small fine grey\">Projet en cours : </div><div class=\"ib fine lightgrey bord-droit\"> {{ projet.nomProjet }}</div>

         <a href=\"{{ path('projet_index', {'id':app.user.id}) }}\">
             <div class=\"ib fine\">PROJETS</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('projet_edit', {'id':app.user.id, 'projet': projet.id, 'script' : script.id }) }}\">
             <div class=\"ib fine petite\">Paramètres</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <a href=\"{{ path('script_orientation', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine\">SCRIPT</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('script_questions', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine petite\">Guide</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('script_voixoff', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine petite\">Voix-Off</div>
         </a>
         <div class=\"ib fine\">></div>
         <a href=\"{{ path('scriptecriture_index', {'id':app.user.id, 'projet': projet.id,'script': projet.script.id}) }}\">
             <div class=\"ib fine petite\">Ecriture</div>
         </a>
         <div class=\"ib padding-ten fine\">></div>
         <div class=\"ib fine\">STORYBOARD</div>
         <div class=\"ib fine\">></div>
         <div class=\"ib fine petite\">Ecriture</div>

     </div>

 {% endblock %}


{% block left %}



    {% set mintotal = 0 %}
    {% set sectotal = 0 %}



<table>

    <td style=\"width:65%; vertical-align: top; background-color: #e4e8e9;\">

        <div class=\"padding-ten\">

    <div class=\"largeur-totale script-footer\">
        <a target=\"_blank\" class=\"ib icontop\" href=\"{{ path('script_print', {'id':app.user.id, 'projet': projet.id, 'script': script.id}) }}\">
            <img src=\"{{ asset('images/print.png')}}\" alt=\"Imprimer\" height=\"25\">

        </a>
        <a class=\"ib icontop\" href=\"{{ path('script_valid', {'id':app.user.id, 'projet': projet.id, 'script': script.id}) }}\">
            <img src=\"{{ asset('images/envelope.png')}}\" alt=\"Mail\" height=\"25\">

        </a>
    </div>



    {#Pour chaque réponse au questionnaire du script#}
    <form>


            {% for key,ecriture in ecritures %}

                {#<div style=\"width: 100%;\">#}

                <div style=\"background-color: white\";>
                <table class=\"title-tab\">
                    <td class=\"padding-ten script\"><h3>Ligne de script n° {{ key + 1 }}</h3></td>
                </table>

        {#On affiche le formulaire d'édition#}

            {#On renvoie l'id de la réponse en caché#}
            <input type=\"hidden\" name=\"{{ ecriture.id }}\" value=\"idecriture{{ ecriture.id }}\">

                <div class=\"largeur-totale\">
                    <div class=\"largeur-half-form-script ib txt-center\">
                        <div class=\"largeur-totale title-txt-petit script\">Voix-off</div>
                        <div class=\"largeur-totale padding-ten\" >
                            <label for=\"voixoff{{ ecriture.id }}\"></label>
                            <textarea class=\"txtarea-form-script\" placeholder=\"Saisissez la voixoff ici...\" rows=\"10\" name=\"vo{{ ecriture.id }}\" >{% if ecriture.voixoff %}{{ ecriture.voixoff }}{% endif %}</textarea>
                        </div>
                    </div>
                    <div class=\"largeur-half-form-script ib txt-center\">
                        <div class=\"largeur-totale title-txt-petit script\">Description</div>
                        <div class=\"largeur-totale padding-ten\" >
                            <label for=\"description{{ ecriture.id }}\"></label>
                            <textarea class=\"txtarea-form-script\" placeholder=\"Saisissez la description ici...\" rows=\"10\" name=\"desc{{ ecriture.id }}\" >{% if ecriture.description %}{{ ecriture.description }}{% endif %}</textarea>
                        </div>
                    </div>

                </div>

                <div class=\"sub-form-script\">
                    {% set timing = ecriture.count/2.5 %}
                    {%  set minround = timing/60 %}
                    {%  set min = minround|round(0, 'floor') %}
                    {%  set sec = timing%60 %}
                    <div class=\"ib\">
                        <div class=\"ib padding-ten sub-txt-big\">{{ ecriture.count }}</div>
                        <div class=\"ib sub-txt-small bord-droit\">mots</div>
                    </div>
                    <div class=\"ib\">
                        <div class=\"ib sub-txt-small\">Durée estimée :</div>
                        <div class=\"ib sub-txt-big\">{{ min }}</div>
                        <div class=\"ib sub-txt-small\">min</div>
                        <div class=\"ib sub-txt-big\">{{ sec }}</div>
                        <div class=\"ib sub-txt-small bord-droit\">sec</div>
                    </div>
                        <div class=\"ib\">
                        <div class=\"ib sub-txt-small\">Forcer la durée :</div>
                            <input style=\"display: inline-block; width: 50px; padding-right: 5px;\" placeholder=\"00\" type=\"number\" min=\"0\" max=\"59\" step=\"1\" class=\"form-control\" name=\"min{{ ecriture.id }}\" value=\"{% if ecriture.tempsForceMin %}{{ ecriture.tempsForceMin }}{% endif %}\">
                        <div class=\"ib sub-txt-small\"> min</div>
                            <input style=\"display: inline-block; width: 50px; padding-right: 5px;\" placeholder=\"00\" type=\"number\" min=\"0\" max=\"59\" step=\"1\" class=\"form-control\" name=\"sec{{ ecriture.id }}\" value=\"{% if ecriture.tempsForceSec %}{{ ecriture.tempsForceSec }}{% endif %}\">
                        <div class=\"ib sub-txt-small bord-droit\"> sec</div>
                    </div>

                    {% if ecriture.tempsForceMin or ecriture.tempsForceSec %}
                        {% set mintotal = mintotal + ecriture.tempsForceMin %}
                        {% set sectotal = sectotal + ecriture.tempsForceSec %}
                        {% if sectotal > 59 %}
                            {% set mintotal = mintotal +1 %}
                            {% set sectotal = sectotal - 60 %}
                        {% endif %}
                    {% else %}
                        {% set mintotal = mintotal + min %}
                        {% set sectotal = sectotal + sec %}
                        {% if sectotal > 59 %}
                            {% set mintotal = mintotal +1 %}
                            {% set sectotal = sectotal - 60 %}
                        {% endif %}
                    {% endif %}


                    <div class=\"ib\">
                        <div class=\"ib sub-txt-small\">Durée depuis le début :</div>
                        <div class=\"ib sub-txt-big\">{{ mintotal }}</div>
                        <div class=\"ib sub-txt-small\">min</div>
                        <div class=\"ib sub-txt-big\">{{ sectotal }}</div>
                        <div class=\"ib sub-txt-small bord-droit\">sec</div>
                    </div>

                    <div class=\"ib\">
                        <button class=\"btn-iconflat\" type=\"submit\" value=\"Enregistrer\" formmethod=\"post\" formaction=\"{{ path('scriptecriture_edit',{'id':app.user.id, 'projet': projet.id, 'script': script.id})}}\">
                            <table class=\"ib tab-buttons-petit shadow back-script\">
                                <td>
                                    <div class=\"lightgrey\">Mettre à jour</div>
                                </td>
                                <td>
                                    <img src=\"{{ asset('images/refresh-button.png')}}\" alt=\"Enregistrer\" height=\"19\">
                                </td>
                            </table>
                        </button>

                        <a href=\"{{ path('scriptecriture_delete', {'id':app.user.id, 'projet': projet.id, 'script': script.id, 'scriptEcriture': ecriture.id}) }}\">


                                    <div class=\"script ib\" style=\"font-size: 0.8em\">Supprimer</div>

                                    <img src=\"{{ asset('images/delete.png')}}\" alt=\"Enregistrer\" height=\"13\">


                        </a>
                    </div>
                </div>

            <div class=\"title-tab\"></div>



</div>
                <br>
        {% endfor %}

        <div class=\"largeur-totale txt-center ib\">

            <div class=\"ib\">
                <button class=\"btn-iconflat\" type=\"submit\" formmethod=\"post\" formaction=\"{{ path('scriptecriture_new',{'id':app.user.id, 'projet': projet.id, 'script': script.id})}}\" value=\"Enregistrer\">
                    <img class=\"imgflat\" src=\"{{ asset('images/add-plus-button.png')}}\" alt=\"Ajouter une ligne de script\" height=\"14\">
                    <h2 class=\"ib script\">Ajouter une ligne de script</h2>
                    <img class=\"imgflat\" src=\"{{ asset('images/pen-plume.png')}}\" alt=\"Ajouter une ligne de script\" height=\"35\">
                </button>
            </div>

        </div>



    </form>
        <br>




<div class=\"largeur-totale script-footer\">
    <a target=\"_blank\" class=\"ib icontop\" href=\"{{ path('script_print', {'id':app.user.id, 'projet': projet.id, 'script': script.id}) }}\">
                <img src=\"{{ asset('images/print.png')}}\" alt=\"Enregistrer\" height=\"30\">

    </a>
    <a class=\"ib icontop\" href=\"{{ path('script_valid', {'id':app.user.id, 'projet': projet.id, 'script': script.id}) }}\">
        <img src=\"{{ asset('images/envelope.png')}}\" alt=\"Enregistrer\" height=\"30\">

    </a>
</div>
        </div>


    </td>
<td style=\"vertical-align: top; padding-right: 3%\">


<div class=\"largeur-totale padding-ten\">

    <h3 class=\"ib bord-droit script\">Vos réponses :</h3>
    {% for key,reponse in reponses %}



        <div class=\"id sub-txt-small grey\">
            {{ reponse.question.question }}
        </div>



        <div class=\"id sub-txt-small script\">
            {{ reponse.reponse }}
        </div>

        <br>

        {% endfor %}

    <div class=\"title-tab\"></div>



    <h3 class=\"ib bord-droit script\">Votre voix-off :</h3>


    {% set timing = script.count/2.5 %}
    {%  set minround = timing/60 %}
    {%  set minvo = minround|round(0, 'floor') %}
    {%  set secvo = timing%60 %}

    <div class=\"ib sub-txt-big grey\">{{ script.count }}</div>
    <div class=\"ib sub-txt-small grey bord-droit\">mots</div>

    <div class=\"ib sub-txt-big grey\">{{ minvo }}</div>
    <div class=\"ib sub-txt-small grey\">min</div>
    <div class=\"ib sub-txt-big grey\">{{ secvo }}</div>
    <div class=\"ib sub-txt-small grey\">sec</div>


    {% set text = script.voixoffGlobal|split('\\n') %}
    {% for paragraph in text %}
    <p class=\"sub-txt-small script\">{{ paragraph }}</p>
    {% endfor %}

</div>
</td>

</table>

{% endblock %}", ":scriptecriture:edit.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/app/Resources/views/scriptecriture/edit.html.twig");
    }
}
