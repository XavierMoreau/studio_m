<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_e4c6614b8878719aff89fc1a0eeb1276c684952ff5e8dc12ffc6ff054a2ac3b1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0ec2ada0a4db5989190f48e65ca8588cd815d3b3a70d6e3feca827f5a55023e7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0ec2ada0a4db5989190f48e65ca8588cd815d3b3a70d6e3feca827f5a55023e7->enter($__internal_0ec2ada0a4db5989190f48e65ca8588cd815d3b3a70d6e3feca827f5a55023e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_0ec2ada0a4db5989190f48e65ca8588cd815d3b3a70d6e3feca827f5a55023e7->leave($__internal_0ec2ada0a4db5989190f48e65ca8588cd815d3b3a70d6e3feca827f5a55023e7_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_9ca70e9c76612886744c055efb9f882026300d31e68854440ebcb5e8e79dfc37 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9ca70e9c76612886744c055efb9f882026300d31e68854440ebcb5e8e79dfc37->enter($__internal_9ca70e9c76612886744c055efb9f882026300d31e68854440ebcb5e8e79dfc37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_9ca70e9c76612886744c055efb9f882026300d31e68854440ebcb5e8e79dfc37->leave($__internal_9ca70e9c76612886744c055efb9f882026300d31e68854440ebcb5e8e79dfc37_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
