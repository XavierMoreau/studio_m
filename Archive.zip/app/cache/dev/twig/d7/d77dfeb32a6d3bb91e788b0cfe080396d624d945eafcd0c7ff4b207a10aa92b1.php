<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_e4c6614b8878719aff89fc1a0eeb1276c684952ff5e8dc12ffc6ff054a2ac3b1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_80c2fe2e817e9b827ad34386f43a166076d048f080620da1409d578b113d16b5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_80c2fe2e817e9b827ad34386f43a166076d048f080620da1409d578b113d16b5->enter($__internal_80c2fe2e817e9b827ad34386f43a166076d048f080620da1409d578b113d16b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_80c2fe2e817e9b827ad34386f43a166076d048f080620da1409d578b113d16b5->leave($__internal_80c2fe2e817e9b827ad34386f43a166076d048f080620da1409d578b113d16b5_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_c06710677a89e5991e7241acbd33e45397df9f1c40c7cdc6a81c6d048f4eb84e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c06710677a89e5991e7241acbd33e45397df9f1c40c7cdc6a81c6d048f4eb84e->enter($__internal_c06710677a89e5991e7241acbd33e45397df9f1c40c7cdc6a81c6d048f4eb84e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_c06710677a89e5991e7241acbd33e45397df9f1c40c7cdc6a81c6d048f4eb84e->leave($__internal_c06710677a89e5991e7241acbd33e45397df9f1c40c7cdc6a81c6d048f4eb84e_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
