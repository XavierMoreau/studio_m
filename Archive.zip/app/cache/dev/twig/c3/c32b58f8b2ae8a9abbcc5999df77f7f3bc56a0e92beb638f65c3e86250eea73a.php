<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_b8e359b7b4eb61e4150468c4ba5c260067190a4debcf0a389d6832d6dac03dcf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_14f2cc05a4b82311f7a9712da58be61f7542322cf988530ee1950767ca0d626d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_14f2cc05a4b82311f7a9712da58be61f7542322cf988530ee1950767ca0d626d->enter($__internal_14f2cc05a4b82311f7a9712da58be61f7542322cf988530ee1950767ca0d626d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_14f2cc05a4b82311f7a9712da58be61f7542322cf988530ee1950767ca0d626d->leave($__internal_14f2cc05a4b82311f7a9712da58be61f7542322cf988530ee1950767ca0d626d_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_54fd61a37591edb2cc939f80400ebbb091c1c51454b0e10c8bd31f2c364512f8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_54fd61a37591edb2cc939f80400ebbb091c1c51454b0e10c8bd31f2c364512f8->enter($__internal_54fd61a37591edb2cc939f80400ebbb091c1c51454b0e10c8bd31f2c364512f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_54fd61a37591edb2cc939f80400ebbb091c1c51454b0e10c8bd31f2c364512f8->leave($__internal_54fd61a37591edb2cc939f80400ebbb091c1c51454b0e10c8bd31f2c364512f8_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_5714e2951a197ed0522c43dc7564bdb9aeb9102574432a4497899e7d55cd46de = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5714e2951a197ed0522c43dc7564bdb9aeb9102574432a4497899e7d55cd46de->enter($__internal_5714e2951a197ed0522c43dc7564bdb9aeb9102574432a4497899e7d55cd46de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_5714e2951a197ed0522c43dc7564bdb9aeb9102574432a4497899e7d55cd46de->leave($__internal_5714e2951a197ed0522c43dc7564bdb9aeb9102574432a4497899e7d55cd46de_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
