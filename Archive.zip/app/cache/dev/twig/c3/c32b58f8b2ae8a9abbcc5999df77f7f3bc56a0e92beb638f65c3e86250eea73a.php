<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_b8e359b7b4eb61e4150468c4ba5c260067190a4debcf0a389d6832d6dac03dcf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4fd6d8d79a48470149235f5e83b47277c4e9dd471c0570bf0a554b82df091e33 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4fd6d8d79a48470149235f5e83b47277c4e9dd471c0570bf0a554b82df091e33->enter($__internal_4fd6d8d79a48470149235f5e83b47277c4e9dd471c0570bf0a554b82df091e33_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4fd6d8d79a48470149235f5e83b47277c4e9dd471c0570bf0a554b82df091e33->leave($__internal_4fd6d8d79a48470149235f5e83b47277c4e9dd471c0570bf0a554b82df091e33_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_393a2ee39abdfa49f71f1ec02dbc664c4b5fadf344ecbd4114b9d3f38eb545c1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_393a2ee39abdfa49f71f1ec02dbc664c4b5fadf344ecbd4114b9d3f38eb545c1->enter($__internal_393a2ee39abdfa49f71f1ec02dbc664c4b5fadf344ecbd4114b9d3f38eb545c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_393a2ee39abdfa49f71f1ec02dbc664c4b5fadf344ecbd4114b9d3f38eb545c1->leave($__internal_393a2ee39abdfa49f71f1ec02dbc664c4b5fadf344ecbd4114b9d3f38eb545c1_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_122c14f10c15a73aa60b555a1c3c2dd9984c3c12f00b06e1108b83de16f08032 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_122c14f10c15a73aa60b555a1c3c2dd9984c3c12f00b06e1108b83de16f08032->enter($__internal_122c14f10c15a73aa60b555a1c3c2dd9984c3c12f00b06e1108b83de16f08032_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_122c14f10c15a73aa60b555a1c3c2dd9984c3c12f00b06e1108b83de16f08032->leave($__internal_122c14f10c15a73aa60b555a1c3c2dd9984c3c12f00b06e1108b83de16f08032_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "/Users/macmini/Desktop/Xavier/DEV/studio_m/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
